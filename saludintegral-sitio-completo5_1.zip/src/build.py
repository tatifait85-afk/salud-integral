# -*- coding: utf-8 -*-
import os, json, shutil, html, sys
sys.path.insert(0, os.path.dirname(__file__))
from config import *
import catalog, assistant
from content import COMMON, HOME
from content_food import FOOD, PRODUCTS
from content_spiritual import SPIRIT
from articles import ARTICLES, SPIRITUAL_COURSES, EN_BLOG

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DIST = os.path.join(ROOT, "dist")
E = html.escape

ICONS = {
 "clipboard": '<rect x="6" y="4" width="12" height="17" rx="2"/><path d="M9 4h6v3H9z"/><path d="M9 12h6M9 16h4"/>',
 "video":  '<rect x="3" y="6" width="13" height="12" rx="2"/><path d="M16 10l5-3v10l-5-3"/>',
 "brain":  '<path d="M9 4a3 3 0 0 0-3 3 3 3 0 0 0-2 5 3 3 0 0 0 2 5 3 3 0 0 0 5 1V4a3 3 0 0 0-2 0z"/><path d="M15 4a3 3 0 0 1 3 3 3 3 0 0 1 2 5 3 3 0 0 1-2 5 3 3 0 0 1-5 1V4a3 3 0 0 1 2 0z"/>',
 "leaf":   '<path d="M5 19c0-8 5-13 14-14 0 9-5 14-13 14"/><path d="M5 19l8-8"/>',
 "heart":  '<path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/>',
 "laptop": '<rect x="4" y="5" width="16" height="11" rx="1.5"/><path d="M2 19h20"/>',
 "sprout": '<path d="M12 21v-9"/><path d="M12 12c0-4-3-6-7-6 0 4 3 6 7 6z"/><path d="M12 14c0-3 2.5-5 6-5 0 3-2.5 5-6 5z"/>',
 "bowl":   '<path d="M3 11h18a9 9 0 0 1-18 0z"/><path d="M8 7c0-2 2-2 2-4M13 7c0-2 2-2 2-4"/>',
 "move":   '<path d="M3 12h4l2.5-6 4 12 2.5-6h5"/>',
 "wind":   '<path d="M3 9h11a3 3 0 1 0-3-3"/><path d="M3 14h15a3 3 0 1 1-3 3"/>',
 "wave":   '<path d="M2 12c2-4 4-4 6 0s4 4 6 0 4-4 6 0"/><path d="M2 17c2-4 4-4 6 0s4 4 6 0 4-4 6 0" opacity=".5"/>',
 "repeat": '<path d="M4 12a8 8 0 0 1 14-5.3M20 12a8 8 0 0 1-14 5.3"/><path d="M18 3v4h-4M6 21v-4h4"/>',
 "compass":'<circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2 5-5 2 2-5z"/>',
 "mail":   '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
 "chat":   '<path d="M4 5h16v11H9l-5 4z"/>',
 "menu":   '<path d="M4 7h16M4 12h16M4 17h16"/>',
 "x":      '<path d="M6 6l12 12M18 6L6 18"/>',
}
def sprite():
    s = "".join(f'<symbol id="i-{k}" viewBox="0 0 24 24">{v}</symbol>' for k, v in ICONS.items())
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="0" height="0" style="position:absolute" aria-hidden="true" focusable="false"><defs>{s}</defs></svg>'
def icon(name, cls="ic"):
    return f'<svg class="{cls}" aria-hidden="true" focusable="false"><use href="#i-{name}"/></svg>'

LOGO = '<img class="logo-mark" src="/assets/img/logo.webp" width="46" height="46" alt="" aria-hidden="true">'

NAV_KEYS = ["home", "food", "habits", "mind", "spiritual", "resources", "about", "blog", "contact"]
def nav_href(lang, k):
    return ((BLOG_BASE if lang == "es" else EN_BLOG) + "/") if k == "blog" else url(lang, k)

def head(lang, key, title, desc, og_img="/assets/img/hero-home.webp", alts_on=True, noindex=False, extra_css=""):
    other = "en" if lang == "es" else "es"
    canon = SITE_URL + url(lang, key)
    alts = "" if not alts_on else (f'<link rel="alternate" hreflang="es" href="{SITE_URL}{url("es", key)}">'
            f'<link rel="alternate" hreflang="en" href="{SITE_URL}{url("en", key)}">'
            f'<link rel="alternate" hreflang="x-default" href="{SITE_URL}{url("es", key)}">')
    return f'''<!doctype html>
<html lang="{lang}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>{E(title)}</title>
<meta name="description" content="{E(desc)}">
<link rel="canonical" href="{canon}">
{'<meta name="robots" content="noindex,nofollow">' if noindex else ""}
{alts}
<meta property="og:type" content="website"><meta property="og:site_name" content="Salud Integral">
<meta property="og:title" content="{E(title)}"><meta property="og:description" content="{E(desc)}">
<meta property="og:url" content="{canon}"><meta property="og:image" content="{SITE_URL}{og_img}">
<meta name="theme-color" content="#F7F3E8">
<link rel="icon" href="/favicon.ico" sizes="48x48">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/img/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/assets/img/favicon-16x16.png">
<link rel="apple-touch-icon" href="/assets/img/apple-touch-icon.png">
<link rel="preload" href="/assets/fonts/fraunces-latin-wght-normal.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="/assets/fonts/jost-latin-wght-normal.woff2" as="font" type="font/woff2" crossorigin>
<link rel="stylesheet" href="/assets/css/site.css">
{extra_css}
</head>
<body class="page-{key}">
{sprite()}'''

def header(lang, key):
    c = COMMON[lang]; other = "en" if lang == "es" else "es"
    items = []
    for k in NAV_KEYS:
        cur = ' aria-current="page"' if k == key else ""
        ext = ' target="_blank" rel="noopener"' if k == "blog" else ""
        items.append(f'<li><a href="{nav_href(lang,k)}"{cur}{ext}>{E(c["nav"][k])}</a></li>')
    return f'''<a class="skip" href="#main">{E(c["skip"])}</a>
<header class="site-header">
  <div class="container bar">
    <a class="brand" href="{url(lang,"home")}" aria-label="Salud Integral">{LOGO}<span class="brand-text"><span class="brand-name">Salud Integral</span><span class="brand-tag">{E(c["brand_tag"])}</span></span></a>
    <nav class="nav" id="nav" aria-label="{'Principal' if lang=='es' else 'Main'}"><ul>{"".join(items)}</ul></nav>
    <a class="lang" href="{url(other,key)}" hreflang="{other}" lang="{other}" aria-label="{E(c["other_label"])}">{E(c["other_lang"])}</a>
    <button class="menu-btn" type="button" aria-expanded="false" aria-controls="nav" aria-label="{E(c["menu"])}">{icon("menu")}</button>
  </div>
</header>'''

def footer(lang):
    c = COMMON[lang]
    links = "".join(f'<li><a href="{nav_href(lang,k)}"{" target=_blank rel=noopener" if k=="blog" else ""}>{E(c["nav"][k])}</a></li>' for k in NAV_KEYS[1:])
    wa = wa_link(lang, COMMON["es"]["wa_msg"], COMMON["en"]["wa_msg"])
    return f'''<footer class="site-footer">
  <div class="container fgrid">
    <div class="fbrand"><a class="brand brand-inv" href="{url(lang,"home")}">{LOGO}<span class="brand-text"><span class="brand-name">Salud Integral</span></span></a>
      <p>{E(c["footer_about"])}</p></div>
    <div><h2 class="fh">{E(c["footer_explore"])}</h2><ul class="flist">{links}</ul></div>
    <div><h2 class="fh">{E(c["footer_contact"])}</h2><ul class="flist">
      <li><a href="{wa}" target="_blank" rel="noopener">{E(c["wa_label"])} {CONTACT["wa_display"]}</a></li>
      <li><a href="mailto:{CONTACT["email"]}">{CONTACT["email"]}</a></li></ul>
      <h2 class="fh fh2">{E(c["footer_follow"])}</h2><ul class="flist">
      <li><a href="{CONTACT["facebook"]}" target="_blank" rel="noopener">{E(c["facebook"])}</a></li>
      <li><a href="{CONTACT["linkedin"]}" target="_blank" rel="noopener">{E(c["linkedin"])}</a></li></ul></div>
  </div>
  <div class="container fbase"><p class="disc">{E(c["disclaimer"])}</p><p class="copy">{E(c["copyright"])}</p></div>
</footer>'''

def tail(lang):
    return f'''<script src="/assets/js/data-{lang}.js" defer></script>
<script src="/assets/js/site.js" defer></script>
<script src="/assets/js/romero.js" defer></script>
</body></html>'''

# ------------------------------------------------------------------ HOME
def home(lang):
    h = HOME[lang]; L = lambda a, b: a if lang == "es" else b
    cat = {r["id"]: r for r in catalog.build(lang)}
    img = {"food": "salud-digestiva", "habits": "habitos", "mind": "mente-tranquila", "spiritual": "espiritual-card"}
    sup = "".join(f'<li>{icon(i)}<span>{E(t)}</span></li>' for i, t in h["supports"])
    areas = "".join(f'''<article class="card area">
        <div class="card-img"><img src="/assets/img/{img[k]}-m.webp" alt="{E(alt)}" width="720" height="405" loading="lazy" decoding="async"></div>
        <div class="card-body"><h3>{E(t)}</h3><p>{E(d)}</p>
        <a class="more" href="{url(lang,k)}">{E(cta)}</a></div></article>''' for k, _i, t, d, cta, alt in h["areas"])
    tools = "".join(f'<li><span class="ico">{icon(i,"ic ic-lg")}</span><span>{E(t)}</span></li>' for i, t in h["tools"])
    testi = "".join(f"<p>{E(p)}</p>" for p in h["testi"])
    books = "".join(f'''<li><a class="book" href="{b["url"]}" target="_blank" rel="noopener sponsored" aria-label="{E(b["title"])} — {E(h["res_amazon_badge"])}">
        <span class="cover"><img src="{b["img"]}" alt="{E(L('Portada de ','Cover of '))}{E(b["title"])}" width="240" height="375" loading="lazy" decoding="async"><span class="badge">{E(h["res_amazon_badge"])} ↗</span></span>
        <span class="btitle">{E(b["title"])}</span></a></li>''' for b in [cat[f"libro-{i}"] for i in "12345"])
    course, rep = cat["curso"], cat["informe"]
    body = f'''{head(lang,"home",h["title"],h["desc"])}
{header(lang,"home")}
<main id="main">
<section class="hero">
  <picture class="hero-media"><source media="(max-width: 760px)" srcset="/assets/img/hero-home-m.webp"><img src="/assets/img/hero-home.webp" alt="{E(h["hero_img_alt"])}" width="1672" height="941" fetchpriority="high"></picture>
  <div class="container hero-inner"><div class="hero-copy">
    <h1>{E(h["hero_h1"])}</h1><p class="lead">{E(h["hero_sub"])}</p>
    <a class="btn btn-primary" href="#areas">{E(h["hero_cta"])}</a>
    <ul class="supports">{sup}</ul></div></div>
</section>

<section class="section areas" id="areas"><div class="container">
  <div class="sec-head"><h2>{E(h["areas_h2"])}</h2><p>{E(h["areas_p"])}</p></div>
  <div class="grid-4">{areas}</div>
</div></section>

<section class="guide"><div class="container guide-in">
  <img class="guide-img" src="/assets/img/romero.webp" alt="" width="200" height="260" loading="lazy">
  <div><h2>{E(h["guide_h2"])}</h2><p>{E(h["guide_p"])}</p>
  <div class="guide-actions"><button class="btn btn-terra" type="button" data-open-guide>{E(h["guide_cta"])}</button><span class="note">{E(h["guide_note"])}</span></div></div>
</div></section>

<section class="section tools"><div class="container">
  <h2 class="center">{E(h["tools_h2"])}</h2>
  <ul class="tools-grid">{tools}</ul>
</div></section>

<section class="section about"><div class="container about-in">
  <div class="about-photo"><img src="/assets/img/sobre-mi-m.webp" alt="{E(h["about_img_alt"])}" width="720" height="603" loading="lazy" decoding="async"></div>
  <div class="about-copy"><h2>{E(h["about_h2"])}</h2>
    <p class="pull">{E(h["about_quote"])}</p>
    <p>{E(h["about_p1"])}</p><p>{E(h["about_p2"])}</p>
    <a class="btn btn-outline" href="{url(lang,"about")}">{E(h["about_cta"])}</a></div>
</div></section>

<section class="section testi"><div class="container testi-in">
  <h2>{E(h["testi_h2"])}</h2>
  <figure class="quote"><blockquote>{testi}</blockquote><figcaption>— {E(h["testi_by"])}</figcaption></figure>
</div></section>

<section class="section resources"><div class="container">
  <div class="sec-head"><h2>{E(h["res_h2"])}</h2><p>{E(h["res_p"])}</p></div>
  <div class="res-books">
    <div class="rb-copy"><h3>{E(h["res_books_h"])}</h3><p>{E(h["res_books_p"])}</p>
      <a class="more" href="{LINKS["amazon_author"]}" target="_blank" rel="noopener sponsored">{E(h["res_books_cta"])}</a></div>
    <ul class="books">{books}</ul>
  </div>
  <div class="res-tiles">
      <a class="tile" href="{course["url"]}" target="_blank" rel="noopener"><h3>{E(course["title"])}</h3><p>{E(h["res_course_p"])}</p><span class="more">{E(course["cta"])}</span></a>
      <a class="tile" href="{rep["url"]}"><h3>{E(h["res_report_h"])} <span class="price">USD 25</span></h3><p>{E(h["res_report_p"])}</p><span class="more">{E(rep["cta"])}</span></a>
      <a class="tile" href="{url(lang,"food")}"><h3>{E(h["res_food_h"])}</h3><p>{E(h["res_food_p"])}</p><span class="more">{E(h["res_food_cta"])}</span></a>
  </div>
  <p class="center"><a class="btn btn-primary" href="{url(lang,"resources")}">{E(h["res_all_cta"])}</a></p>
</div></section>
</main>
{footer(lang)}
{tail(lang)}'''
    return body


# ------------------------------------------------------------------ helpers de artículos
def article_cards(lang, page, read_label):
    """Tarjetas de artículos (3 por tema). EN usa el artículo de flowsomatic si existe; si no, el artículo en español, marcado."""
    out = []
    for a in ARTICLES[page]:
        if lang == "en" and a["en"]:
            href, title, img, tag = a["en"]["url"], a["en"]["title"], a["img_en"], ""
        elif lang == "en":
            href, title, img, tag = a["url"], a["title"], a["img"], "In Spanish"
        else:
            href, title, img, tag = a["url"], a["title"], a["img"], ""
        portrait = False
        if img:
            from PIL import Image as _I
            _w, _h = _I.open(os.path.join(ROOT, "static", img.replace("/assets/", ""))).size; portrait = _h > _w * 1.15
        pic = (f'<div class="card-img{" contain" if portrait else ""}"><img src="{img}" alt="" width="640" height="400" loading="lazy" decoding="async"></div>' if img
               else f'<div class="card-img card-img-empty">{icon("leaf","ic ic-lg")}</div>')
        tg = f'<span class="tag">{E(tag)}</span>' if tag else ""
        out.append(f'''<article class="card art">{pic}<div class="card-body">{tg}<h3>{E(title)}</h3>
          <a class="more" href="{href}" target="_blank" rel="noopener">{E(read_label)} →</a></div></article>''')
    return "".join(out)

def products_html(lang):
    """Sección comercial (productos) + «Cómo pagar». Independiente de la sección editorial de artículos."""
    P = PRODUCTS[lang]
    cards = []
    for it in P["items"]:
        inc = "".join(f"<li>{E(x)}</li>" for x in it["inc"])
        if it["kind"] == "form":
            f = FOOD["es"]
            action = f'''<form class="rm-form" data-ml="{LINKS["mailerlite_programa"]}" data-ok="{E(f["free_ok"])}" data-err="{E(f["free_err"])}" novalidate>
          <input type="email" name="fields[email]" required autocomplete="email" placeholder="{E(f["free_ph"])}" aria-label="{E(f["free_label"])}">
          <button type="submit">{E(it["cta"])}</button></form>
          <p class="offer-note" role="status" aria-live="polite" data-ml-msg></p>'''
        elif it["kind"] == "wa":
            action = f'<a class="btn btn-primary" href="{wa_link(lang, it["msg"], it["msg"])}" target="_blank" rel="noopener">{E(it["cta"])} →</a>'
        else:
            action = f'<a class="btn btn-primary" href="{it["href"]}" target="_blank" rel="noopener">{E(it["cta"])} →</a>'
        cards.append(f'''<article class="card prod">
      <div class="card-img"><img src="/assets/img/{it["img"]}.webp" alt="{E(it["alt"])}" width="1200" height="800" loading="lazy" decoding="async"></div>
      <div class="card-body">
        <h3>{E(it["name"])}</h3>
        <p class="prod-desc">{E(it["desc"])}</p>
        <p class="prod-h">{E(P["incl"])}</p>
        <ul class="offer-list">{inc}</ul>
        <p class="offer-meta">{icon("mail")} <span><strong>{E(P["deliv"])}:</strong> {E(it["delivery"])}</span></p>
        <div class="offer-row"><span class="price price-lg">{E(it["price"])}</span></div>
        {action}
      </div></article>''')
    cls = "prod-grid" + (" prod-one" if len(cards) == 1 else "")
    ints = (f'<div><h3>{E(P["pay_int"])}</h3><ul class="offer-list">{"".join("<li>"+E(x)+"</li>" for x in P["pay_int_l"])}</ul></div>' if P["pay_int"] else "")
    steps = "".join(f"<li>{E(x)}</li>" for x in P["pay_steps"])
    return f'''<section class="section feature" id="productos"><div class="container">
  <div class="sec-head"><h2>{E(P["h2"])}</h2><p>{E(P["p"])}</p></div>
  <div class="{cls}">{"".join(cards)}</div>
  <p class="offer-note prod-note">{E(P["note"])}</p>
</div></section>

<section class="offers" id="como-pagar"><div class="container">
  <div class="sec-head"><h2>{E(P["pay_h2"])}</h2><p>{E(P["pay_p"])}</p></div>
  <div class="pay-in{" pay-2" if not P["pay_int"] else ""}">
    <div><h3>{E(P["pay_cr"])}</h3><ul class="offer-list">{"".join("<li>"+E(x)+"</li>" for x in P["pay_cr_l"])}</ul></div>
    {ints}
    <div class="pay-steps"><ol class="steps">{steps}</ol>
      <a class="btn btn-outline" href="{wa_link(lang, P["pay_wa_msg"], P["pay_wa_msg"])}" target="_blank" rel="noopener">{E(P["pay_wa"])} →</a></div>
  </div>
</div></section>'''

# ------------------------------------------------------------------ ALIMENTACIÓN
def food(lang):
    f = FOOD[lang]; L = lambda a, b: a if lang == "es" else b
    sup = "".join(f'<li>{icon(i)}<span>{E(t)}</span></li>' for i, t in f["supports"])
    items = "".join(f"<li>{E(x)}</li>" for x in f["rep_items"])
    progs = "".join(f'''<div class="feature-in">
    <div class="feature-img"><img src="/assets/img/{im}.webp" alt="{E(alt)}" width="1400" height="{788 if im == "salud-digestiva" else 933}" loading="lazy" decoding="async"></div>
    <div><p class="eyebrow">{E(f["prog_eyebrow"])}</p><h3 class="feature-title">{E(t)}</h3>
      <p>{E(d)}</p>
      <p class="feature-row"><span class="price price-lg">{E(price)}</span></p>
      <a class="btn btn-terra" href="{url(lang,k)}">{E(f["prog_cta"])} →</a></div></div>''' for k, im, t, d, price, alt in f["progs"])
    free = ""
    if lang == "es":   # programa gratuito por correo: SOLO español
        free = f'''<div class="offer">
    <span class="offer-ico">{icon("mail","ic ic-lg")}</span>
    <div><h3>{E(f["free_h"])}</h3><p class="offer-sub">{E(f["free_sub"])}</p>
      <p>{E(f["free_p"])}</p>
      <div class="offer-row"><span class="price price-lg">{E(f["free_price"])}</span></div>
      <form class="rm-form" data-ml="{LINKS["mailerlite_programa"]}" data-ok="{E(f["free_ok"])}" data-err="{E(f["free_err"])}" novalidate>
        <input type="email" name="fields[email]" required autocomplete="email" placeholder="{E(f["free_ph"])}" aria-label="{E(f["free_label"])}">
        <button type="submit">{E(f["free_cta"])}</button></form>
      <p class="offer-note" role="status" aria-live="polite" data-ml-msg></p></div>
  </div>'''
    offers_cls = "offers-in offers-3" if lang == "es" else "offers-in"
    return f'''{head(lang,"food",f["title"],f["desc"],"/assets/img/hero-alimentacion.webp")}
{header(lang,"food")}
<main id="main">
<section class="hero hero-page">
  <picture class="hero-media"><source media="(max-width: 760px)" srcset="/assets/img/hero-alimentacion-m.webp"><img src="/assets/img/hero-alimentacion.webp" alt="{E(f["hero_alt"])}" width="1400" height="700" fetchpriority="high"></picture>
  <div class="container hero-inner"><div class="hero-copy">
    <p class="eyebrow">{E(f["eyebrow"])}</p>
    <h1>{E(f["h1"])}</h1><p class="lead">{E(f["lead"])}</p>
    <a class="btn btn-primary" href="#productos">{E(f["cta"])} →</a>
    <ul class="supports">{sup}</ul></div></div>
</section>

{products_html(lang)}

<section class="section articles" id="articulos"><div class="container">
  <div class="art-head"><div><h2>{E(f["art_h2"])}</h2><p>{E(f["art_p"])}</p></div>
    <a class="more" href="{BLOG_BASE if lang=="es" else EN_BLOG}/" target="_blank" rel="noopener">{E(f["art_all"])} →</a></div>
  <div class="grid-3">{article_cards(lang,"food",f["art_read"])}</div>
</div></section>

</main>
{footer(lang)}
{tail(lang)}'''


# ------------------------------------------------------------------ TRANSPERSONAL / ESPIRITUAL
def spiritual(lang):
    f = SPIRIT[lang]
    cat = {r["id"]: r for r in catalog.build(lang)}
    course = SPIRITUAL_COURSES[lang]
    books = "".join(f'''<li><a class="book" href="{b["url"]}" target="_blank" rel="noopener sponsored" aria-label="{E(b["title"])} — {E(f["amazon_badge"])}">
        <span class="cover"><img src="{b["img"]}" alt="{E(f["cover_of"])}{E(b["title"])}" width="240" height="375" loading="lazy" decoding="async"><span class="badge">{E(f["amazon_badge"])} ↗</span></span>
        <span class="btitle">{E(b["title"])}</span></a></li>''' for b in [cat[i] for i in f["books_ids"]])
    return f'''{head(lang,"spiritual",f["title"],f["desc"],"/assets/img/espiritual.webp")}
{header(lang,"spiritual")}
<main id="main">
<section class="hero-split"><div class="container split-in">
  <div class="hero-copy">
    <p class="eyebrow">{E(f["eyebrow"])}</p>
    <h1>{E(f["h1"])}</h1><p class="lead">{E(f["lead"])}</p>
    <a class="btn btn-primary" href="#curso">{E(f["cta"])} →</a></div>
  <div class="arch"><picture><source media="(max-width: 760px)" srcset="/assets/img/espiritual-m.webp"><img src="/assets/img/espiritual.webp" alt="{E(f["hero_alt"])}" width="999" height="1120" fetchpriority="high"></picture></div>
</div></section>

<section class="section feature" id="curso"><div class="container feature-in">
  <div class="feature-img"><img src="/assets/img/{f["course_img"]}.webp" alt="{E(f["course_alt"])}" width="900" height="900" loading="lazy" decoding="async"></div>
  <div><p class="eyebrow">{E(f["course_eyebrow"])}</p><h2>{E(f["course_h2"])}</h2>
    <h3 class="feature-title">{E(course["title"])}</h3>
    <p>{E(f["course_p"])}</p>
    <p class="feature-row"><span class="price price-lg">{E(course["price"])}</span></p>
    <a class="btn btn-terra" href="{course["url"]}" target="_blank" rel="noopener">{E(f["course_cta"])} →</a></div>
</div></section>

<section class="section areas"><div class="container">
  <div class="sec-head"><h2>{E(f["books_h2"])}</h2><p>{E(f["books_p"])}</p></div>
  <ul class="books books-3">{books}</ul>
</div></section>

<section class="section articles" id="articulos"><div class="container">
  <div class="art-head"><div><h2>{E(f["art_h2"])}</h2><p>{E(f["art_p"])}</p></div>
    <a class="more" href="{BLOG_BASE if lang=="es" else EN_BLOG}/" target="_blank" rel="noopener">{E(f["art_all"])} →</a></div>
  <div class="grid-3">{article_cards(lang,"spiritual",f["art_read"])}</div>
</div></section>

<section class="bridge bridge-note"><div class="container"><p>{E(f["note"])}</p></div></section>
</main>
{footer(lang)}
{tail(lang)}'''


# ------------------------------------------------------------------ MI TRANSFORMACIÓN SALUDABLE (producto de pago; solo español)
def transformacion():
    lang = "es"
    title = "Mi transformación saludable | Salud Integral"
    desc = "Actividad interactiva de Salud Integral para aprender a armar tu plato, entender las porciones, leer etiquetas y crear tu plan personalizado en PDF."
    css = '<link rel="stylesheet" href="/assets/transformacion/app.css">'
    scripts = "".join(f'<script src="/assets/transformacion/{n}.js"></script>' for n in ("data", "core", "stations-a", "stations-b"))
    return f'''{head(lang,"transform",title,desc,"/assets/img/transformacion-plato.webp",alts_on=False,noindex=True,extra_css=css)}
{header(lang,"transform")}
<main id="main" class="ts-app">
<section class="ts-hero"><img src="/assets/img/transformacion-plato.webp" alt="" width="1400" height="612" fetchpriority="high">
  <div class="container"><p class="eyebrow">SALUD INTEGRAL</p><h1>Mi <em>transformación</em> saludable</h1>
  <p>Aprende haciendo: arma tu plato, mide tus porciones, lee etiquetas, elige cómo moverte y organiza tu semana. Al final te llevas un plan personalizado en PDF que puedes llenar en pantalla.</p>
  <p class="ts-fine">Contenido educativo. No sustituye la atención de profesionales de la salud.</p></div></section>
<div class="ts-nav"><div class="container" id="ts-nav"></div></div>
<div class="container ts-top" id="ts-top"><div id="ts-root"></div>
<p class="center"><button type="button" class="ts-reset" id="ts-reset">Borrar mis elecciones de este dispositivo</button></p></div>
<div id="ts-toast" role="status" aria-live="polite"></div>
</main>
{footer(lang)}
<script src="/assets/js/site.js" defer></script>
{scripts}
</body></html>'''

# ------------------------------------------------------------------ escritura
def write(path, content):
    full = os.path.join(DIST, path.lstrip("/"))
    os.makedirs(os.path.dirname(full), exist_ok=True)
    open(full, "w", encoding="utf-8").write(content)

def page_path(lang, key):
    return url(lang, key) + "index.html"

def data_js(lang):
    cat = catalog.build(lang)
    art = next(r["url"] for r in cat if r["id"] == "art-2am")
    a = assistant.build(lang)
    blob = json.dumps(a, ensure_ascii=False).replace("__ART2AM__", art)
    return "window.SI_DATA=" + blob + ";window.SI_CATALOG=" + json.dumps(cat, ensure_ascii=False) + ";"

BUILDERS = {"home": home, "food": food, "spiritual": spiritual}

def main():
    if os.path.exists(DIST): shutil.rmtree(DIST)
    os.makedirs(DIST)
    shutil.copytree(os.path.join(ROOT, "static"), os.path.join(DIST, "assets"))
    built = []
    for key, fn in BUILDERS.items():
        for lang in ("es", "en"):
            write(page_path(lang, key), fn(lang)); built.append((lang, key))
    write(page_path("es", "transform"), transformacion())   # producto de pago: fuera del sitemap, noindex
    for lang in ("es", "en"):
        write(f"/assets/js/data-{lang}.js", data_js(lang))
    urls = "".join(f"<url><loc>{SITE_URL}{url(l,k)}</loc></url>" for l, k in built)
    write("/sitemap.xml", f'<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">{urls}</urlset>')
    shutil.copy(os.path.join(ROOT, "static", "img", "favicon.ico"), os.path.join(DIST, "favicon.ico"))
    write("/robots.txt", f"User-agent: *\nAllow: /\nSitemap: {SITE_URL}/sitemap.xml\n")
    write("/_headers", "/assets/*\n  Cache-Control: public, max-age=31536000, immutable\n/*\n  X-Content-Type-Options: nosniff\n  Referrer-Policy: strict-origin-when-cross-origin\n")
    print("páginas:", built)

if __name__ == "__main__":
    main()
