# -*- coding: utf-8 -*-
"""Datos de Romero (asistente) y del Orientador. Un solo motor, un solo catálogo.
Fuente: Documento 'Romero' + 'Hábitos y bienestar' (6 preguntas). La MATRIZ respuesta→recurso
es una propuesta inicial basada en títulos/temas reales; se ajusta editando 'tags' abajo."""
from config import CONTACT, LINKS, url, wa_link

def build(lang):
    es = lang == "es"
    L = lambda a, b: a if es else b
    u = lambda k: url(lang, k)
    wa = wa_link(lang, "Hola Tatiana, vengo de saludintegral.site y tengo una consulta.",
                       "Hello Tatiana, I'm coming from saludintegral.site and I have a question.")

    # ---------- ORIENTADOR: 6 preguntas (Hábitos y bienestar, §3). tags = puntos por tema/formato ----------
    Q = [
      dict(q=L("¿Qué le gustaría cambiar o entender mejor en este momento?", "What would you like to change or understand better right now?"), opts=[
        (L("Mis hábitos cotidianos", "My everyday habits"), {"habitos": 3}),
        (L("Mi relación con la alimentación", "My relationship with food"), {"alimentacion": 3}),
        (L("El pensamiento que no consigo apagar", "The thought I can't switch off"), {"mente": 3}),
        (L("Mi manera de manejar el estrés", "How I handle stress"), {"estres": 3}),
        (L("No estoy seguro/a; quiero explorar", "I'm not sure; I want to explore"), {"explorar": 2})]),
      dict(q=L("¿Dónde nota que más le cuesta mantener un cambio?", "Where do you find it hardest to sustain a change?"), opts=[
        (L("Empezar", "Getting started"), {"habitos": 1, "f_autonomo": 1}),
        (L("Ser constante", "Staying consistent"), {"habitos": 2}),
        (L("No exigirme demasiado", "Not being too hard on myself"), {"mente": 1, "estres": 1}),
        (L("Saber qué hacer", "Knowing what to do"), {"f_articulo": 1, "f_libro": 1}),
        (L("Entender qué me está pasando", "Understanding what's going on with me"), {"mente": 1, "personal": 1})]),
      dict(q=L("¿Qué tipo de recurso le gustaría recibir?", "What kind of resource would you like to receive?"), opts=[
        (L("Un libro para leer a mi ritmo", "A book to read at my own pace"), {"f_libro": 3}),
        (L("Un curso práctico", "A practical course"), {"f_curso": 3}),
        (L("Un recurso concreto", "A concrete resource"), {"f_articulo": 2, "f_informe": 1}),
        (L("Una mirada más personalizada", "A more personalized look"), {"f_informe": 2, "f_sesion": 1}),
        (L("Todavía no lo sé", "I don't know yet"), {})]),
      dict(q=L("¿Qué describe mejor lo que busca?", "What best describes what you're looking for?"), opts=[
        (L("Ideas sencillas para el día a día", "Simple ideas for everyday life"), {"habitos": 1, "f_articulo": 1}),
        (L("Comprender mis patrones", "Understanding my patterns"), {"mente": 1, "personal": 1}),
        (L("Prácticas de regulación y bienestar", "Regulation and wellbeing practices"), {"mente": 1, "estres": 1}),
        (L("Ordenar mis prioridades y decisiones", "Sorting out my priorities and decisions"), {"habitos": 1, "f_libro": 1}),
        (L("Explorar varias áreas", "Exploring several areas"), {"explorar": 1})]),
      dict(q=L("¿Cuánto acompañamiento quiere en este momento?", "How much support do you want right now?"), opts=[
        (L("Quiero hacerlo por mi cuenta", "I want to do it on my own"), {"f_autonomo": 2, "f_libro": 1, "f_articulo": 1}),
        (L("Quiero un recurso y luego decidir", "I want a resource, then I'll decide"), {"f_autonomo": 1}),
        (L("Me interesa una orientación personalizada", "I'm interested in personalized guidance"), {"f_informe": 2}),
        (L("Estoy abierto/a a una sesión individual", "I'm open to a one-on-one session"), {"f_sesion": 3})]),
      dict(q=L("¿Qué frase se parece más a su momento actual?", "Which phrase is closest to where you are now?"), opts=[
        (L("Necesito algo práctico", "I need something practical"), {"habitos": 1, "f_articulo": 1}),
        (L("Quiero entenderme mejor", "I want to understand myself better"), {"mente": 1, "personal": 1}),
        (L("Quiero dejar de dar vueltas a lo mismo", "I want to stop going around in circles"), {"mente": 2}),
        (L("Quiero construir hábitos que pueda sostener", "I want to build habits I can sustain"), {"habitos": 2}),
        (L("No sé exactamente; quiero explorar", "I'm not sure; I want to explore"), {"explorar": 1})]),
    ]

    UI = dict(
      guide_title=L("Orientador de Salud Integral", "Salud Integral Guide"),
      guide_intro=L("Responda unas preguntas breves. No es un test ni una evaluación: solo le ayudará a encontrar un punto de partida entre nuestros recursos.",
                    "Answer a few short questions. It is not a test or an assessment: it only helps you find a starting point among our resources."),
      start=L("Empezar", "Start"), back=L("Atrás", "Back"), close=L("Cerrar", "Close"),
      qcount=L("Pregunta {n} de {t}", "Question {n} of {t}"),
      result_h=L("Su punto de partida podría ser:", "Your starting point could be:"),
      result_lead=L("Por lo que ha seleccionado, este podría ser un buen punto de partida para usted.",
                    "Based on what you selected, this could be a good starting point for you."),
      why_h=L("Por qué encaja", "Why it fits"),
      alt_h=L("Otra opción para explorar", "Another option to explore"),
      other_route=L("¿Quiere explorar otra ruta? → Volver a recursos", "Want to explore another route? → Back to resources"),
      retry=L("Repetir las preguntas", "Retake the questions"),
      resources_url=u("resources"),
      disclaimer=L("El orientador sugiere recursos; no diagnostica ni sustituye atención profesional.",
                   "The guide suggests resources; it does not diagnose or replace professional care."),
    )

    # ---------- ROMERO ----------
    R = dict(
      name="Romero", role=L("Asistente de Salud Integral", "Salud Integral assistant"),
      launcher=L("¿Por dónde empiezo?", "Where do I start?"),
      open_label=L("Abrir el chat con Romero", "Open chat with Romero"),
      close_label=L("Cerrar el chat", "Close chat"),
      placeholder=L("Escriba aquí lo que busca…", "Type what you're looking for…"),
      send=L("Enviar", "Send"),
      note=L("Romero orienta hacia recursos. No diagnostica ni sustituye atención profesional.",
             "Romero points you to resources. It does not diagnose or replace professional care."),
      greet=L("Hola, soy Romero 🌿\n\nPuedo ayudarle a encontrar un buen punto de partida dentro de Salud Integral.",
              "Hi, I'm Romero 🌿\n\nI can help you find a good starting point within Salud Integral."),
      menu=[("quiz", L("🌿 Hacer el cuestionario", "🌿 Take the questionnaire")),
            ("tell", L("🔎 Cuénteme qué está buscando", "🔎 Tell me what you're looking for")),
            ("food", L("🥗 Explorar Alimentación", "🥗 Explore Food")),
            ("habits", L("🌱 Explorar Hábitos", "🌱 Explore Habits")),
            ("mind", L("🧠 Explorar Mente tranquila", "🧠 Explore Calm mind")),
            ("resources", L("📚 Ver recursos", "📚 See resources"))],
      tell_prompt=L("Con gusto. Cuénteme con sus palabras qué está buscando y le sugiero por dónde empezar.",
                    "Happy to. Tell me in your own words what you're looking for and I'll suggest where to start."),
      go=dict(
        food=dict(text=L("Puede comenzar por Alimentación consciente: allí encontrará contenidos y recursos sobre alimentación y hábitos.", "You can start with Mindful eating, where you'll find content and resources about eating and habits."),
                  btns=[(L("Explorar Alimentación", "Explore Food"), u("food")), (L("Ver el informe personalizado", "See the personalized report"), u("report"))]),
        habits=dict(text=L("Hábitos y bienestar reúne herramientas para observar sus rutinas y hacer cambios que pueda sostener.", "Habits & wellbeing gathers tools to observe your routines and make changes you can sustain."),
                    btns=[(L("Explorar Hábitos", "Explore Habits"), u("habits"))]),
        mind=dict(text=L("Si lo que busca es trabajar con esos pensamientos que vuelven una y otra vez, puede comenzar por Mente tranquila: herramientas de respiración, movimiento y observación. También existe el curso «Cuando tu cabeza no para», pensado justamente sobre este tema.", "If you're looking to work with thoughts that keep coming back, you can start with Calm mind: breathing, movement and observation tools."),
                  btns=[(L("Explorar Mente tranquila", "Explore Calm mind"), u("mind"))] + ([(L("Ver el curso", "View the course"), LINKS["payhip_course"])] if es else [])),
        resources=dict(text=L("Estos son los recursos disponibles: libros, curso online, informe personalizado y acompañamiento individual.", "Here are the available resources: books, online course, personalized report and one-on-one session."),
                       btns=[(L("Ver todos los recursos", "See all resources"), u("resources"))]),
        report=dict(text=L("El informe personalizado de alimentación cuesta USD 25 (₡11.000): usted completa un cuestionario previo y recibe un análisis con observaciones y recomendaciones prácticas. Se entrega en PDF, máximo 3 días. Es de finalidad educativa y de acompañamiento personal.", "The personalized eating report costs USD 25 (₡11,000): you complete a prior questionnaire and receive an analysis with practical observations and recommendations. It is delivered as a PDF, within 3 days at most. It is educational and for personal support."),
                     btns=[(L("Quiero mi informe", "I want my report"), u("report"))]),
        session=dict(text=L("El acompañamiento individual es una sesión online de 45 minutos, USD 50 (₡25.000). Es una opción, no una obligación: puede empezar por un recurso y decidir después.", "The one-on-one session is a 45-minute online session, USD 50 (₡25,000). It is an option, not an obligation: you can start with a resource and decide later."),
                     btns=[(L("Conocer el acompañamiento", "Learn about the session"), u("session"))]),
        course=dict(text=L("«Cuando tu cabeza no para» es un curso online práctico sobre rumiación mental: observar lo que ocurre en la mente sin juzgarlo, comprender el ciclo, usar la respiración y la atención corporal, y practicar en situaciones cotidianas. El precio se muestra en su página de Payhip.", "The course is the Magickal Kabbalah for Self Transformation Bundle (USD 33.77): a digital bundle with a main book on the theory and Kabbalah behind the practice, a full-color workbook for tracking personal data and drafting sigils, and two HD videos: a guide that paces a daily 21-minute practice and a tutorial on ritual technique."),
                    btns=[(L("Ver el curso", "View the bundle"), LINKS["payhip_course"] if es else LINKS["kabbalah_bundle_en"])]),
        books=dict(text=L("Tatiana es autora de libros que puede leer a su propio ritmo. Puede verlos todos en Amazon.", "Tatiana is the author of books you can read at your own pace. You can see them all on Amazon."),
                   btns=[(L("Ver los libros", "See the books"), u("resources")), (L("Ver en Amazon", "View on Amazon"), LINKS["amazon_author"])]),
        night=dict(text=L("Si sus pensamientos aparecen sobre todo antes de dormir, puede leer este artículo sobre la mente activa por la noche y luego explorar Mente tranquila.", "If your thoughts show up mostly before sleep, you can explore Calm mind. And if you are curious about how digestion and mood connect, you can read this article about the brain-gut axis."),
                   btns=[(L("Leer el artículo", "Read the article"), "__ART2AM__"), (L("Explorar Mente tranquila", "Explore Calm mind"), u("mind"))]),
        contact=dict(text=L(f"Puede escribirle a Tatiana por WhatsApp ({CONTACT['wa_display']}) o por correo (terapiaholisticacr@gmail.com).", f"You can write to Tatiana on WhatsApp ({CONTACT['wa_display']}) or by email (terapiaholisticacr@gmail.com)."),
                     btns=[(L("Escribir por WhatsApp", "Write on WhatsApp"), wa), (L("Página de contacto", "Contact page"), u("contact"))]),
        price=dict(text=L("Informe personalizado de alimentación: USD 25 (₡11.000). Acompañamiento individual (sesión online de 45 minutos): USD 50 (₡25.000). Los libros y el curso muestran su precio en Amazon y Payhip.", "Personalized eating report: USD 25 (₡11,000). One-on-one session (45-minute online session): USD 50 (₡25,000). Books show their price on Amazon. The Magickal Kabbalah bundle is USD 33.77."),
                   btns=[(L("Ver el informe", "See the report"), u("report")), (L("Ver el acompañamiento", "See the session"), u("session"))]),
        best=dict(text="¡Es la mejor! :) 🌿",
                  after=L("Si quiere información objetiva sobre su formación y su recorrido, puede verla aquí.", "If you'd like objective information about her training and background, you can see it here."),
                  btns=[(L("Conocer a Tatiana →", "Meet Tatiana →"), u("about"))]),
        creds=dict(text=L("Tatiana cuenta con un Máster Internacional en Psicología Holística y Transpersonal, título propio internacional. Puede conocer más sobre su formación y recorrido aquí.", "Tatiana holds an International Master's in Holistic and Transpersonal Psychology, an international own degree. You can learn more about her training and background here."),
                    btns=[(L("Sobre mí →", "About →"), u("about"))]),
        clinical=dict(text=L("No puedo diagnosticar ni interpretar síntomas, y esto no reemplaza la atención de un profesional de la salud. Si lo que describe le preocupa, lo mejor es consultar con un profesional. Si quiere, puedo mostrarle recursos generales de bienestar.", "I can't diagnose or interpret symptoms, and this doesn't replace care from a health professional. If what you describe worries you, it's best to consult one. If you'd like, I can show you general wellbeing resources."),
                       btns=[(L("Hacer el cuestionario", "Take the questionnaire"), "__QUIZ__"), (L("Ver recursos", "See resources"), u("resources"))]),
        crisis=dict(text=L("Lamento que esté pasando por algo así. Yo no puedo ayudarle con esto, pero usted merece apoyo ahora: comuníquese con el 911 (Costa Rica) o con el número de emergencias de su país, o acuda a la persona de confianza más cercana.", "I'm sorry you're going through something like this. I can't help with this, but you deserve support right now: please contact 911 (Costa Rica) or your local emergency number, or reach out to the closest person you trust."),
                    btns=[]),
        greeting=dict(text=L("¡Hola! 🌿 ¿En qué puedo orientarle hoy?", "Hello! 🌿 How can I point you in the right direction today?"), btns=[]),
        thanks=dict(text=L("Con gusto. Aquí estaré si necesita algo más. 🌿", "My pleasure. I'll be here if you need anything else. 🌿"), btns=[]),
        fallback=dict(text=L("No tengo esa información con certeza, y prefiero no inventarla. Puedo ayudarle con los recursos de Salud Integral o puede escribirle directamente a Tatiana.", "I don't have that information with certainty, and I'd rather not make it up. I can help with Salud Integral's resources, or you can write to Tatiana directly."),
                      btns=[(L("Hacer el cuestionario", "Take the questionnaire"), "__QUIZ__"), (L("Contactar a Tatiana", "Contact Tatiana"), u("contact"))]),
      ),
      more=L("¿Quiere seguir explorando?", "Would you like to keep exploring?"),
      followups=dict(
        mind=L("¿Le gustaría que le sugiera también un libro o un artículo sobre este tema?", "Would you like a book or an article on this topic as well?"),
        food=L("Si prefiere una mirada personalizada, puedo contarle sobre el informe.", "If you prefer a personalized look, I can tell you about the report."),
        habits=L("También puedo orientarle hacia un libro o el cuestionario.", "I can also point you to a book or the questionnaire.")),
      yes=["si", "sí", "claro", "ok", "dale", "yes", "sure", "please", "por favor", "quiero", "want"],
      # patrones (regex, minúsculas, sin tildes) → clave de respuesta. Orden = prioridad.
      intents=[
        ("crisis",   L(r"suicid|quitarme la vida|quitarme la existencia|hacerme dano|hacerme un dano|hacer me dano|me quiero hacer dano|lastimarme|autolesion|cortarme las venas|no quiero vivir|no quiero seguir viviendo|ya no quiero seguir|quiero morir|quiero morirme|me quiero morir|matarme|acabar con mi vida|terminar con mi vida|desaparecer para siempre", r"suicid|kill myself|hurt myself|harm myself|self.?harm|end my life|take my life|want to die|wanna die|don.?t want to live|do not want to live|cut myself|better off dead|no reason to live")),
        ("clinical", L(r"diagnos|ansiedad|depresi|enfermedad|sintoma|medicament|pastilla|gastritis|colitis|reflujo|cancer|diabetes|tiroid|trastorno|tdah|panico|dolor de cabeza|duele la cabeza|migrana|vomit|atracon", r"diagnos|anxiety|depress|disease|illness|symptom|medicat|gastritis|colitis|reflux|cancer|diabetes|thyroid|disorder|adhd|panic|headache|migraine|vomit|binge")),
        ("creds",    L(r"psicolog|psicoterap|terapeuta|titulo|credencial|habilitad|colegiad|estudios de|formacion", r"psycholog|psychotherap|therapist|degree|credential|licens|qualif|training|certif")),
        ("price",    L(r"precio|cuanto cuesta|cuanto vale|costo|tarifa|cobra", r"price|how much|cost|fee\b|rate|charge")),
        ("contact",  L(r"contacto|contactar|whatsapp|telefono|correo|email|escribir a tatiana|escribirle a tatiana|escribirle|hablar con tatiana|comunicarme|numero", r"contact|whatsapp|phone|email|write to tatiana|talk to tatiana|speak to tatiana|reach tatiana|number")),
        ("session",  L(r"sesion|cita|agendar|acompanamiento|reservar", r"session|appointment|book a|schedule|one.on.one|coaching")),
        ("report",   L(r"informe|reporte|cuestionario de alimentacion|analisis personalizado", r"report|personalized analysis|eating questionnaire")),
        ("course",   L(r"curso|payhip|clase online", r"course|payhip|online class")),
        ("books",    L(r"libro|amazon|leer|autora|kindle", r"book|amazon|read|author|kindle")),
        ("best",     L(r"es buena|es bueno|buena coach|buena profesional|recomiend|vale la pena|confiable|confiar", r"is she good|good coach|good therapist|recommend|worth it|trust|reliable")),
        ("night",    L(r"dormir|noche|madrugada|insomnio|desvel|antes de acostarme|2 de la manana", r"sleep|night|insomnia|awake|bedtime|2 a\.?m")),
        ("mind",     L(r"pensamiento|dar vueltas|darle vueltas|rumia|mente|cabeza no para|preocup|estres|calma|pausa|respirar|respiracion", r"thought|overthink|ruminat|mind|worry|stress|calm|pause|breath")),
        ("food",     L(r"comer|comida|alimentacion|peso|bajar de peso|dieta|digest|intestin|kefir|fermentad|nutricion|emocional", r"eat|food|eating|overeat|weight|diet|digest|gut|kefir|ferment|nutrition|emotional")),
        ("habits",   L(r"habito|rutina|constancia|disciplina|motivacion|movimiento|ejercicio|decision", r"habit|routine|consisten|discipline|motivation|movement|exercise|decision")),
        ("resources",L(r"recurso|herramienta|producto|que ofrecen|que tienen", r"resource|tool|product|what do you offer|what do you have")),
        ("greeting", L(r"^(hola|buenas|buenos dias|buen dia|hey|saludos)\b", r"^(hi|hello|hey|good morning|good afternoon)\b")),
        ("thanks",   L(r"gracias|muy amable", r"thank|thanks")),
      ],
    )
    return dict(lang=lang, questions=[dict(q=q["q"], opts=[dict(label=o[0], tags=o[1]) for o in q["opts"]]) for q in Q],
                ui=UI, romero=R, wa=wa)
