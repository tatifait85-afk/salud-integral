# -*- coding: utf-8 -*-
"""Página Transpersonal / Espiritual. No existe especificación en el Documento Maestro: el texto es nuevo y se limita a lo que
muestran las fichas reales (cursos, libros, artículos) y a los criterios de lenguaje (sin promesas clínicas)."""
SPIRIT = {
"es": dict(
  title="Transpersonal y espiritual | Salud Integral",
  desc="Meditación, Cábala práctica, Ho'oponopono y psicología transpersonal: lecturas, libros y un curso para explorar la dimensión espiritual del bienestar.",
  eyebrow="TRANSPERSONAL · ESPIRITUAL", h1="Transpersonal y espiritual",
  lead="Un espacio para explorar la dimensión espiritual del bienestar: meditación, Cábala práctica, Ho'oponopono y psicología transpersonal. Lecturas, libros y un curso para recorrerlo a su propio ritmo.",
  cta="Explorar recursos", hero_alt="Mujer sonriente meditando al amanecer frente al mar, con un diseño de luz geométrico detrás",
  course_eyebrow="CURSO", course_h2="Cábala práctica",
  course_p="Curso en línea que aplica la Cábala a la prosperidad: meditación, visualización, oración con nombres divinos y trabajo con las creencias limitantes sobre el dinero. Incluye estrategias prácticas para manejar las finanzas personales, un libro de Salmos en hebreo con pronunciación y traducción al español, un ritual en video y un sigilo con nombres divinos.",
  course_cta="Ver el curso", course_img="curso-kabbalah-es", course_alt="Portada del curso Despierta tu potencial de abundancia con la Cábala Hermética Práctica",
  books_h2="Libros para leer a su ritmo", books_p="Lecturas de Tatiana Fait Shaw sobre Ho'oponopono, neurociencia y psicología transpersonal.",
  art_h2="Artículos para profundizar", art_p="Lecturas del blog para recorrer a su propio ritmo.", art_all="Ver todos los artículos", art_read="Leer artículo",
  note="Estos recursos tienen finalidad educativa y de desarrollo personal. No sustituyen la atención de profesionales de la salud.",
  books_ids=["libro-3","libro-4","libro-5"], amazon_badge="Ver en Amazon", cover_of="Portada de ",
),
"en": dict(
  title="Transpersonal and spiritual | Salud Integral",
  desc="Meditation, practical Kabbalah, Ho'oponopono and transpersonal psychology: readings, books and a course to explore the spiritual dimension of wellbeing.",
  eyebrow="TRANSPERSONAL · SPIRITUAL", h1="Transpersonal and spiritual",
  lead="A space to explore the spiritual dimension of wellbeing: meditation, practical Kabbalah, Ho'oponopono and transpersonal psychology. Readings, books and a course to move through at your own pace.",
  cta="Explore resources", hero_alt="Smiling woman meditating at sunrise by the sea, with a geometric light design behind her",
  course_eyebrow="COURSE", course_h2="Practical Kabbalah",
  course_p="A digital bundle for self-transformation through Magickal Kabbalah: a main book (print or PDF) on the theory and Kabbalah behind the practice, a full-color workbook for tracking personal data and drafting sigils, and two HD videos, one that guides a daily 21-minute practice and one that teaches ritual technique.",
  course_cta="View the bundle", course_img="curso-kabbalah-en", course_alt="Cover of the Magickal Kabbalah for Self Transformation Bundle",
  books_h2="Books to read at your own pace", books_p="Readings by Tatiana Fait Shaw on Ho'oponopono, neuroscience and Magickal Kabbalah.",
  art_h2="Articles to go deeper", art_p="Blog readings to explore at your own pace.", art_all="See all articles", art_read="Read article",
  note="These resources are for educational and personal-development purposes. They do not replace care from health professionals.",
  books_ids=["libro-1","libro-4","libro-5"], amazon_badge="View on Amazon", cover_of="Cover of ",
),
}
