/* Salud Integral — comportamiento general (menú móvil) */
(function () {
  var btn = document.querySelector('.menu-btn'), nav = document.getElementById('nav');
  if (!btn || !nav) return;
  function set(open) { nav.classList.toggle('open', open); btn.setAttribute('aria-expanded', open ? 'true' : 'false'); }
  btn.addEventListener('click', function () { set(!nav.classList.contains('open')); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') set(false); });
  nav.addEventListener('click', function (e) { if (e.target.tagName === 'A') set(false); });
})();

/* Programa gratuito por correo (MailerLite). Solo existe en la versión en español. */
(function () {
  var form = document.querySelector('form[data-ml]'); if (!form) return;
  var msg = document.querySelector('[data-ml-msg]'), btn = form.querySelector('button');
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var email = form.querySelector('input[type=email]');
    if (!email.value || !email.checkValidity()) { email.focus(); email.reportValidity && email.reportValidity(); return; }
    var fd = new FormData(); fd.append('fields[email]', email.value.trim()); fd.append('ml-submit', '1'); fd.append('anticsrf', 'true');
    btn.disabled = true;
    fetch(form.getAttribute('data-ml'), { method: 'POST', body: fd })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (d && d.success) { msg.textContent = form.getAttribute('data-ok'); form.reset(); }
        else { msg.textContent = form.getAttribute('data-err'); }
      })
      .catch(function () { msg.textContent = form.getAttribute('data-err'); })
      .then(function () { btn.disabled = false; });
  });
})();
