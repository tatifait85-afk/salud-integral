/* Mi transformación saludable · generador del PDF personalizado y rellenable (pdf-lib se carga solo al descargar) */
(function (W) {
  'use strict';
  var TS = W.TS, D = TS.D;
  var PL = W.PDFLib;

  /* ------------------------------------------------------------------ texto seguro para las fuentes estándar (WinAnsi) */
  var MAP = { '→': '->', '←': '<-', '≈': '~', '⅓': '1/3', '⅔': '2/3', '✓': 'x', '₡': 'CRC ', '⇄': '<>', '’': "'", '‘': "'", '“': '"', '”': '"', '…': '...', '—': '-', '–': '-', '•': '-', '♥': '', '♡': '', '×': 'x' };
  var KEEP = { '¼': 1, '½': 1, '¾': 1, '·': 1, '¿': 1, '¡': 1 };
  function san(s) {
    s = String(s == null ? '' : s); var o = '';
    for (var i = 0; i < s.length; i++) {
      var ch = s[i], c = s.charCodeAt(i);
      if (c === 10) o += '\n';
      else if (c < 32) o += ' ';
      else if (c <= 255) o += ch;
      else if (MAP[ch] != null) o += MAP[ch];
      else o += '';
    }
    return o;
  }

  var C = {
    cream: [0.984, 0.973, 0.945], ivory: [0.969, 0.953, 0.91], forest: [0.09, 0.227, 0.118], olive: [0.373, 0.451, 0.094], sage: [0.659, 0.753, 0.541],
    mint: [0.863, 0.91, 0.824], sand: [0.843, 0.78, 0.647], wood: [0.545, 0.42, 0.29], terra: [0.663, 0.333, 0.184], ink: [0.227, 0.173, 0.133],
    soft: [0.353, 0.29, 0.243], line: [0.85, 0.83, 0.77], white: [1, 1, 1],
    title1: [0.149, 0.247, 0.149], title2: [0.455, 0.494, 0.306], name: [0.365, 0.42, 0.282]
  };
  function rgb(a) { return PL.rgb(a[0], a[1], a[2]); }
  function hex(h) { h = h.replace('#', ''); return PL.rgb(parseInt(h.substr(0, 2), 16) / 255, parseInt(h.substr(2, 2), 16) / 255, parseInt(h.substr(4, 2), 16) / 255); }

  /* ------------------------------------------------------------------ SVG -> PNG (para los iconos de los alimentos) */
  var pngCache = {};
  function svgToPng(id) {
    if (pngCache[id]) return pngCache[id];
    pngCache[id] = new Promise(function (ok, bad) {
      var svg = D.foodSVG(id, 128), img = new Image(), url = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
      img.onload = function () {
        try {
          var cv = document.createElement('canvas'); cv.width = 192; cv.height = 192; var cx = cv.getContext('2d'); cx.drawImage(img, 0, 0, 192, 192);
          cv.toBlob(function (b) { b.arrayBuffer().then(function (ab) { ok(new Uint8Array(ab)); }); }, 'image/png');
        } catch (e) { bad(e); }
      };
      img.onerror = function () { bad(new Error('icono ' + id)); };
      img.src = url;
    });
    return pngCache[id];
  }

  /* ------------------------------------------------------------------ constructor del documento */
  var A4W = 595.28, A4H = 841.89, M = 46, CW = A4W - 2 * M;

  function Builder(doc, fonts) {
    this.doc = doc; this.f = fonts; this.form = doc.getForm(); this.pages = []; this.n = 0; this.cur = null; this.y = 0; this.fieldN = 0;
  }
  Builder.prototype.page = function (title) {
    var p = this.doc.addPage([A4W, A4H]);
    p.drawRectangle({ x: 0, y: 0, width: A4W, height: A4H, color: rgb(C.cream) });
    p.drawRectangle({ x: 0, y: A4H - 6, width: A4W, height: 6, color: rgb(C.sage) });
    p.drawText(san('Mi transformación saludable'), { x: M, y: A4H - 30, size: 8.5, font: this.f.sansB, color: rgb(C.olive) });
    var w = this.f.sans.widthOfTextAtSize('Salud Integral', 8.5);
    p.drawText('Salud Integral', { x: A4W - M - w, y: A4H - 30, size: 8.5, font: this.f.sans, color: rgb(C.soft) });
    p.drawLine({ start: { x: M, y: A4H - 38 }, end: { x: A4W - M, y: A4H - 38 }, thickness: 0.6, color: rgb(C.line) });
    this.cur = p; this.pages.push(p); this.y = A4H - 64;
    if (title) this.h1(title);
    return p;
  };
  Builder.prototype.need = function (h, title) { if (this.y - h < 56) this.page(title || null); };
  Builder.prototype.wrap = function (text, font, size, width) {
    var out = [], paras = san(text).split('\n');
    paras.forEach(function (para) {
      var words = para.split(/\s+/).filter(Boolean), line = '';
      words.forEach(function (w) {
        var t = line ? line + ' ' + w : w;
        if (font.widthOfTextAtSize(t, size) > width && line) { out.push(line); line = w; } else line = t;
      });
      out.push(line);
    });
    return out;
  };
  Builder.prototype.h1 = function (t, sub) {
    var p = this.cur; p.drawText(san(t), { x: M, y: this.y - 22, size: 26, font: this.f.serifB, color: rgb(C.forest) }); this.y -= 34;
    p.drawLine({ start: { x: M, y: this.y }, end: { x: M + 46, y: this.y }, thickness: 2, color: rgb(C.olive) }); this.y -= 18;
    if (sub) this.p(sub, { color: C.soft, size: 10.5 });
  };
  Builder.prototype.h2 = function (t) { this.need(40); this.cur.drawText(san(t), { x: M, y: this.y - 14, size: 14.5, font: this.f.serifB, color: rgb(C.forest) }); this.y -= 24; };
  Builder.prototype.p = function (t, o) {
    o = o || {}; var size = o.size || 10.5, font = o.font || this.f.sans, lh = o.lh || size * 1.45, x = o.x == null ? M : o.x, width = o.w || (CW - (x - M));
    var lines = this.wrap(t, font, size, width), self = this;
    lines.forEach(function (ln) { self.need(lh + 4); self.cur.drawText(ln, { x: x, y: self.y - size, size: size, font: font, color: rgb(o.color || C.ink) }); self.y -= lh; });
    this.y -= (o.gap == null ? 5 : o.gap);
  };
  Builder.prototype.bullets = function (list, o) {
    var self = this; o = o || {};
    list.forEach(function (t) {
      var size = o.size || 10.5, lines = self.wrap(t, self.f.sans, size, CW - 16);
      self.need(lines.length * size * 1.45 + 4);
      self.cur.drawCircle({ x: M + 4, y: self.y - size * 0.62, size: 2, color: rgb(C.olive) });
      lines.forEach(function (ln) { self.cur.drawText(ln, { x: M + 14, y: self.y - size, size: size, font: self.f.sans, color: rgb(C.ink) }); self.y -= size * 1.45; });
      self.y -= 2;
    });
    this.y -= 4;
  };
  Builder.prototype.box = function (x, y, w, h, o) {
    o = o || {}; this.cur.drawRectangle({ x: x, y: y, width: w, height: h, color: rgb(o.fill || C.white), borderColor: rgb(o.border || C.line), borderWidth: o.bw == null ? 0.8 : o.bw, borderOpacity: 1 });
  };
  Builder.prototype.chip = function (x, y, text, o) {
    o = o || {}; var size = o.size || 9, w = this.f.sansB.widthOfTextAtSize(san(text), size) + 14;
    this.cur.drawRectangle({ x: x, y: y, width: w, height: 17, color: rgb(o.fill || C.mint), borderColor: rgb(o.border || C.sage), borderWidth: 0.6 });
    this.cur.drawText(san(text), { x: x + 7, y: y + 5, size: size, font: this.f.sansB, color: rgb(o.color || C.forest) });
    return w;
  };
  Builder.prototype.chips = function (list, o) {
    var self = this, x = M; if (!list.length) return;
    this.need(26);
    list.forEach(function (t) {
      var w = self.f.sansB.widthOfTextAtSize(san(t), 9) + 14;
      if (x + w > A4W - M) { x = M; self.y -= 22; self.need(24); }
      self.chip(x, self.y - 17, t, o); x += w + 6;
    });
    this.y -= 26;
  };
  Builder.prototype.field = function (name, x, y, w, h, value, o) {
    o = o || {}; this.fieldN++;
    var f = this.form.createTextField(name + '_' + this.fieldN);
    if (o.multi !== false) f.enableMultiline();
    f.setText(san(value || ''));
    f.addToPage(this.cur, { x: x, y: y, width: w, height: h, font: this.f.sans, textColor: rgb(C.ink), backgroundColor: rgb(o.bg || C.white), borderColor: rgb(o.border || C.sage), borderWidth: 0.7 });
    f.setFontSize(o.size || 9);
    return f;
  };
  Builder.prototype.check = function (name, x, y, size, checked) {
    this.fieldN++;
    var c = this.form.createCheckBox(name + '_' + this.fieldN);
    c.addToPage(this.cur, { x: x, y: y, width: size, height: size, borderColor: rgb(C.olive), backgroundColor: rgb(C.white), borderWidth: 1 });
    if (checked) c.check();
    return c;
  };

  /* ------------------------------------------------------------------ portada */
  async function cover(doc, fonts, state) {
    var bytes = await (await fetch('/assets/img/transformacion-portada.jpg')).arrayBuffer();
    var img = await doc.embedJpg(bytes), H = A4W * 1.5;
    var p = doc.addPage([A4W, H]);
    p.drawImage(img, { x: 0, y: 0, width: A4W, height: H });
    var cx = A4W / 2, k = A4W / 1024;                      // coordenadas tomadas del ejemplo (1024 x 1536)
    function Y(py) { return H - py * k; }
    function centered(text, font, size, py, color) {
      var w = font.widthOfTextAtSize(text, size); p.drawText(text, { x: cx - w / 2, y: Y(py), size: size, font: font, color: rgb(color) });
    }
    function fit(text, font, target, max) { var s = max; while (s > 8 && font.widthOfTextAtSize(text, s) > target) s -= 0.5; return s; }
    centered('Mi', fonts.serifI, 50, 272, C.title1);
    var t1 = 'Transformación', s1 = fit(t1, fonts.serifB, 535 * k, 66);
    centered(t1, fonts.serifB, s1, 384, C.title1);
    var t2 = 'Saludable', s2 = fit(t2, fonts.serifB, 490 * k, 68);
    centered(t2, fonts.serifB, s2, 472, C.title2);
    p.drawLine({ start: { x: cx - 165 * k, y: Y(525) }, end: { x: cx - 18 * k, y: Y(525) }, thickness: 0.7, color: rgb(C.sand) });
    p.drawLine({ start: { x: cx + 18 * k, y: Y(525) }, end: { x: cx + 165 * k, y: Y(525) }, thickness: 0.7, color: rgb(C.sand) });
    p.drawSvgPath('M0 -6 L5 0 L0 6 L-5 0 Z', { x: cx, y: Y(525), scale: 0.9 * k * 1.1, color: rgb(C.title2), borderWidth: 0 });
    var nm = san(state.name.trim()), sn = fit(nm, fonts.serif, 430 * k, 30);
    centered(nm, fonts.serif, sn, 596, C.name);
  }

  /* ------------------------------------------------------------------ plato (vector) */
  async function drawPlate(B, plate, x0, yTop, size) {
    var G = TS.plateGeom, k = size / 400, p = B.cur;
    function X(v) { return x0 + v * k; } function Yp(v) { return yTop - v * k; }
    p.drawCircle({ x: X(200), y: Yp(200), size: 188 * k, color: rgb(C.cream), borderColor: rgb(C.sand), borderWidth: 1.5 });
    p.drawCircle({ x: X(200), y: Yp(200), size: 176 * k, color: rgb(C.white), borderColor: hex('#EADFC6'), borderWidth: 0.8 });
    var soft = { veg: '#DCE8D2', protein: '#F3D9C9', starch: '#F2E4B8' };
    for (var k2 in G.SECT) {
      p.drawSvgPath(G.SECT[k2], { x: x0, y: yTop, scale: k, color: hex(soft[k2]), borderColor: rgb(C.white), borderWidth: 2 });
    }
    var hint = { veg: ['1/2 vegetales', 'sin almidón', 108, 196], protein: ['1/4 proteína', '', 274, 132], starch: ['1/4 almidón', '', 274, 276] };
    for (var g in hint) {
      var items = plate[g] || [], pos = TS.plateSlots(g, items.length), i;
      if (!items.length) {
        var h = hint[g], col = g === 'veg' ? C.olive : g === 'protein' ? C.terra : [0.725, 0.541, 0.118];
        var w = B.f.sansB.widthOfTextAtSize(san(h[0]), 8); p.drawText(san(h[0]), { x: X(h[2]) - w / 2, y: Yp(h[3]), size: 8, font: B.f.sansB, color: rgb(col) });
        if (h[1]) { var w2 = B.f.sans.widthOfTextAtSize(san(h[1]), 8); p.drawText(san(h[1]), { x: X(h[2]) - w2 / 2, y: Yp(h[3]) - 10, size: 8, font: B.f.sans, color: rgb(col) }); }
      }
      for (i = 0; i < items.length; i++) {
        var img = await B.doc.embedPng(await svgToPng(items[i])), s = pos[i].s * k;
        p.drawImage(img, { x: X(pos[i].x) - s / 2, y: Yp(pos[i].y) - s / 2, width: s, height: s });
      }
    }
  }

  /* ------------------------------------------------------------------ generación */
  function today() { var d = new Date(); return d.getDate() + ' de ' + ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'][d.getMonth()] + ' de ' + d.getFullYear(); }
  function listOf(a, map) { return a.map(map); }

  async function build(state) {
    TS.ensureWeek();
    var doc = await PL.PDFDocument.create();
    doc.setTitle(san('Mi transformación saludable - ' + state.name.trim()));
    doc.setAuthor('Salud Integral'); doc.setSubject('Plan educativo personalizado'); doc.setCreator('saludintegral.site'); doc.setLanguage('es-CR');
    var S = PL.StandardFonts;
    var fonts = {
      serif: await doc.embedFont(S.TimesRoman), serifB: await doc.embedFont(S.TimesRomanBold), serifI: await doc.embedFont(S.TimesRomanItalic),
      sans: await doc.embedFont(S.Helvetica), sansB: await doc.embedFont(S.HelveticaBold), sansI: await doc.embedFont(S.HelveticaOblique)
    };
    await cover(doc, fonts, state);
    var B = new Builder(doc, fonts), P = TS.byId;
    var goalsList = state.goals.length ? state.goals : D.GOALS.map(function (g) { return g.id; });

    /* ---- 2 · punto de partida */
    B.page('Mi punto de partida');
    B.p('Plan preparado para ' + state.name.trim() + ' · ' + today(), { color: C.soft, size: 10 });
    B.p('Este documento reúne lo que elegiste en la actividad: tu plato, tus porciones, tu guía de etiquetas, tu semana, tu lista de compras y tu movimiento. Es tuyo: se puede llenar en pantalla o imprimir, y puedes cambiarlo cuando quieras.', { gap: 10 });
    B.h2('Lo que quiero lograr');
    B.bullets(state.goals.length ? state.goals.map(function (g) { return P(D.GOALS, g).t; }) : ['Explorar toda la actividad a mi ritmo']);
    B.h2('Mis preferencias');
    var prefs = [];
    if (state.usual.length) prefs.push('Comidas de siempre: ' + state.usual.map(function (u) { return P(D.USUAL, u).t.toLowerCase(); }).join(', '));
    if (state.diets.length) prefs.push('Mi forma de comer: ' + state.diets.map(function (u) { return P(D.DIETS, u).t.toLowerCase(); }).join(', '));
    if (state.dislikes.trim()) prefs.push('Alimentos que no como o no me gustan: ' + state.dislikes.trim());
    if (state.time) prefs.push('Tiempo para cocinar: ' + P(D.TIMES, state.time).t.toLowerCase());
    if (state.budget) prefs.push('Presupuesto aproximado: ' + P(D.BUDGETS, state.budget).t.toLowerCase());
    B.bullets(prefs.length ? prefs : ['Sin preferencias indicadas: todo queda abierto para ajustar a mi gusto.']);
    if (state.commit.trim()) { B.h2('Mi compromiso'); B.box(M, B.y - 54, CW, 54, { fill: C.mint, border: C.sage }); B.p(state.commit.trim(), { x: M + 12, w: CW - 24, font: fonts.serifI, size: 12, color: C.forest }); B.y -= 18; }
    B.h2('Cómo usar este plan');
    B.bullets(['Empieza por una sola cosa: tu plato con la guía en una comida del día.', 'Las casillas y los cuadros de texto se llenan en pantalla o a mano.', 'Revisa tu registro de avances una vez por semana y ajusta con calma.', 'No hay metas perfectas: lo importante es lo que puedes sostener.']);

    /* ---- 3 · mi plato */
    B.page('Mi plato');
    B.p('La guía es orientativa: la mitad del plato con vegetales sin almidón, un cuarto con proteína y un cuarto con alimentos ricos en almidón. No es una regla; es una forma sencilla de organizar la comida.', { gap: 8 });
    var top = B.y;
    await drawPlate(B, state.plate, M, top, 230);
    var lx = M + 252, ly = top - 6;
    [['veg', 'Vegetales sin almidón (1/2)', C.olive], ['protein', 'Proteína (1/4)', C.terra], ['starch', 'Almidón (1/4)', [0.725, 0.541, 0.118]], ['extra', 'Al lado: fruta y complementos', C.wood]].forEach(function (g) {
      var items = state.plate[g[0]];
      B.cur.drawText(san(g[1]), { x: lx, y: ly - 10, size: 10.5, font: fonts.sansB, color: rgb(g[2]) }); ly -= 17;
      var txt = items.length ? items.map(function (i) { return D.FOODS[i].n; }).join(', ') : 'Sin elegir todavía';
      B.wrap(txt, fonts.sans, 10, A4W - M - lx).forEach(function (ln) { B.cur.drawText(ln, { x: lx, y: ly - 9, size: 10, font: fonts.sans, color: rgb(C.ink) }); ly -= 13; });
      ly -= 9;
    });
    B.y = top - 256;
    B.h2('Por qué esta distribución puede ayudar');
    B.bullets(['Los vegetales aportan fibra, color y variedad de nutrientes, y llenan buena parte del plato.', 'La proteína ayuda a sentirte satisfecha y a mantener tus músculos.', 'El almidón (arroz, frijoles, lentejas, papa, yuca, maíz, plátano) es tu fuente de energía. Ningún alimento con almidón está prohibido.', 'Si una comida no se sirve en plato (sopa, tacos, guiso), usa la misma idea: variedad y equilibrio.']);
    var preset = state.platePreset && P(D.PLATES, state.platePreset);
    if (preset) B.p('Mi ejemplo de partida: ' + preset.n + '. ' + preset.why, { font: fonts.sansI, color: C.soft, size: 10 });
    B.h2('Mi plato en práctica');
    B.p('Anota cómo armaste tu plato esta semana y qué te gustaría cambiar:', { size: 10 });
    B.field('mi_plato', M, B.y - 70, CW, 70, '', { size: 10 }); B.y -= 82;

    /* ---- 4 · porciones */
    B.page('Mis porciones');
    B.p('Una cosa es la porción de referencia, otra la cantidad que decides servirte y otra lo que necesita tu cuerpo. Estas medidas son una guía para observar, no una meta.', { gap: 8 });
    var cw = [150, 104, 90, 150];
    function row(y, h, vals, header) {
      var x = M;
      vals.forEach(function (v, i) {
        B.box(x, y - h, cw[i], h, { fill: header ? C.forest : C.white, border: C.line });
        var f = header || i === 0 ? fonts.sansB : fonts.sans;
        B.wrap(v, f, 8.5, cw[i] - 10).slice(0, 4).forEach(function (ln, j) { B.cur.drawText(ln, { x: x + 5, y: y - 11 - j * 10.5, size: 8.5, font: f, color: header ? rgb(C.white) : rgb(C.ink) }); });
        x += cw[i];
      });
    }
    B.need(30); row(B.y, 20, ['Alimento', 'Porción de referencia', 'Con la mano', 'Lo que quiero tener en cuenta'], true); B.y -= 20;
    var handTxt = { arroz: 'Mano en copa = 1/2 taza', veg: 'Puño = 1 taza cruda', proteina: 'Palma abierta', huevos: 'Por unidad', legumbres: 'Mano en copa = 1/2 taza', fruta: 'Puño = 1 fruta mediana', grasas: 'Uña del pulgar = 1 cdta' };
    D.PORTIONS.forEach(function (pt) {
      B.need(40); row(B.y, 36, [pt.n, pt.measure, handTxt[pt.id] || '', pt.alt.length > 60 ? pt.alt.split(' · ')[0] : pt.alt], false); B.y -= 36;
    });
    B.y -= 10; B.h2('Mis medidas');
    var any = false;
    D.MEASURE_ITEMS.forEach(function (m) {
      var cur = state.measures[m.id] || {}; B.need(54);
      B.cur.drawText(san(m.n), { x: M, y: B.y - 10, size: 10, font: fonts.sansB, color: rgb(C.forest) });
      B.cur.drawText(san('Referencia: ' + m.ref), { x: M + 230, y: B.y - 10, size: 9, font: fonts.sansI, color: rgb(C.soft) }); B.y -= 16;
      B.cur.drawText('Lo que suelo servirme', { x: M, y: B.y - 8, size: 8, font: fonts.sans, color: rgb(C.soft) });
      B.cur.drawText('Con qué medida quiero empezar a observar', { x: M + 250, y: B.y - 8, size: 8, font: fonts.sans, color: rgb(C.soft) });
      B.field('suelo_' + m.id, M, B.y - 28, 235, 18, cur.usual || '', { multi: false }); B.field('empezar_' + m.id, M + 250, B.y - 28, 247, 18, cur.start || '', { multi: false }); B.y -= 38; any = true;
    });

    /* ---- 5 · etiquetas */
    B.page('Mi guía para leer etiquetas');
    B.p('El nombre, el envase y la publicidad no cuentan toda la historia: hay que aprender a leer los datos.', { font: fonts.serifI, size: 13, color: C.forest, gap: 8 });
    B.h2('Cinco pasos, en este orden');
    B.bullets(['1. Tamaño de la porción: todos los números son por porción. Si comes el doble, todo se duplica.', '2. Azúcares añadidos: es la línea que más cuenta al comparar. Los azúcares naturales (fruta, leche) están en «azúcares totales».', '3. Fibra: más fibra suele ser buena señal. La fruta entera aporta fibra; el jugo casi no.', '4. Carbohidratos totales: incluyen almidones, azúcares y fibra; en el cuerpo se transforman en glucosa, que es una fuente de energía.', '5. Ingredientes: van de mayor a menor. Lo primero es lo que más hay; «integral» o «natural» en el frente no garantizan nada.']);
    B.p('Como guía general (FDA de EE. UU.), 5 % o menos del valor diario es poco y 20 % o más es mucho; el valor diario de azúcares añadidos de referencia son 50 g. Es una referencia general, no una meta personal.', { size: 9.5, color: C.soft });
    B.h2('Lo que practiqué');
    D.DUELS.forEach(function (d) {
      var ans = state.labels[d.id]; if (ans == null) return;
      B.need(46); var okk = ans === d.a;
      B.p(d.title + ' - ' + (okk ? 'lo identifiqué bien' : 'para recordar') + ': ' + d.e.split('. ').slice(0, 2).join('. ').replace(/\.?$/, '.'), { size: 9.5, gap: 4 });
    });
    B.h2('Mis revisiones al comprar');
    var revs = state.revisions.length ? state.revisions : D.REVISIONS.slice(0, 3).map(function (r) { return r.id; });
    revs.forEach(function (r) { B.need(20); B.check('rev_' + r, M, B.y - 14, 12, false); B.cur.drawText(san(P(D.REVISIONS, r).t), { x: M + 20, y: B.y - 12, size: 10.5, font: fonts.sans, color: rgb(C.ink) }); B.y -= 20; });
    B.y -= 6;
    B.p('La glucosa es un azúcar sencillo que circula en la sangre y que el cuerpo usa como energía; los carbohidratos de los alimentos se transforman en ella. Cómo cambia después de comer varía entre personas y depende de la comida completa. Si tienes diabetes u otra condición, tu equipo de salud define tu plan.', { size: 9.5, color: C.soft });

    /* ---- 6 · comidas */
    B.page('Mis comidas y sus alternativas');
    B.p('Estas son las comidas de tu semana. Cada una tiene opciones para variar sin salirte de tu estilo.', { gap: 8 });
    var seen = {};
    Object.keys(state.week.cells).forEach(function (k) { var c = state.week.cells[k]; if (!seen[c.m]) seen[c.m] = c; });
    var ids = Object.keys(seen);
    for (var mi = 0; mi < ids.length; mi++) {
      var meal = P(D.MEALS, ids[mi]), cell = seen[ids[mi]];
      B.need(54);
      B.cur.drawText(san(meal.n), { x: M, y: B.y - 11, size: 10.5, font: fonts.sansB, color: rgb(C.forest) }); B.y -= 15;
      var ingTxt = 'Lleva: ' + meal.ing.map(function (i) { return D.FOODS[i].n.toLowerCase(); }).join(', ') + '.';
      var alts = []; meal.ing.forEach(function (i) { if (D.SWAPS[i] && alts.length < 2) alts.push(D.FOODS[i].n.toLowerCase() + ' por ' + D.FOODS[D.SWAPS[i][0]].n.toLowerCase()); });
      B.p(ingTxt + (alts.length ? ' Alternativas: ' + alts.join('; ') + '.' : ''), { size: 9.5, color: C.soft, gap: 5 });
    }

    /* ---- 7 · semana (editable) */
    B.page('Mi plan semanal');
    B.p('Escribe encima de cualquier cuadro para cambiar una comida. Cada día tiene un hábito para practicar.', { gap: 6 });
    var cols = [52, 90, 90, 90, 90, 87], hx = M, hy = B.y;
    var heads = ['', 'Desayuno', 'Almuerzo', 'Merienda', 'Cena', 'Hábito del día'];
    heads.forEach(function (h, i) { B.box(hx, hy - 20, cols[i], 20, { fill: C.forest, border: C.forest }); B.cur.drawText(san(h), { x: hx + 5, y: hy - 14, size: 8.5, font: fonts.sansB, color: rgb(C.white) }); hx += cols[i]; });
    B.y = hy - 20; var wc = TS.weekCells();
    D.DAYS.forEach(function (d) {
      var rh = 74, x = M;
      B.need(rh + 4); var y = B.y;
      B.box(x, y - rh, cols[0], rh, { fill: C.mint, border: C.line }); B.cur.drawText(san(d.t), { x: x + 4, y: y - 14, size: 8.5, font: fonts.sansB, color: rgb(C.forest) }); x += cols[0];
      ['d', 'a', 'm', 'c'].forEach(function (sk, i) {
        B.box(x, y - rh, cols[i + 1], rh, { fill: C.white, border: C.line });
        B.field('plan_' + d.id + '_' + sk, x + 2, y - rh + 2, cols[i + 1] - 4, rh - 4, wc[d.id + '-' + sk], { size: 7.5, border: C.white });
        x += cols[i + 1];
      });
      B.box(x, y - rh, cols[5], rh, { fill: C.ivory, border: C.line });
      var hab = P(D.HABITS, state.habitsByDay[d.id]);
      B.field('habito_' + d.id, x + 2, y - rh + 2, cols[5] - 4, rh - 4, hab ? hab.t : '', { size: 7.5, border: C.ivory, bg: C.ivory });
      B.y -= rh;
    });
    B.y -= 10; B.p('Es una propuesta flexible: sin dieta rígida y sin un número de calorías universal. Ajusta las cantidades con tus medidas de la página «Mis porciones».', { size: 9, color: C.soft });

    /* ---- 8 · compras */
    B.page('Mi lista de compras');
    var sl = TS.shoppingList().map(function (g) { return { t: g.t, items: g.items.filter(function (i) { return !i.off; }) }; }).filter(function (g) { return g.items.length; });
    if (state.shopExtra.length) sl.push({ t: 'Otros que quiero agregar', items: state.shopExtra.map(function (t) { return { n: t, c: 0 }; }) });
    B.p('Marca cada producto a medida que lo vas poniendo en el carrito. Dejé fuera lo que ya tienes en casa.', { gap: 6 });
    var colW = CW / 2 - 8;
    sl.forEach(function (g) {
      B.need(40); B.h2(g.t); var startY = B.y, col = 0, rowY = B.y;
      g.items.forEach(function (it, i) {
        if (i % 2 === 0) { B.need(22); rowY = B.y; }
        var x = M + (i % 2) * (colW + 16);
        B.check('c_' + (it.id || 'x'), x, rowY - 14, 11, false);
        var label = it.n + (it.c > 1 ? ' (' + it.c + ' comidas)' : '');
        B.cur.drawText(san(label), { x: x + 18, y: rowY - 11.5, size: 10, font: fonts.sans, color: rgb(C.ink) });
        if (i % 2 === 1 || i === g.items.length - 1) B.y -= 19;
      });
      B.y -= 4;
    });

    /* ---- 9 · movimiento */
    B.page('Mi movimiento');
    var t = TS.moveTotals();
    B.p('Bloques cortos que se suman: cada minuto cuenta. Tú decides cuánto y cuándo; esta es solo tu propuesta.', { gap: 6 });
    B.box(M, B.y - 44, CW, 44, { fill: C.mint, border: C.sage });
    B.cur.drawText(String(t.day), { x: M + 14, y: B.y - 33, size: 28, font: fonts.serifB, color: rgb(C.forest) });
    B.cur.drawText('minutos al día', { x: M + 14 + fonts.serifB.widthOfTextAtSize(String(t.day), 28) + 8, y: B.y - 32, size: 11, font: fonts.sansB, color: rgb(C.forest) });
    B.cur.drawText(san(t.week + ' minutos en la semana  ·  Punto de partida: ' + (P(D.LEVELS, state.moveLevel) || {}).t), { x: M + 200, y: B.y - 30, size: 9.5, font: fonts.sans, color: rgb(C.ink) });
    B.y -= 58;
    if (!state.blocks.length) B.p('Todavía no armaste un horario. Usa el espacio de abajo para anotar tus bloques.', { color: C.soft });
    D.SLOTS.forEach(function (sl2) {
      var bl = state.blocks.filter(function (b) { return b.slot === sl2.id; });
      if (!bl.length) return; B.need(30 + bl.length * 30);
      B.cur.drawText(san(sl2.t), { x: M, y: B.y - 11, size: 11, font: fonts.sansB, color: rgb(C.olive) }); B.y -= 18;
      bl.forEach(function (b) {
        var m = P(D.MOVES, b.move), lines = B.wrap(m.L[state.moveLevel], fonts.sans, 9.5, CW - 110);
        B.need(lines.length * 12 + 10);
        B.cur.drawText(san(m.n + ' - ' + b.min + ' min'), { x: M + 8, y: B.y - 10, size: 10, font: fonts.sansB, color: rgb(C.ink) });
        lines.forEach(function (ln, i) { B.cur.drawText(ln, { x: M + 150, y: B.y - 10 - i * 12, size: 9.5, font: fonts.sans, color: rgb(C.soft) }); });
        B.y -= Math.max(18, lines.length * 12 + 6);
      });
      B.y -= 4;
    });
    B.h2('Mis días');
    B.chips(D.DAYS.filter(function (d) { return state.moveDays.indexOf(d.id) > -1; }).map(function (d) { return d.t; }));
    B.h2('Mis notas de movimiento');
    B.field('notas_mov', M, B.y - 70, CW, 70, '', { size: 10 }); B.y -= 82;
    B.p('Si tienes una condición médica, dolor o dudas, consulta con tu profesional de salud antes de cambiar tu actividad.', { size: 9, color: C.soft });

    /* ---- 10-11 · registro de avances */
    var habs = goalsList.map(function (g) { return P(D.HABITS, P(D.GOALS, g).h); }).filter(Boolean);
    ['agua', 'pausa'].forEach(function (h) { if (habs.length < 4 && !habs.some(function (x) { return x.id === h; })) habs.push(P(D.HABITS, h)); });
    var dl = ['L', 'M', 'X', 'J', 'V', 'S', 'D'];
    for (var wk = 1; wk <= 4; wk++) {
      if (wk % 2 === 1) B.page(wk === 1 ? 'Registro de avances' : null);
      B.need(30 + habs.length * 22 + 50);
      B.cur.drawText('Semana ' + wk, { x: M, y: B.y - 12, size: 13, font: fonts.serifB, color: rgb(C.forest) });
      dl.forEach(function (l, i) { B.cur.drawText(l, { x: M + 340 + i * 23 + 3, y: B.y - 12, size: 8.5, font: fonts.sansB, color: rgb(C.olive) }); });
      B.y -= 20;
      habs.forEach(function (h) {
        B.cur.drawText(san(h.t).length > 62 ? san(h.t).slice(0, 60) + '...' : san(h.t), { x: M, y: B.y - 12, size: 9, font: fonts.sans, color: rgb(C.ink) });
        for (var di = 0; di < 7; di++) B.check('av_' + wk + '_' + h.id + '_' + di, M + 340 + di * 23, B.y - 14, 12, false);
        B.cur.drawLine({ start: { x: M, y: B.y - 19 }, end: { x: A4W - M, y: B.y - 19 }, thickness: 0.4, color: rgb(C.line) });
        B.y -= 22;
      });
      B.cur.drawText('Cómo me sentí esta semana', { x: M, y: B.y - 10, size: 8.5, font: fonts.sansB, color: rgb(C.soft) }); B.y -= 14;
      B.field('sem_' + wk, M, B.y - 40, CW, 40, '', { size: 9.5 }); B.y -= 58;
    }

    /* ---- 12 · revisión */
    B.page('Revisión de mis hábitos');
    B.p('Al final de las cuatro semanas, tómate un momento para mirar tu camino. No se trata de «aprobar», sino de aprender qué te funciona.', { gap: 8 });
    [['¿Qué me funcionó mejor?', 'rev_1'], ['¿Qué me costó más y por qué?', 'rev_2'], ['¿Qué voy a ajustar en mi plato, mis porciones o mi semana?', 'rev_3'], ['Mi próxima meta pequeña', 'rev_4']].forEach(function (q) {
      B.need(100); B.cur.drawText(san(q[0]), { x: M, y: B.y - 11, size: 11, font: fonts.sansB, color: rgb(C.forest) }); B.y -= 16;
      B.field(q[1], M, B.y - 62, CW, 62, '', { size: 10 }); B.y -= 76;
    });
    B.need(90); B.box(M, B.y - 70, CW, 70, { fill: C.ivory, border: C.sand });
    B.p('Aviso: Este material es educativo y trata de alimentación general, porciones, etiquetas y hábitos. No diagnostica ni trata enfermedades, no promete controlar la glucosa ni prevenir o curar nada, y no sustituye la atención de tu profesional de la salud. Las cantidades son una guía que debes adaptar a tu caso.', { x: M + 10, w: CW - 20, size: 8.5, color: C.soft });

    /* ---- numeración y campos ---- */
    var total = B.pages.length + 1;
    B.pages.forEach(function (pg, i) {
      var txt = 'Página ' + (i + 2) + ' de ' + total, w = fonts.sans.widthOfTextAtSize(txt, 8.5);
      pg.drawText(txt, { x: A4W / 2 - w / 2, y: 24, size: 8.5, font: fonts.sans, color: rgb(C.soft) });
    });
    B.form.updateFieldAppearances(fonts.sans);

    var bytes = await doc.save();
    var fn = 'Mi-transformacion-saludable-' + (TS.norm(state.name).replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'plan') + '.pdf';
    var blob = new Blob([bytes], { type: 'application/pdf' }), url = URL.createObjectURL(blob), a = document.createElement('a');
    a.href = url; a.download = fn; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 20000);
    TS.lastPDF = bytes;
    return fn;
  }
  TS.buildPDF = build;
})(window);
