/* Mi transformación saludable · Salud Integral
   Datos de la actividad: alimentos, comidas, porciones, etiquetas de ejemplo y movimiento.
   Todo el contenido es educativo y general; no sustituye la atención de profesionales de la salud. */
(function (W) {
  'use strict';

  /* ------------------------------------------------------------------ grupos */
  var GROUPS = {
    veg:     { n: 'Vegetales sin almidón', short: 'Vegetales', color: '#5F7318', soft: '#DCE8D2', note: 'Aportan fibra, color y variedad de nutrientes.' },
    protein: { n: 'Fuentes de proteína',   short: 'Proteína',  color: '#A9552F', soft: '#F3D9C9', note: 'Ayudan a sentirte satisfecha y a mantener tus músculos.' },
    starch:  { n: 'Alimentos con almidón', short: 'Almidón',   color: '#B98A1E', soft: '#F2E4B8', note: 'Dan energía. Arroz, legumbres, papa o maíz son parte de la comida, no enemigos.' },
    extra:   { n: 'Fruta y complementos',  short: 'Complementos', color: '#8B6B4A', soft: '#E8DCC8', note: 'Frutas, grasas buenas, semillas y toques de sabor.' },
    pantry:  { n: 'Despensa',              short: 'Despensa',  color: '#8B6B4A', soft: '#E8DCC8', note: '' }
  };

  /* ------------------------------------------------------------------ iconos de alimentos (SVG propios, 64x64) */
  var IC = {
    round: function (a) { return '<circle cx="32" cy="36" r="19" fill="' + a[0] + '"/><path d="M20 30a14 14 0 0 1 9-10" stroke="#fff" stroke-opacity=".5" stroke-width="3" fill="none" stroke-linecap="round"/><path d="M32 18c-1-6 3-9 8-10-1 5-3 8-8 10z" fill="' + (a[1] || '#5F7318') + '"/>'; },
    oval: function (a) { return '<ellipse cx="32" cy="34" rx="14" ry="21" fill="' + a[0] + '"/><ellipse cx="26" cy="26" rx="3.5" ry="8" fill="#fff" fill-opacity=".28"/>' + (a[1] ? '<path d="M32 13c0-4 2-6 5-7-1 4-2 6-5 7z" fill="' + a[1] + '"/>' : ''); },
    slice: function (a) {
      var seeds = '';
      for (var d = 0; d < 360; d += 60) { var x = 32 + 9 * Math.cos(d * Math.PI / 180), y = 32 + 9 * Math.sin(d * Math.PI / 180); seeds += '<ellipse cx="' + x.toFixed(1) + '" cy="' + y.toFixed(1) + '" rx="1.5" ry="2.8" fill="' + a[2] + '" transform="rotate(' + (d + 90) + ' ' + x.toFixed(1) + ' ' + y.toFixed(1) + ')"/>'; }
      return '<circle cx="32" cy="32" r="22" fill="' + a[0] + '"/><circle cx="32" cy="32" r="18" fill="' + a[1] + '"/>' + seeds;
    },
    floret: function (a) { return '<path d="M26 58V43h12v15z" fill="' + a[1] + '"/><circle cx="19" cy="35" r="10" fill="' + a[0] + '"/><circle cx="45" cy="35" r="10" fill="' + a[0] + '"/><circle cx="32" cy="24" r="13" fill="' + a[0] + '"/><circle cx="32" cy="38" r="11" fill="' + a[0] + '"/><circle cx="27" cy="21" r="3" fill="#fff" fill-opacity=".22"/><circle cx="40" cy="32" r="2.4" fill="#fff" fill-opacity=".18"/><circle cx="21" cy="33" r="2.4" fill="#fff" fill-opacity=".18"/>'; },
    root: function (a) { return '<path d="M32 58 L22 22 Q32 14 42 22 Z" fill="' + a[0] + '"/><path d="M26 30l5 1M28 40l5 1M30 49l3 .6" stroke="#000" stroke-opacity=".16" stroke-width="1.6" stroke-linecap="round"/>' + (a[1] ? '<path d="M32 20c-6-2-9-8-8-13 5 2 8 7 8 13zM32 20c0-6 3-12 8-13 1 5-2 11-8 13z" fill="' + a[1] + '"/>' : ''); },
    leafy: function (a) { return '<path d="M32 58C12 56 6 34 14 18c8 0 14 4 18 10 4-6 10-10 18-10 8 16 2 38-18 40z" fill="' + a[0] + '"/><path d="M32 58V24M32 44l-9-9M32 38l9-8M32 50l-8-6" stroke="' + a[1] + '" stroke-width="2.2" fill="none" stroke-linecap="round"/>'; },
    cabbage: function (a) { return '<circle cx="32" cy="34" r="22" fill="' + a[0] + '"/><path d="M32 12c-8 8-8 28 0 44M32 12c8 8 8 28 0 44M12 34c10 6 30 6 40 0" stroke="' + a[1] + '" stroke-width="2" fill="none"/>'; },
    pepper: function (a) { return '<path d="M20 26c0-6 6-8 12-6 6-2 12 0 12 6 2 14-2 28-12 28S18 40 20 26z" fill="' + a[0] + '"/><path d="M32 20c0-5 1-8 5-10" stroke="' + a[1] + '" stroke-width="3.4" fill="none" stroke-linecap="round"/><path d="M25 28c-1 6 0 12 2 16" stroke="#fff" stroke-opacity=".4" stroke-width="3" fill="none" stroke-linecap="round"/>'; },
    pod: function (a) { return '<path d="M12 50C20 30 36 18 52 12" stroke="' + a[0] + '" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M12 56C22 38 40 26 56 22" stroke="' + a[0] + '" stroke-width="7" fill="none" stroke-linecap="round" opacity=".85"/><path d="M16 46C24 32 36 24 48 19" stroke="#fff" stroke-opacity=".3" stroke-width="2" fill="none" stroke-linecap="round"/>'; },
    mound: function (a) {
      var dots = '', pts = [[22, 46], [30, 44], [38, 46], [26, 38], [34, 38], [42, 40], [30, 31], [38, 32], [32, 24], [20, 50], [44, 48], [27, 48], [36, 50]];
      pts.forEach(function (p, i) { dots += a[3] === 'bean' ? '<ellipse cx="' + p[0] + '" cy="' + p[1] + '" rx="3.4" ry="2.4" fill="' + a[1] + '" transform="rotate(' + (i * 37 % 90 - 30) + ' ' + p[0] + ' ' + p[1] + ')"/>' : '<ellipse cx="' + p[0] + '" cy="' + p[1] + '" rx="' + (a[3] === 'lens' ? 2.6 : 2.2) + '" ry="' + (a[3] === 'lens' ? 2.6 : 1.3) + '" fill="' + a[1] + '" transform="rotate(' + (i * 51 % 120 - 40) + ' ' + p[0] + ' ' + p[1] + ')"/>'; });
      return '<path d="M8 54c0-18 10-34 24-34s24 16 24 34z" fill="' + a[0] + '"/>' + dots;
    },
    nest: function (a) { return '<ellipse cx="32" cy="46" rx="24" ry="9" fill="' + a[1] + '"/><path d="M10 44c6-14 14-22 22-22s16 8 22 22M16 46c4-10 10-16 16-16s12 6 16 16M22 47c3-6 6-9 10-9s7 3 10 9" stroke="' + a[0] + '" stroke-width="3.2" fill="none" stroke-linecap="round"/><circle cx="32" cy="20" r="3" fill="#C8412B"/>'; },
    potato: function (a) { return '<path d="M12 36c0-12 10-20 22-20 12 0 20 8 18 20-2 12-12 18-24 16-10-2-16-6-16-16z" fill="' + a[0] + '"/><circle cx="24" cy="30" r="1.8" fill="' + a[1] + '"/><circle cx="38" cy="26" r="1.8" fill="' + a[1] + '"/><circle cx="42" cy="38" r="1.8" fill="' + a[1] + '"/><circle cx="26" cy="42" r="1.8" fill="' + a[1] + '"/><path d="M20 24c4-4 10-5 14-4" stroke="#fff" stroke-opacity=".35" stroke-width="3" fill="none" stroke-linecap="round"/>'; },
    cob: function (a) {
      var k = ''; for (var r = 0; r < 6; r++) for (var c = 0; c < 3; c++) k += '<rect x="' + (24 + c * 6) + '" y="' + (12 + r * 7) + '" width="5" height="6" rx="2" fill="' + a[0] + '"/>';
      return '<path d="M14 58C10 40 14 28 24 20l4 4c-6 8-8 18-6 32z" fill="' + a[1] + '"/><path d="M50 58C54 40 50 28 40 20l-4 4c6 8 8 18 6 32z" fill="' + a[1] + '"/><rect x="22" y="10" width="20" height="46" rx="10" fill="#F4D872"/>' + k;
    },
    banana: function (a) { return '<path d="M10 22c4 24 22 36 44 30-2 4-6 8-14 10C20 66 6 48 6 24z" fill="' + a[0] + '"/><path d="M10 22c-2-4 0-8 4-9l6 8z" fill="' + a[1] + '"/><path d="M12 28c6 18 20 26 36 24" stroke="#fff" stroke-opacity=".3" stroke-width="2.4" fill="none" stroke-linecap="round"/>'; },
    plantain: function (a) { return '<path d="M8 40c6-14 24-24 48-20 0 10-8 22-24 26C20 49 12 48 8 40z" fill="' + a[0] + '"/><path d="M14 38c8-8 20-14 36-14" stroke="' + a[1] + '" stroke-width="2.4" fill="none" stroke-linecap="round"/>'; },
    tortilla: function (a) { return '<circle cx="32" cy="32" r="23" fill="' + a[0] + '"/><circle cx="24" cy="26" r="2.4" fill="' + a[1] + '"/><circle cx="40" cy="24" r="2.4" fill="' + a[1] + '"/><circle cx="38" cy="40" r="2.4" fill="' + a[1] + '"/><circle cx="24" cy="40" r="2.4" fill="' + a[1] + '"/><circle cx="32" cy="33" r="2" fill="' + a[1] + '"/>'; },
    bread: function (a) { return '<path d="M10 28c-2-10 8-16 22-16s24 6 22 16c-2 2-4 2-4 4v20c0 3-3 4-6 4H20c-3 0-6-1-6-4V32c0-2-2-2-4-4z" fill="' + a[0] + '"/><path d="M20 30v20M32 30v20M44 30v20" stroke="' + a[1] + '" stroke-width="2" stroke-linecap="round" opacity=".6"/>'; },
    bowl: function (a) { return '<path d="M8 32h48a24 22 0 0 1-48 0z" fill="' + a[0] + '"/><path d="M12 32c2-8 10-12 20-12s18 4 20 12z" fill="' + a[1] + '"/><circle cx="26" cy="27" r="1.6" fill="#fff" fill-opacity=".6"/><circle cx="36" cy="25" r="1.6" fill="#fff" fill-opacity=".6"/><circle cx="31" cy="29" r="1.4" fill="#fff" fill-opacity=".6"/>'; },
    drumstick: function (a) { return '<path d="M14 50L30 34" stroke="#F4E9D8" stroke-width="7" stroke-linecap="round"/><circle cx="12" cy="52" r="3.6" fill="#F4E9D8"/><circle cx="16" cy="56" r="3.2" fill="#F4E9D8"/><path d="M26 18c8-8 24-8 28 4 3 10-6 22-18 24-10 2-18-6-18-14 0-6 2-10 8-14z" fill="' + a[0] + '"/><path d="M34 20c6-2 12 0 14 6" stroke="' + a[1] + '" stroke-width="3" fill="none" stroke-linecap="round" opacity=".6"/>'; },
    fish: function (a) { return '<path d="M6 32c10-14 26-16 38-6l12-8v28l-12-8C32 48 16 46 6 32z" fill="' + a[0] + '"/><circle cx="18" cy="29" r="2.4" fill="#173A1E"/><path d="M26 22c4 6 4 14 0 20M34 22c3 6 3 14 0 20" stroke="' + a[1] + '" stroke-width="2" fill="none" stroke-linecap="round" opacity=".7"/>'; },
    egg: function (a) { return '<path d="M32 8c10 0 20 20 20 32a20 18 0 0 1-40 0C12 28 22 8 32 8z" fill="' + a[0] + '"/><circle cx="32" cy="40" r="9" fill="' + a[1] + '"/><ellipse cx="29" cy="37" rx="3" ry="2" fill="#fff" fill-opacity=".45"/>'; },
    steak: function (a) { return '<path d="M10 34c0-14 12-22 26-20 12 2 20 12 18 24-2 12-14 18-28 14-10-3-16-8-16-18z" fill="' + a[0] + '"/><path d="M20 34c2-8 10-12 18-10 8 2 12 10 8 16" stroke="' + a[1] + '" stroke-width="3.4" fill="none" stroke-linecap="round" opacity=".7"/><circle cx="30" cy="34" r="3.4" fill="' + a[1] + '" opacity=".8"/>'; },
    cheese: function (a) { return '<path d="M6 40L34 14l24 10v22H6z" fill="' + a[0] + '"/><path d="M6 40L34 14l24 10-26 8z" fill="#fff" fill-opacity=".25"/><circle cx="20" cy="46" r="3" fill="' + a[1] + '"/><circle cx="38" cy="42" r="4" fill="' + a[1] + '"/><circle cx="50" cy="38" r="2.4" fill="' + a[1] + '"/>'; },
    cup: function (a) { return '<path d="M16 22h32l-4 34H20z" fill="' + a[0] + '"/><rect x="14" y="16" width="36" height="8" rx="3" fill="' + a[1] + '"/><path d="M22 34c4 3 8 3 12 0s8-3 10 0" stroke="#fff" stroke-opacity=".6" stroke-width="2.4" fill="none" stroke-linecap="round"/>'; },
    can: function (a) { return '<ellipse cx="32" cy="18" rx="20" ry="7" fill="' + a[1] + '"/><path d="M12 18v28c0 4 9 8 20 8s20-4 20-8V18c0 4-9 7-20 7s-20-3-20-7z" fill="' + a[0] + '"/><path d="M12 30c0 4 9 7 20 7s20-3 20-7" stroke="#fff" stroke-opacity=".5" stroke-width="2" fill="none"/>'; },
    avocado: function (a) { return '<path d="M32 6c10 0 14 14 14 22 6 6 8 12 6 18-3 8-12 12-20 12S15 54 12 46c-2-6 0-12 6-18 0-8 4-22 14-22z" fill="' + a[0] + '"/><path d="M32 12c8 0 10 12 10 18 4 4 6 9 4 14-2 6-8 9-14 9s-12-3-14-9c-2-5 0-10 4-14 0-6 2-18 10-18z" fill="' + a[1] + '"/><circle cx="32" cy="40" r="9" fill="#8B5A2B"/><ellipse cx="29" cy="37" rx="3" ry="2" fill="#fff" fill-opacity=".3"/>'; },
    bottle: function (a) { return '<rect x="25" y="6" width="14" height="8" rx="2" fill="#8B6B4A"/><path d="M26 14h12v8c6 4 8 8 8 16v14c0 4-3 6-6 6H24c-3 0-6-2-6-6V38c0-8 2-12 8-16z" fill="' + a[0] + '"/><rect x="22" y="38" width="20" height="12" rx="2" fill="#FBF8F1" fill-opacity=".85"/>'; },
    seeds: function (a) { var s = ''; [[18, 40], [28, 34], [38, 38], [46, 46], [24, 48], [34, 48], [30, 24], [42, 28], [20, 30], [36, 56], [14, 50]].forEach(function (p, i) { s += '<ellipse cx="' + p[0] + '" cy="' + p[1] + '" rx="5" ry="3" fill="' + a[0] + '" transform="rotate(' + (i * 43 % 160 - 60) + ' ' + p[0] + ' ' + p[1] + ')"/><path d="M' + (p[0] - 2) + ' ' + p[1] + 'h4" stroke="#fff" stroke-opacity=".4" stroke-width="1.2" transform="rotate(' + (i * 43 % 160 - 60) + ' ' + p[0] + ' ' + p[1] + ')"/>'; }); return s; },
    herbs: function (a) { return '<path d="M32 58V28" stroke="' + a[1] + '" stroke-width="2.6" stroke-linecap="round"/><path d="M32 30c-10-2-16-10-14-18 8 2 14 8 14 18zM32 36c10-2 16-10 14-18-8 2-14 8-14 18zM32 46c-8 0-12-6-12-12 6 0 12 4 12 12zM32 46c8 0 12-6 12-12-6 0-12 4-12 12z" fill="' + a[0] + '"/>'; },
    lemon: function (a) { return '<ellipse cx="32" cy="34" rx="23" ry="17" fill="' + a[0] + '" transform="rotate(-18 32 34)"/><ellipse cx="25" cy="28" rx="6" ry="3" fill="#fff" fill-opacity=".4" transform="rotate(-18 25 28)"/><path d="M52 26l5-4M8 42l-5 3" stroke="' + a[0] + '" stroke-width="5" stroke-linecap="round"/>'; },
    melon: function (a) { return '<path d="M6 30a26 26 0 0 0 52 0z" fill="' + a[0] + '"/><path d="M10 30a22 22 0 0 0 44 0z" fill="' + a[1] + '"/><ellipse cx="24" cy="38" rx="1.6" ry="2.6" fill="#173A1E"/><ellipse cx="34" cy="42" rx="1.6" ry="2.6" fill="#173A1E"/><ellipse cx="42" cy="36" rx="1.6" ry="2.6" fill="#173A1E"/>'; },
    nuts: function (a) { return '<ellipse cx="22" cy="38" rx="11" ry="15" fill="' + a[0] + '" transform="rotate(-20 22 38)"/><ellipse cx="42" cy="34" rx="11" ry="15" fill="' + a[0] + '" transform="rotate(18 42 34)"/><path d="M16 36c3 2 6 2 9 0M38 32c3 2 6 2 9 0" stroke="' + a[1] + '" stroke-width="2" fill="none" stroke-linecap="round"/>'; },
    jar: function (a) { return '<rect x="20" y="8" width="24" height="9" rx="2" fill="' + a[1] + '"/><path d="M18 17h28v36c0 3-3 5-6 5H24c-3 0-6-2-6-5z" fill="' + a[0] + '"/><rect x="20" y="30" width="24" height="14" rx="2" fill="#FBF8F1" fill-opacity=".8"/>'; },
    pot: function (a) { return '<path d="M10 28h44v14c0 10-8 16-22 16S10 52 10 42z" fill="' + a[0] + '"/><rect x="6" y="24" width="52" height="6" rx="3" fill="' + a[1] + '"/><path d="M22 18c0-4 4-4 4-8M32 18c0-4 4-4 4-8M42 18c0-4 4-4 4-8" stroke="' + a[1] + '" stroke-width="2.4" fill="none" stroke-linecap="round"/>'; }
  };

  /* ------------------------------------------------------------------ alimentos
     g: grupo · ic: icono · a: colores · lat: dato de cocina (solo para ordenar ejemplos) */
  var F = [
    // Vegetales sin almidón
    ['lechuga', 'Lechuga', 'veg', 'leafy', ['#8DBB5A', '#5F7318']],
    ['espinaca', 'Espinaca', 'veg', 'leafy', ['#4E7F2E', '#2F5A1B']],
    ['repollo', 'Repollo', 'veg', 'cabbage', ['#B9D49A', '#5F7318']],
    ['tomate', 'Tomate', 'veg', 'round', ['#D9442B', '#4E7F2E']],
    ['pepino', 'Pepino', 'veg', 'slice', ['#3F7A32', '#CFE6A8', '#7FA45A']],
    ['brocoli', 'Brócoli', 'veg', 'floret', ['#3F7A32', '#6E9A4A']],
    ['coliflor', 'Coliflor', 'veg', 'floret', ['#EFE6CF', '#B9D49A']],
    ['zanahoria', 'Zanahoria', 'veg', 'root', ['#E9812B', '#4E7F2E']],
    ['zucchini', 'Zucchini', 'veg', 'oval', ['#5E8C3A', '#3F6B2A']],
    ['chayote', 'Chayote', 'veg', 'round', ['#A8CB7A', '#4E7F2E']],
    ['vainica', 'Vainica', 'veg', 'pod', ['#5E9A3A']],
    ['pimiento', 'Pimiento', 'veg', 'pepper', ['#D9442B', '#3F7A32']],
    // Fuentes de proteína
    ['pollo', 'Pollo', 'protein', 'drumstick', ['#D98B3D', '#A9552F']],
    ['pescado', 'Pescado', 'protein', 'fish', ['#7FA8B8', '#BFD8E0']],
    ['huevos', 'Huevos', 'protein', 'egg', ['#FBF4E4', '#F2B63A']],
    ['res', 'Carne de res', 'protein', 'steak', ['#B5473A', '#F2D9CB']],
    ['cerdo', 'Cerdo', 'protein', 'steak', ['#D98A7A', '#F7E3D8']],
    ['atun', 'Atún', 'protein', 'can', ['#7FA8B8', '#C9D2D6']],
    ['queso', 'Queso fresco', 'protein', 'cheese', ['#F6DE8C', '#D9B14A']],
    ['yogurt', 'Yogur natural', 'protein', 'cup', ['#F7F2E8', '#A8C08A']],
    // Alimentos con almidón
    ['arroz', 'Arroz', 'starch', 'mound', ['#F7F2E4', '#D8CDB4', null, 'rice']],
    ['frijoles', 'Frijoles', 'starch', 'mound', ['#6B4A3A', '#2E1F18', null, 'bean'], 'También aportan proteína.'],
    ['lentejas', 'Lentejas', 'starch', 'mound', ['#C98A4B', '#8B5A2B', null, 'lens'], 'También aportan proteína.'],
    ['garbanzos', 'Garbanzos', 'starch', 'mound', ['#E3C47F', '#C49A4B', null, 'lens'], 'También aportan proteína.'],
    ['espaguetis', 'Espaguetis', 'starch', 'nest', ['#E8C45E', '#F4E3A8']],
    ['papa', 'Papa', 'starch', 'potato', ['#D9B27A', '#A9814A']],
    ['yuca', 'Yuca', 'starch', 'root', ['#C9A878', null]],
    ['camote', 'Camote', 'starch', 'root', ['#B5603A', null]],
    ['maiz', 'Maíz', 'starch', 'cob', ['#F2C94C', '#A8C08A']],
    ['platano', 'Plátano', 'starch', 'plantain', ['#E8C24A', '#8B6B2A']],
    ['tortilla', 'Tortilla de maíz', 'starch', 'tortilla', ['#EAD08A', '#C9A64A']],
    ['pan', 'Pan integral', 'starch', 'bread', ['#C98F55', '#8B5A2B']],
    ['avena', 'Avena', 'starch', 'bowl', ['#E8D6B0', '#F4EAD2']],
    // Fruta y complementos
    ['banano', 'Banano', 'extra', 'banana', ['#F2CE4A', '#8B6B2A']],
    ['manzana', 'Manzana', 'extra', 'round', ['#C93A2F', '#4E7F2E']],
    ['naranja', 'Naranja', 'extra', 'round', ['#EE8E2B', '#4E7F2E']],
    ['papaya', 'Papaya', 'extra', 'oval', ['#F28B3C', '#4E7F2E']],
    ['mango', 'Mango', 'extra', 'oval', ['#F2B63A', '#D9442B']],
    ['sandia', 'Sandía', 'extra', 'melon', ['#3F7A32', '#E8546A']],
    ['aguacate', 'Aguacate', 'extra', 'avocado', ['#4E7F2E', '#C9DF8A']],
    ['aceite', 'Aceite de oliva', 'extra', 'bottle', ['#C9B23A']],
    ['pepitoria', 'Pepitoria', 'extra', 'seeds', ['#7FA45A']],
    ['mani', 'Maní', 'extra', 'nuts', ['#D9B27A', '#A9814A']],
    ['limon', 'Limón', 'extra', 'lemon', ['#F2DE4A']],
    ['culantro', 'Culantro e hierbas', 'extra', 'herbs', ['#5F7318', '#3F6B2A']],
    // Despensa (no se usan en el plato, sí en las comidas y la lista de compras)
    ['leche', 'Leche o bebida vegetal', 'pantry', 'jar', ['#F7F2E8', '#A8C08A']],
    ['canela', 'Canela', 'pantry', 'jar', ['#B5703A', '#8B5A2B']],
    ['caldo', 'Caldo o recado', 'pantry', 'pot', ['#C98A4B', '#8B6B4A']],
    ['mantequilla-mani', 'Mantequilla de maní', 'pantry', 'jar', ['#C9955A', '#A9552F']]
  ];
  var FOODS = {}, ORDER = [];
  F.forEach(function (r) { FOODS[r[0]] = { id: r[0], n: r[1], g: r[2], ic: r[3], a: r[4], note: r[5] || '' }; ORDER.push(r[0]); });

  function foodSVG(id, px) {
    var f = FOODS[id]; if (!f) return '';
    var body = (IC[f.ic] || IC.round)(f.a || []);
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="' + (px || 64) + '" height="' + (px || 64) + '" role="img" aria-label="' + f.n + '">' + body + '</svg>';
  }

  /* ------------------------------------------------------------------ comidas de ejemplo para el plato (Estación 2) */
  var PLATES = [
    { id: 'casado', n: 'Casado tradicional', t: 'Latina', veg: ['lechuga', 'tomate', 'repollo'], protein: ['pollo'], starch: ['arroz', 'frijoles', 'platano'], extra: [],
      why: 'Mucha gente se sirve poco vegetal y bastante almidón. Con la guía, el arroz, los frijoles y el plátano ocupan un cuarto, y los vegetales ganan espacio.' },
    { id: 'gallo', n: 'Gallo pinto con huevo', t: 'Latina', veg: ['tomate', 'pepino', 'lechuga'], protein: ['huevos'], starch: ['arroz', 'frijoles'], extra: ['aguacate', 'culantro'],
      why: 'Los frijoles también aportan proteína; el huevo y los vegetales completan el plato.' },
    { id: 'arrozpollo', n: 'Arroz con pollo y ensalada', t: 'Latina', veg: ['lechuga', 'tomate', 'zanahoria', 'vainica'], protein: ['pollo'], starch: ['arroz'], extra: ['limon'],
      why: 'Los vegetales van picados dentro del arroz y también al lado, en ensalada.' },
    { id: 'lentejas', n: 'Lentejas con verduras', t: 'Latina', veg: ['zanahoria', 'chayote', 'espinaca'], protein: ['huevos'], starch: ['lentejas', 'papa'], extra: ['culantro'],
      why: 'Las legumbres dan almidón y proteína a la vez; un huevo o un poco de queso las complementa.' },
    { id: 'pollopapa', n: 'Pollo asado con papa y brócoli', t: 'Estadounidense', veg: ['brocoli', 'zanahoria', 'lechuga'], protein: ['pollo'], starch: ['papa'], extra: ['aceite'],
      why: 'Un clásico: la papa es el almidón, el brócoli y la ensalada llenan media mesa.' },
    { id: 'chili', n: 'Chili de frijoles con ensalada', t: 'Estadounidense', veg: ['pimiento', 'tomate', 'lechuga', 'pepino'], protein: ['res'], starch: ['frijoles', 'maiz'], extra: ['aguacate'],
      why: 'Los frijoles y el maíz son el almidón; la carne es la proteína; la ensalada equilibra.' },
    { id: 'pasta', n: 'Pasta con atún y vegetales', t: 'Estadounidense', veg: ['brocoli', 'tomate', 'zucchini', 'espinaca'], protein: ['atun'], starch: ['espaguetis'], extra: ['aceite', 'limon'],
      why: 'La pasta no está prohibida: se sirve en un cuarto y se acompaña de proteína y muchos vegetales.' },
    { id: 'burger', n: 'Hamburguesa casera con ensalada', t: 'Estadounidense', veg: ['lechuga', 'tomate', 'pepino', 'zanahoria'], protein: ['res'], starch: ['papa'], extra: ['aguacate'],
      why: 'Papas al horno en vez de fritas y una ensalada grande al lado.' }
  ];

  /* ------------------------------------------------------------------ porciones (Estación 3) */
  var PORTIONS = [
    { id: 'arroz', n: 'Arroz, pasta y otros cereales cocidos', measure: '½ taza cocida', hand: 'cup', alt: 'Una taza = un puño cerrado', foods: ['arroz', 'espaguetis'],
      txt: 'Media taza cocida cabe en la mano en forma de copa. Muchas personas se sirven una taza o más, y eso puede estar bien: depende de tu hambre, de tu día y del resto del plato.' },
    { id: 'veg', n: 'Vegetales', measure: '1 taza crudos · ½ taza cocidos', hand: 'fist', alt: 'Las hojas verdes crudas ocupan más: 2 puños', foods: ['lechuga', 'brocoli', 'zanahoria'],
      txt: 'Los vegetales crudos ocupan mucho volumen; cocidos, se reducen. Por eso media taza cocida y una taza cruda se consideran similares.' },
    { id: 'proteina', n: 'Pollo, pescado y carnes', measure: '85 g cocidos (3 onzas)', hand: 'palm', alt: 'Más o menos la palma abierta, sin los dedos', foods: ['pollo', 'pescado', 'res'],
      txt: 'Es una referencia común del tamaño y el grosor de una palma. Tu cuerpo, tu actividad y tus comidas del día cambian lo que te conviene.' },
    { id: 'huevos', n: 'Huevos', measure: '1 a 2 huevos', hand: 'egg', alt: 'Se cuentan por unidad', foods: ['huevos'],
      txt: 'Uno o dos huevos suelen usarse como porción de proteína en una comida. No hace falta contarlos con precisión: sirve para tener una idea.' },
    { id: 'legumbres', n: 'Frijoles, lentejas y garbanzos', measure: '½ taza cocida', hand: 'cup', alt: 'Como el arroz: una mano en copa', foods: ['frijoles', 'lentejas', 'garbanzos'],
      txt: 'Aportan fibra, almidón y proteína. Son parte de la comida diaria en muchos hogares y no hay por qué evitarlas.' },
    { id: 'fruta', n: 'Fruta entera', measure: '1 fruta mediana', hand: 'fist', alt: 'Más o menos del tamaño de un puño (una manzana, una naranja)', foods: ['manzana', 'naranja', 'banano'],
      txt: 'La fruta entera aporta fibra y otros nutrientes. Un banano o una manzana medianos son una porción habitual.' },
    { id: 'grasas', n: 'Aceites y aderezos', measure: '1 cucharadita a 1 cucharada', hand: 'thumb', alt: 'La uña del pulgar ≈ 1 cucharadita · el pulgar entero ≈ 2 cucharadas (aderezos o mantequilla de maní)', foods: ['aceite', 'aguacate'],
      txt: 'Son pequeñas cantidades que dan sabor y ayudan a absorber algunas vitaminas. Un cuarto o un tercio de aguacate suele ser una porción.' }
  ];

  var PORTION_QUIZ = [
    { q: '¿Qué parte de tu mano se parece a una porción de pollo o pescado cocido?', hand: 'palm', o: ['La palma abierta (sin los dedos)', 'El puño cerrado', 'La punta del pulgar'], a: 0,
      e: 'La palma abierta es una referencia común: unos 85 g (3 onzas) cocidos. Es una guía; tu porción depende de ti.' },
    { q: 'Una taza de vegetales crudos se parece a…', hand: 'fist', o: ['Un puño cerrado', 'La punta del pulgar', 'Una palma abierta'], a: 0,
      e: 'Un puño cerrado equivale a más o menos una taza. Las hojas verdes ocupan más lugar: sirve una cantidad generosa.' },
    { q: '¿Qué mano se parece a media taza de arroz cocido?', hand: 'cup', o: ['La mano en forma de copa', 'La palma abierta', 'El pulgar'], a: 0,
      e: 'Una mano ahuecada sostiene más o menos media taza. Si te sirves una taza, serían dos «copas»: no es bueno ni malo, es información.' },
    { q: 'Alguien se sirvió 2 tazas de arroz. ¿Qué podemos decir?', hand: null, o: ['Está mal: la porción es media taza', 'Es más que la referencia, pero lo que conviene depende de la persona y del resto del plato', 'Es lo ideal para todas las personas'], a: 1,
      e: 'Una cosa es la porción de referencia y otra la cantidad que decides servirte. Observa cómo queda tu plato, cómo te sientes después y ajusta a tu ritmo.' },
    { q: 'Una fruta entera mediana, como una manzana, se parece a…', hand: 'fist', o: ['Más o menos un puño', 'Dos palmas', 'La uña del pulgar'], a: 0,
      e: 'Un puño es una buena idea del tamaño de una fruta mediana. Las frutas muy grandes pueden contar como más de una porción.' }
  ];

  var SERVE_OPTS = [
    { id: 'mi', v: 0.25, t: '¼ taza' }, { id: 'mii', v: 0.5, t: '½ taza' }, { id: 'miii', v: 0.75, t: '¾ de taza' },
    { id: 'miv', v: 1, t: '1 taza' }, { id: 'miv2', v: 1.5, t: '1½ tazas' }, { id: 'miv3', v: 2, t: '2 tazas o más' }
  ];
  var MEASURE_ITEMS = [
    { id: 'arroz', n: 'Arroz, pasta o cereal cocido', ref: '½ taza', opts: ['¼ taza', '½ taza', '¾ de taza', '1 taza', '1½ tazas', '2 tazas o más'] },
    { id: 'legumbres', n: 'Frijoles o lentejas cocidos', ref: '½ taza', opts: ['¼ taza', '½ taza', '¾ de taza', '1 taza'] },
    { id: 'proteina', n: 'Pollo, pescado o carne cocidos', ref: '85 g (una palma)', opts: ['Menos de una palma', 'Una palma', 'Una palma y media', 'Dos palmas'] },
    { id: 'veg', n: 'Vegetales', ref: '1 taza crudos o ½ taza cocidos', opts: ['½ taza', '1 taza', '2 tazas', '3 tazas o más'] }
  ];

  /* ------------------------------------------------------------------ etiquetas de ejemplo (Estación 4)
     Todas son EJEMPLOS inventados con datos coherentes; no corresponden a productos comerciales reales. */
  var LABEL_PARTS = [
    { id: 'serving', n: 'Tamaño de la porción', t: 'Todos los números de la etiqueta son «por porción». Si te sirves el doble, todo se duplica. Y dos productos solo se comparan bien con la misma cantidad.' },
    { id: 'carbs', n: 'Carbohidratos totales', t: 'Incluye almidones, azúcares y fibra. Los carbohidratos de los alimentos se transforman en glucosa, que es una fuente de energía para el cuerpo.' },
    { id: 'fiber', n: 'Fibra', t: 'Viene de los alimentos de origen vegetal. Ayuda a que la digestión de los carbohidratos sea más gradual. Más fibra suele ser buena señal.' },
    { id: 'sugars', n: 'Azúcares totales', t: 'Suma los azúcares que están naturalmente en el alimento (como la lactosa de la leche o la fructosa de la fruta) y los añadidos.' },
    { id: 'added', n: 'Azúcares añadidos', t: 'Son los que se agregan al producto: azúcar, miel, jarabes, concentrados. Es el número que más cuenta cuando comparas dos productos parecidos.' },
    { id: 'dv', n: '% del Valor Diario', t: 'Como guía general, 5 % o menos es poco y 20 % o más es mucho. Para azúcares añadidos, el 100 % del valor diario de referencia son 50 g (referencia de la FDA de EE. UU.). Es una guía general, no una meta para ti.' },
    { id: 'ingredients', n: 'Lista de ingredientes', t: 'Va ordenada de mayor a menor cantidad: lo primero es lo que más hay. Si dice «integral» pero el primer ingrediente es harina refinada, ese producto lleva poca harina integral.' }
  ];

  var DUELS = [
    { id: 'avena', title: 'Avena natural y cereal azucarado',
      A: { name: 'Avena en hojuelas', claim: '100 % avena integral', serving: '40 g (½ taza)', carbs: 27, fiber: 4, sugars: 1, added: 0, ing: 'Avena integral.' },
      B: { name: 'Cereal de aros sabor frutas', claim: 'Con vitaminas y minerales', serving: '40 g (1 taza)', carbs: 33, fiber: 1, sugars: 14, added: 13, ing: 'Harina de maíz, azúcar, jarabe de glucosa, sabor artificial, colorantes, vitaminas y minerales.' },
      q: '¿Cuál tiene más azúcares añadidos por porción?', o: ['La avena', 'El cereal de aros', 'Los dos igual'], a: 1,
      e: 'El cereal tiene 13 g de azúcares añadidos (26 % del valor diario) y la avena, 0 g. Que el frente del empaque hable de vitaminas no cuenta la historia completa: hay que leer los datos. Además, la avena tiene 4 g de fibra frente a 1 g.' },
    { id: 'granola', title: 'Dos granolas «naturales»', scale: true,
      A: { name: 'Granola crujiente miel y almendra', claim: 'Natural', serving: '30 g (¼ taza)', carbs: 20, fiber: 2, sugars: 8, added: 7, ing: 'Avena, miel, azúcar morena, almendras, aceite de palma.' },
      B: { name: 'Granola de avena y frutos secos', claim: 'Receta casera', serving: '60 g (½ taza)', carbs: 38, fiber: 6, sugars: 9, added: 5, ing: 'Avena integral, nueces, pasas, semillas de girasol, un poco de miel.' },
      scaleTo: 60, scaleSide: 'A',
      q: 'Misma cantidad (60 g): ¿cuál tiene menos azúcares añadidos?', o: ['La granola A', 'La granola B', 'Dan igual'], a: 1,
      e: 'La granola A indica 7 g en 30 g; en 60 g serían 14 g. La B tiene 5 g en 60 g. Las porciones son distintas, por eso conviene mirar siempre el tamaño de la porción y comparar con la misma cantidad. «Natural» es una palabra del frente del empaque, no un dato.' },
    { id: 'fruta', title: 'Fruta entera y néctar',
      A: { name: 'Naranja mediana (fruta entera)', claim: '', serving: '1 unidad (130 g)', carbs: 15, fiber: 3, sugars: 12, added: 0, ing: 'Naranja.' },
      B: { name: 'Néctar de naranja', claim: 'Sabor natural', serving: '1 vaso (240 ml)', carbs: 30, fiber: 0, sugars: 27, added: 12, ing: 'Agua, concentrado de naranja, azúcar, ácido cítrico.' },
      q: 'Los dos «son de naranja». ¿En cuál hay azúcares añadidos y casi nada de fibra?', o: ['En la fruta entera', 'En el néctar', 'En ninguno'], a: 1,
      e: 'La fruta entera trae fibra y otros nutrientes, y sus azúcares son naturales. En el néctar hay 12 g de azúcares añadidos y 0 g de fibra. Un jugo 100 % fruta no lleva azúcares añadidos, pero igual pierde la fibra de la fruta entera: por eso la etiqueta ayuda a distinguir.' },
    { id: 'integral', title: '«Integral» en el frente del empaque',
      A: { name: 'Galletas integrales con miel', claim: 'Integral · con miel natural', serving: '30 g (4 galletas)', carbs: 22, fiber: 1, sugars: 8, added: 7, ing: 'Harina de trigo enriquecida, azúcar, aceite de palma, harina integral de trigo (8 %), miel, sal.' },
      B: { name: 'Pan integral de caja', claim: '', serving: '1 rebanada (40 g)', carbs: 18, fiber: 3, sugars: 2, added: 1, ing: 'Harina integral de trigo, agua, levadura, sal, azúcar.' },
      q: '¿Cuál tiene la harina integral como primer ingrediente?', o: ['Las galletas', 'El pan', 'Ninguno'], a: 1,
      e: 'Los ingredientes van de mayor a menor. En las galletas lo primero es harina enriquecida y la harina integral es solo el 8 %. En el pan, lo primero es harina integral. Un producto puede anunciarse como «integral» o «natural» y aun así tener poco de eso.' },
    { id: 'yogur', title: 'Yogur natural y yogur de sabor',
      A: { name: 'Yogur natural sin endulzar', claim: '', serving: '1 envase (170 g)', carbs: 8, fiber: 0, sugars: 7, added: 0, ing: 'Leche, cultivos de yogur.' },
      B: { name: 'Yogur sabor fresa', claim: 'Con trozos de fruta', serving: '1 envase (170 g)', carbs: 27, fiber: 0, sugars: 22, added: 14, ing: 'Leche, azúcar, preparado de fresa, almidón modificado, sabor.' },
      q: 'El yogur natural muestra 7 g de azúcares totales. ¿Cuántos son azúcares añadidos?', o: ['7 g', '0 g', 'No se puede saber'], a: 1,
      e: 'Son 0 g: esos 7 g son azúcares naturales de la leche (lactosa). Por eso no basta con mirar «azúcares totales»; la línea de azúcares añadidos aclara de dónde vienen. El yogur de fresa suma 14 g añadidos.' }
  ];

  var REVISIONS = [
    { id: 'porcion', t: 'Mirar el tamaño de la porción' },
    { id: 'anadidos', t: 'Buscar la línea de azúcares añadidos' },
    { id: 'fibra', t: 'Fijarme en la fibra' },
    { id: 'ingredientes', t: 'Leer los primeros ingredientes' },
    { id: 'misma', t: 'Comparar productos con la misma cantidad' },
    { id: 'frente', t: 'Recordar que el frente del empaque es publicidad' }
  ];

  /* ------------------------------------------------------------------ movimiento (Estación 5) */
  var MOVES = [
    { id: 'caminar', n: 'Caminar', ic: 'walk',
      L: { apoyo: 'Camina dentro de casa, con apoyo en una pared o un andador si lo usas.', suave: 'Camina a paso cómodo por la casa o el patio.', medio: 'Camina a un ritmo en el que todavía puedes conversar.', activo: 'Camina más rápido o busca una subida suave.' } },
    { id: 'bailar', n: 'Bailar', ic: 'dance',
      L: { apoyo: 'Baila sentada: mueve brazos, hombros y pies al ritmo.', suave: 'Baila una canción con pasos pequeños.', medio: 'Baila una o dos canciones a tu ritmo.', activo: 'Baila con más energía y mueve todo el cuerpo.' } },
    { id: 'sentada', n: 'Ejercicios sentados o con apoyo', ic: 'chair',
      L: { apoyo: 'Eleva los talones y las puntas de los pies; haz círculos con los brazos.', suave: 'Marcha sentada y estira los brazos al frente.', medio: 'Marcha sentada con los brazos al ritmo.', activo: 'Combina marcha sentada con movimientos amplios de brazos.' } },
    { id: 'fuerza', n: 'Fuerza adaptada', ic: 'strength',
      L: { apoyo: 'Empuja suavemente contra una pared o una mesa firme.', suave: 'Levanta botellas de agua vacías o llenas a la mitad.', medio: 'Siéntate y párate de una silla; levanta botellas de agua.', activo: 'Haz sentadillas a una silla o flexiones inclinadas contra la mesa.' } },
    { id: 'movilidad', n: 'Movilidad y estiramientos suaves', ic: 'stretch',
      L: { apoyo: 'Gira los hombros y los tobillos con calma, sentada.', suave: 'Gira cuello, hombros y muñecas con movimientos pequeños.', medio: 'Estira brazos, espalda y piernas sin dolor.', activo: 'Haz una secuencia de estiramientos más larga y respirada.' } }
  ];
  var LEVELS = [
    { id: 'apoyo', t: 'Con apoyo o sentada' }, { id: 'suave', t: 'A ritmo suave' },
    { id: 'medio', t: 'A mi ritmo' }, { id: 'activo', t: 'Con más energía' }
  ];
  var SLOTS = [
    { id: 'am', t: 'Al despertar' }, { id: 'mid', t: 'Media mañana' }, { id: 'pm', t: 'Tarde' }, { id: 'noche', t: 'Noche' }
  ];
  var DAYS = [
    { id: 'lun', t: 'Lunes', s: 'L' }, { id: 'mar', t: 'Martes', s: 'M' }, { id: 'mie', t: 'Miércoles', s: 'X' }, { id: 'jue', t: 'Jueves', s: 'J' },
    { id: 'vie', t: 'Viernes', s: 'V' }, { id: 'sab', t: 'Sábado', s: 'S' }, { id: 'dom', t: 'Domingo', s: 'D' }
  ];

  /* ------------------------------------------------------------------ comidas para la semana (Estación 6)
     slots: d desayuno · a almuerzo · m merienda · c cena · tags para filtrar · eco: económica · q: rápida (≤ 20 min) */
  var MEALS = [
    // Desayunos
    { id: 'gallo-huevo', n: 'Gallo pinto con huevo y tomate', s: 'd', t: 'Latina', ing: ['arroz', 'frijoles', 'huevos', 'tomate', 'culantro'], tags: ['huevo'], eco: 1, q: 1 },
    { id: 'gallo-aguacate', n: 'Gallo pinto con aguacate y tomate', s: 'd', t: 'Latina', ing: ['arroz', 'frijoles', 'aguacate', 'tomate', 'culantro'], tags: [], eco: 1, q: 1 },
    { id: 'revueltos', n: 'Huevos revueltos con espinaca y tostada integral', s: 'd', t: 'Estadounidense', ing: ['huevos', 'espinaca', 'pan'], tags: ['huevo', 'gluten'], q: 1 },
    { id: 'avena-banano', n: 'Avena con banano y canela', s: 'd', t: 'Estadounidense', ing: ['avena', 'banano', 'canela', 'leche'], tags: ['gluten', 'lacteo'], eco: 1, q: 1 },
    { id: 'tortilla-frijol', n: 'Tortilla de maíz con frijoles, aguacate y huevo', s: 'd', t: 'Latina', ing: ['tortilla', 'frijoles', 'aguacate', 'huevos'], tags: ['huevo'], eco: 1, q: 1 },
    { id: 'yogur-fruta', n: 'Yogur natural con papaya y pepitoria', s: 'd', t: 'Latina', ing: ['yogurt', 'papaya', 'pepitoria'], tags: ['lacteo'], q: 1 },
    { id: 'tostada-aguacate', n: 'Tostada integral con aguacate, tomate y fruta', s: 'd', t: 'Estadounidense', ing: ['pan', 'aguacate', 'tomate', 'naranja'], tags: ['gluten'], q: 1 },
    { id: 'omelette', n: 'Omelette de pimiento y tomate con fruta', s: 'd', t: 'Estadounidense', ing: ['huevos', 'pimiento', 'tomate', 'manzana'], tags: ['huevo'], q: 1 },
    { id: 'avena-agua', n: 'Avena cocida con manzana y canela', s: 'd', t: 'Latina', ing: ['avena', 'manzana', 'canela'], tags: ['gluten'], eco: 1, q: 1 },
    // Almuerzos y cenas
    { id: 'casado', n: 'Casado: arroz, frijoles, pollo, ensalada y plátano', s: 'ac', t: 'Latina', ing: ['arroz', 'frijoles', 'pollo', 'lechuga', 'tomate', 'platano'], tags: ['carne'], eco: 1 },
    { id: 'arroz-pollo', n: 'Arroz con pollo y vegetales, con ensalada', s: 'ac', t: 'Latina', ing: ['arroz', 'pollo', 'zanahoria', 'vainica', 'pimiento', 'lechuga'], tags: ['carne'], eco: 1 },
    { id: 'pescado-papa', n: 'Pescado a la plancha con papa al horno y brócoli', s: 'ac', t: 'Estadounidense', ing: ['pescado', 'papa', 'brocoli', 'limon', 'aceite'], tags: ['pescado'] },
    { id: 'sopa-lentejas', n: 'Sopa de lentejas con verduras y ensalada', s: 'ac', t: 'Latina', ing: ['lentejas', 'zanahoria', 'papa', 'chayote', 'culantro', 'lechuga', 'tomate'], tags: [], eco: 1 },
    { id: 'pasta-atun', n: 'Espaguetis con atún, tomate y brócoli', s: 'ac', t: 'Estadounidense', ing: ['espaguetis', 'atun', 'tomate', 'brocoli', 'aceite'], tags: ['pescado', 'gluten'], eco: 1, q: 1 },
    { id: 'tacos-pollo', n: 'Tacos de pollo con tortilla de maíz, frijoles y repollo', s: 'ac', t: 'Latina', ing: ['tortilla', 'pollo', 'frijoles', 'repollo', 'limon', 'culantro'], tags: ['carne'], q: 1 },
    { id: 'pollo-camote', n: 'Pollo asado con camote y ensalada de brócoli y zanahoria', s: 'ac', t: 'Estadounidense', ing: ['pollo', 'camote', 'brocoli', 'zanahoria', 'aceite'], tags: ['carne'] },
    { id: 'chili', n: 'Chili de frijoles con carne y ensalada', s: 'ac', t: 'Estadounidense', ing: ['frijoles', 'res', 'tomate', 'pimiento', 'lechuga', 'pepino'], tags: ['carne'] },
    { id: 'hamburguesa', n: 'Hamburguesa casera con papas al horno y ensalada', s: 'ac', t: 'Estadounidense', ing: ['res', 'papa', 'lechuga', 'tomate', 'pepino', 'aceite'], tags: ['carne'] },
    { id: 'picadillo', n: 'Picadillo de chayote con carne y arroz', s: 'ac', t: 'Latina', ing: ['chayote', 'res', 'arroz', 'zanahoria', 'culantro'], tags: ['carne'], eco: 1 },
    { id: 'arroz-huevo', n: 'Arroz con huevo, vegetales salteados y aguacate', s: 'ac', t: 'Latina', ing: ['arroz', 'huevos', 'zucchini', 'pimiento', 'aguacate'], tags: ['huevo'], eco: 1, q: 1 },
    { id: 'frijol-zucchini', n: 'Frijoles negros con arroz, zucchini salteado y aguacate', s: 'ac', t: 'Latina', ing: ['frijoles', 'arroz', 'zucchini', 'aguacate', 'culantro'], tags: [], eco: 1, q: 1 },
    { id: 'cerdo-yuca', n: 'Cerdo asado con yuca cocida y repollo', s: 'ac', t: 'Latina', ing: ['cerdo', 'yuca', 'repollo', 'tomate', 'limon'], tags: ['carne'] },
    { id: 'sandwich-pollo', n: 'Sándwich de pollo con ensalada y fruta', s: 'ac', t: 'Estadounidense', ing: ['pan', 'pollo', 'lechuga', 'tomate', 'manzana'], tags: ['carne', 'gluten'], q: 1 },
    { id: 'ensalada-completa', n: 'Ensalada grande con atún, huevo y garbanzos', s: 'ac', t: 'Estadounidense', ing: ['lechuga', 'atun', 'huevos', 'garbanzos', 'tomate', 'pepino', 'aceite'], tags: ['pescado', 'huevo'], q: 1 },
    { id: 'garbanzos-veg', n: 'Arroz con garbanzos y vegetales salteados', s: 'ac', t: 'Latina', ing: ['arroz', 'garbanzos', 'zanahoria', 'vainica', 'pimiento', 'culantro'], tags: [], eco: 1, q: 1 },
    { id: 'lentejas-camote', n: 'Lentejas guisadas con camote y ensalada', s: 'ac', t: 'Latina', ing: ['lentejas', 'camote', 'lechuga', 'tomate', 'pepino'], tags: [], eco: 1 },
    // Meriendas
    { id: 'm-queso-fruta', n: 'Manzana con queso fresco', s: 'm', t: 'Estadounidense', ing: ['manzana', 'queso'], tags: ['lacteo'], q: 1 },
    { id: 'm-yogur-mani', n: 'Yogur natural con pepitoria', s: 'm', t: 'Latina', ing: ['yogurt', 'pepitoria'], tags: ['lacteo'], q: 1 },
    { id: 'm-huevo-pepino', n: 'Huevo duro con pepino y limón', s: 'm', t: 'Latina', ing: ['huevos', 'pepino', 'limon'], tags: ['huevo'], eco: 1, q: 1 },
    { id: 'm-banano-mani', n: 'Banano con mantequilla de maní', s: 'm', t: 'Estadounidense', ing: ['banano', 'mantequilla-mani'], tags: [], q: 1 },
    { id: 'm-zanahoria-aguacate', n: 'Zanahoria y pepino con aguacate', s: 'm', t: 'Latina', ing: ['zanahoria', 'pepino', 'aguacate', 'limon'], tags: [], q: 1 },
    { id: 'm-palomitas', n: 'Palomitas de maíz caseras', s: 'm', t: 'Estadounidense', ing: ['maiz'], tags: [], eco: 1, q: 1 },
    { id: 'm-fruta', n: 'Fruta de temporada picada', s: 'm', t: 'Latina', ing: ['papaya', 'sandia', 'naranja'], tags: [], eco: 1, q: 1 },
    { id: 'm-camote', n: 'Camote al horno con canela', s: 'm', t: 'Latina', ing: ['camote', 'canela'], tags: [], eco: 1 }
  ];

  var HABITS = [
    { id: 'plato', t: 'Armar mi plato con la guía en al menos una comida' },
    { id: 'porcion', t: 'Observar mis porciones con mis medidas' },
    { id: 'etiqueta', t: 'Leer una etiqueta antes de comprar o comer algo envasado' },
    { id: 'plan', t: 'Seguir mi plan de comidas (lo que pueda)' },
    { id: 'mover', t: 'Hacer mis bloques de movimiento' },
    { id: 'agua', t: 'Tomar agua durante el día' },
    { id: 'pausa', t: 'Comer una comida sin pantallas y sin prisa' },
    { id: 'compras', t: 'Revisar mi lista de compras antes de ir al supermercado' },
    { id: 'preparar', t: 'Dejar una preparación lista para el día siguiente' }
  ];

  var GOALS = [
    { id: 'plato', t: 'Aprender a construir comidas equilibradas', h: 'plato' },
    { id: 'porciones', t: 'Entender mejor las porciones', h: 'porcion' },
    { id: 'etiquetas', t: 'Aprender a leer etiquetas', h: 'etiqueta' },
    { id: 'semana', t: 'Organizar las comidas de la semana', h: 'plan' },
    { id: 'movimiento', t: 'Incorporar más movimiento', h: 'mover' },
    { id: 'habitos', t: 'Construir hábitos que pueda mantener', h: 'pausa' }
  ];

  var USUAL = [
    { id: 'gallo', t: 'Gallo pinto' }, { id: 'casado', t: 'Casado' }, { id: 'arroz-pollo', t: 'Arroz con pollo' }, { id: 'pasta', t: 'Pasta' },
    { id: 'sopa', t: 'Sopas y guisos' }, { id: 'sandwich', t: 'Sándwiches' }, { id: 'tacos', t: 'Tacos o tortillas' }, { id: 'hamburguesa', t: 'Hamburguesas' },
    { id: 'ensaladas', t: 'Ensaladas' }, { id: 'huevos', t: 'Huevos' }
  ];
  var DIETS = [
    { id: 'vegetariana', t: 'Vegetariana (sin carne ni pescado)' }, { id: 'sinlacteos', t: 'Sin lácteos' }, { id: 'sinhuevo', t: 'Sin huevo' },
    { id: 'sinpescado', t: 'Sin pescado ni atún' }, { id: 'singluten', t: 'Evito el gluten' }
  ];
  var TIMES = [{ id: 'poco', t: 'Poco: hasta 20 minutos' }, { id: 'medio', t: 'Normal: 20 a 40 minutos' }, { id: 'mucho', t: 'Con calma: más de 40 minutos' }];
  var BUDGETS = [{ id: 'ajustado', t: 'Ajustado' }, { id: 'medio', t: 'Intermedio' }, { id: 'flexible', t: 'Flexible' }];

  /* sustituciones simples dentro del mismo grupo (para «Sustituir alimento») */
  var SWAPS = {
    pollo: ['pescado', 'huevos', 'atun', 'res', 'cerdo'], pescado: ['pollo', 'atun', 'huevos'], res: ['pollo', 'cerdo', 'pescado'], cerdo: ['pollo', 'res', 'pescado'],
    atun: ['pollo', 'huevos', 'pescado'], huevos: ['queso', 'atun', 'pollo', 'frijoles'], queso: ['huevos', 'yogurt'], yogurt: ['queso', 'huevos'],
    arroz: ['papa', 'yuca', 'camote', 'espaguetis', 'tortilla'], papa: ['arroz', 'yuca', 'camote'], yuca: ['papa', 'camote', 'arroz'], camote: ['papa', 'yuca', 'arroz'],
    espaguetis: ['arroz', 'papa', 'tortilla'], tortilla: ['arroz', 'pan', 'papa'], pan: ['tortilla', 'avena'], avena: ['pan', 'tortilla'], platano: ['camote', 'yuca', 'papa'], maiz: ['papa', 'camote'],
    frijoles: ['lentejas', 'garbanzos'], lentejas: ['frijoles', 'garbanzos'], garbanzos: ['frijoles', 'lentejas'],
    lechuga: ['espinaca', 'repollo'], espinaca: ['lechuga', 'repollo'], repollo: ['lechuga', 'zanahoria'], tomate: ['pepino', 'pimiento'], pepino: ['tomate', 'zanahoria'],
    brocoli: ['coliflor', 'vainica', 'zucchini'], coliflor: ['brocoli', 'chayote'], zanahoria: ['chayote', 'pimiento', 'vainica'], zucchini: ['chayote', 'brocoli', 'vainica'],
    chayote: ['zucchini', 'zanahoria'], vainica: ['brocoli', 'zucchini'], pimiento: ['tomate', 'zanahoria'],
    banano: ['manzana', 'naranja', 'papaya'], manzana: ['banano', 'naranja', 'papaya'], naranja: ['manzana', 'banano'], papaya: ['sandia', 'mango', 'banano'], mango: ['papaya', 'banano'], sandia: ['papaya', 'naranja'],
    aguacate: ['aceite', 'pepitoria'], aceite: ['aguacate'], mani: ['pepitoria'], pepitoria: ['mani']
  };

  W.TS_DATA = {
    GROUPS: GROUPS, FOODS: FOODS, ORDER: ORDER, foodSVG: foodSVG, PLATES: PLATES, PORTIONS: PORTIONS, PORTION_QUIZ: PORTION_QUIZ,
    MEASURE_ITEMS: MEASURE_ITEMS, SERVE_OPTS: SERVE_OPTS, LABEL_PARTS: LABEL_PARTS, DUELS: DUELS, REVISIONS: REVISIONS,
    MOVES: MOVES, LEVELS: LEVELS, SLOTS: SLOTS, DAYS: DAYS, MEALS: MEALS, HABITS: HABITS, GOALS: GOALS,
    USUAL: USUAL, DIETS: DIETS, TIMES: TIMES, BUDGETS: BUDGETS, SWAPS: SWAPS
  };
})(window);
