/* Mi transformación saludable · estaciones 1 a 4: inicio, plato, porciones y etiquetas */
(function (W) {
  'use strict';
  var TS = W.TS, D = TS.D, S = TS.S, esc = TS.esc, $ = TS.$;

  function chip(list, id, text, on) {
    return '<button type="button" class="ts-chip' + (on ? ' on' : '') + '" data-act="toggle" data-list="' + list + '" data-id="' + esc(id) + '" aria-pressed="' + (on ? 'true' : 'false') + '">' + esc(text) + '</button>';
  }
  function one(k, id, text) {
    var on = S[k] === id;
    return '<button type="button" class="ts-chip' + (on ? ' on' : '') + '" data-act="one" data-k="' + k + '" data-id="' + id + '" aria-pressed="' + (on ? 'true' : 'false') + '">' + esc(text) + '</button>';
  }

  /* ================================================================== 1 · INICIO */
  TS.register({
    id: 'inicio', short: 'Inicio', eyebrow: 'Estación 1', title: 'Mi punto de partida', next: 'Construir mi plato',
    lead: 'Cuéntanos cómo quieres empezar. Lo que elijas aquí va dando forma a tu plan. Puedes omitir lo que prefieras no responder.',
    html: function () {
      var goals = D.GOALS.map(function (g) { return chip('goals', g.id, g.t, S.goals.indexOf(g.id) > -1); }).join('');
      var usual = D.USUAL.map(function (g) { return chip('usual', g.id, g.t, S.usual.indexOf(g.id) > -1); }).join('');
      var diets = D.DIETS.map(function (g) { return chip('diets', g.id, g.t, S.diets.indexOf(g.id) > -1); }).join('');
      var times = D.TIMES.map(function (t) { return one('time', t.id, t.t); }).join('');
      var buds = D.BUDGETS.map(function (t) { return one('budget', t.id, t.t); }).join('');
      return '<div class="ts-card"><h3>¿Cómo quieres que aparezca tu nombre en la portada?</h3>' +
        '<label class="ts-lab" for="ts-name">Tu nombre</label>' +
        '<input id="ts-name" class="ts-input" type="text" maxlength="60" autocomplete="name" placeholder="Ej.: María Rodríguez" data-bind="name" value="' + esc(S.name) + '" required>' +
        '<p class="ts-hint">Es lo único necesario. Solo se guarda en este dispositivo y se usa para tu PDF.</p></div>' +
        '<div class="ts-card"><h3>¿Qué te gustaría mejorar?</h3><p class="ts-hint">Elige todo lo que quieras.</p><div class="ts-chips">' + goals + '</div></div>' +
        '<div class="ts-card"><h3>Tus comidas de siempre</h3><p class="ts-hint">Marca las que comes con frecuencia. Las usaremos para armar tu semana.</p><div class="ts-chips">' + usual + '</div></div>' +
        '<div class="ts-card"><h3>Tu forma de comer</h3><p class="ts-hint">Opcional. Nos ayuda a no proponerte lo que no va contigo. Si tienes alergias o una condición médica, revisa cada comida con tu profesional de salud.</p>' +
        '<div class="ts-chips">' + diets + '</div>' +
        '<label class="ts-lab" for="ts-dis">Alimentos que no comes o no te gustan</label>' +
        '<input id="ts-dis" class="ts-input" type="text" maxlength="120" placeholder="Ej.: pescado, coliflor" data-bind="dislikes" value="' + esc(S.dislikes) + '"></div>' +
        '<div class="ts-card ts-two"><div><h3>Tiempo para cocinar</h3><div class="ts-chips">' + times + '</div></div>' +
        '<div><h3>Presupuesto aproximado</h3><div class="ts-chips">' + buds + '</div></div></div>';
    },
    bind: { name: function (v) { S.name = v; TS.save(); }, dislikes: function (v) { S.dislikes = v; TS.save(); } }
  });

  /* ================================================================== 2 · PLATO */
  var CX = 200, CY = 200, R = 170;
  var LIMIT = { veg: 6, protein: 3, starch: 3, extra: 6 };
  var pf = 'all';

  /* posiciones de los iconos dentro de cada sector (compartidas con el PDF) */
  function slots(group, n) {
    var out = [], i, cols, rows, px, py, cx, cy;
    if (group === 'veg') { cols = n <= 2 ? 1 : 2; rows = Math.ceil(n / cols); px = 66; py = n <= 2 ? 90 : 78; cx = 108; cy = CY; }
    else if (group === 'protein') { cols = n <= 1 ? 1 : 2; rows = Math.ceil(n / cols); px = 56; py = 54; cx = 274; cy = 128; }
    else if (group === 'starch') { cols = n <= 1 ? 1 : 2; rows = Math.ceil(n / cols); px = 56; py = 54; cx = 274; cy = 272; }
    else { cols = 6; rows = 1; px = 44; py = 0; cx = CX; cy = 436; }
    for (i = 0; i < n; i++) {
      var c = i % cols, r = Math.floor(i / cols), inRow = (r === rows - 1 && n % cols) ? n % cols : cols;
      if (group === 'extra') inRow = n;
      var x = cx + (c - (inRow - 1) / 2) * px, y = cy + (r - (rows - 1) / 2) * py;
      out.push({ x: x, y: y, s: group === 'veg' ? (n > 4 ? 52 : 60) : group === 'extra' ? 40 : (n > 2 ? 44 : 52) });
    }
    return out;
  }
  var SECT = {
    veg: 'M' + CX + ' ' + (CY - R) + 'A' + R + ' ' + R + ' 0 0 0 ' + CX + ' ' + (CY + R) + 'Z',
    protein: 'M' + CX + ' ' + CY + 'L' + CX + ' ' + (CY - R) + 'A' + R + ' ' + R + ' 0 0 1 ' + (CX + R) + ' ' + CY + 'Z',
    starch: 'M' + CX + ' ' + CY + 'L' + (CX + R) + ' ' + CY + 'A' + R + ' ' + R + ' 0 0 1 ' + CX + ' ' + (CY + R) + 'Z'
  };
  var HINT = { veg: ['½ del plato', 'vegetales', 'sin almidón', 108, 188], protein: ['¼ del plato', 'proteína', '', 274, 126], starch: ['¼ del plato', 'almidón', '', 274, 270] };

  function plateSVG(plate, opts) {
    opts = opts || {};
    var g = D.GROUPS, out = '<svg viewBox="0 0 400 ' + (opts.tray === false ? 400 : 470) + '" class="ts-plate" role="img" aria-label="Tu plato: la mitad vegetales sin almidón, un cuarto proteína y un cuarto almidón">';
    out += '<circle cx="200" cy="200" r="188" fill="#FBF8F1" stroke="#D7C7A5" stroke-width="3"/><circle cx="200" cy="200" r="176" fill="#fff" stroke="#EADFC6" stroke-width="1.5"/>';
    ['veg', 'protein', 'starch'].forEach(function (k) {
      out += '<path d="' + SECT[k] + '" fill="' + g[k].soft + '" stroke="#fff" stroke-width="4" stroke-linejoin="round"/>';
      var items = plate[k] || [];
      if (!items.length) {
        var h = HINT[k];
        out += '<text x="' + h[3] + '" y="' + h[4] + '" text-anchor="middle" font-family="Jost,sans-serif" fill="' + g[k].color + '" opacity=".85"><tspan x="' + h[3] + '" font-size="15" font-weight="600">' + h[0] + '</tspan><tspan x="' + h[3] + '" dy="18" font-size="14">' + h[1] + '</tspan>' + (h[2] ? '<tspan x="' + h[3] + '" dy="17" font-size="14">' + h[2] + '</tspan>' : '') + '</text>';
      } else {
        slots(k, items.length).forEach(function (p, i) {
          out += '<g transform="translate(' + (p.x - p.s / 2).toFixed(1) + ' ' + (p.y - p.s / 2).toFixed(1) + ') scale(' + (p.s / 64).toFixed(3) + ')" class="ts-drop">' + D.foodSVG(items[i], 64).replace(/^<svg[^>]*>/, '<g>').replace('</svg>', '</g>') + '</g>';
        });
      }
    });
    if (opts.tray !== false) {
      out += '<rect x="40" y="406" width="320" height="58" rx="29" fill="#FBF8F1" stroke="#D7C7A5" stroke-dasharray="4 5"/>';
      var ex = plate.extra || [];
      if (!ex.length) out += '<text x="200" y="440" text-anchor="middle" font-size="13.5" font-family="Jost,sans-serif" fill="#8B6B4A">Al lado: fruta y complementos</text>';
      else slots('extra', ex.length).forEach(function (p, i) { out += '<g transform="translate(' + (p.x - p.s / 2).toFixed(1) + ' ' + (p.y - p.s / 2).toFixed(1) + ') scale(' + (p.s / 64).toFixed(3) + ')" class="ts-drop">' + D.foodSVG(ex[i], 64).replace(/^<svg[^>]*>/, '<g>').replace('</svg>', '</g>') + '</g>'; });
    }
    return out + '</svg>';
  }
  TS.plateSVG = plateSVG; TS.plateSlots = slots; TS.plateGeom = { CX: CX, CY: CY, R: R, SECT: SECT };

  function plateFeed() {
    var p = S.plate, n = { veg: p.veg.length, protein: p.protein.length, starch: p.starch.length, extra: p.extra.length };
    var total = n.veg + n.protein + n.starch + n.extra, msgs = [];
    if (!total) return '<p class="ts-msg">Toca los alimentos de la derecha para ir armando tu plato. Puedes quitarlos tocándolos otra vez.</p>';
    if (!n.veg) msgs.push('Aún no hay vegetales: la guía les da la mitad del plato porque aportan fibra, color y variedad.');
    if (!n.protein) msgs.push('Falta una fuente de proteína (pollo, pescado, huevos, queso…). Ayuda a sentirte satisfecha.');
    if (!n.starch) msgs.push('Todavía no hay almidón. Arroz, frijoles, papa, yuca o maíz dan energía y son parte de la comida.');
    if (n.veg && n.protein && n.starch) msgs.push('¡Tu plato tiene de todo! Se parece a la guía: la mitad vegetales, un cuarto proteína y un cuarto almidón.');
    if (n.veg >= 3) msgs.push('Tienes ' + n.veg + ' vegetales distintos: cuantos más colores, más variedad de nutrientes.');
    if (n.starch >= 3) msgs.push('Hay varios alimentos con almidón juntos. No son malos: puedes dejar uno para otra comida y darle más lugar a los vegetales.');
    if (p.starch.some(function (id) { return D.FOODS[id].note; }) && !n.protein) msgs.push('Los frijoles y las lentejas también aportan proteína; sumar un huevo, pollo o queso completa el plato.');
    var chips = ['veg', 'protein', 'starch', 'extra'].map(function (k) { return '<span class="ts-count-chip" style="--c:' + D.GROUPS[k].color + '">' + D.GROUPS[k].short + ': <b>' + n[k] + '</b></span>'; }).join('');
    var preset = S.platePreset && TS.byId(D.PLATES, S.platePreset);
    return '<div class="ts-counts">' + chips + '</div>' + msgs.map(function (m) { return '<p class="ts-msg">' + esc(m) + '</p>'; }).join('') +
      (preset ? '<p class="ts-msg ts-msg-note"><b>' + esc(preset.n) + ':</b> ' + esc(preset.why) + '</p>' : '');
  }
  function palette() {
    return ['veg', 'protein', 'starch', 'extra'].map(function (k) {
      var g = D.GROUPS[k];
      var foods = D.ORDER.filter(function (id) { return D.FOODS[id].g === k; }).map(function (id) {
        var on = S.plate[k].indexOf(id) > -1, f = D.FOODS[id];
        return '<button type="button" class="ts-food' + (on ? ' on' : '') + '" data-act="food" data-id="' + id + '" data-key="f-' + id + '" aria-pressed="' + (on ? 'true' : 'false') + '" title="' + esc(f.note || f.n) + '"><span class="i">' + D.foodSVG(id, 44) + '</span><span class="n">' + esc(f.n) + '</span></button>';
      }).join('');
      return '<div class="ts-pal" style="--c:' + g.color + ';--s:' + g.soft + '"><h4><span class="dot"></span>' + esc(g.n) + '</h4><p class="ts-hint">' + esc(g.note) + '</p><div class="ts-foods">' + foods + '</div></div>';
    }).join('');
  }
  function presets() {
    var list = D.PLATES.filter(function (p) { return pf === 'all' || (pf === 'lat' ? p.t === 'Latina' : p.t === 'Estadounidense'); });
    var f = [['all', 'Todas'], ['lat', 'Latinas'], ['usa', 'Estadounidenses']].map(function (x) { return '<button type="button" class="ts-chip' + (pf === x[0] ? ' on' : '') + '" data-act="pfilter" data-id="' + x[0] + '" aria-pressed="' + (pf === x[0]) + '">' + x[1] + '</button>'; }).join('');
    return '<div class="ts-chips">' + f + '</div><div class="ts-presets">' + list.map(function (p) {
      return '<button type="button" class="ts-preset' + (S.platePreset === p.id ? ' on' : '') + '" data-act="preset" data-id="' + p.id + '"><b>' + esc(p.n) + '</b><span>' + esc(p.t) + '</span></button>';
    }).join('') + '</div>';
  }

  TS.register({
    id: 'plato', short: 'Mi plato', eyebrow: 'Estación 2', title: 'Construye tu plato', next: 'Ver las porciones',
    lead: 'Elige alimentos de todos los días y mira cómo queda tu plato. La guía es sencilla: <b>la mitad con vegetales sin almidón, un cuarto con proteína y un cuarto con alimentos ricos en almidón.</b>',
    html: function () {
      return '<div class="ts-card ts-how"><h3>Cómo se hace</h3><ol class="ts-steps">' +
        '<li><b>Mira el plato.</b> Está dividido en tres sectores: la mitad para vegetales, un cuarto para proteína y un cuarto para almidón.</li>' +
        '<li><b>Elige alimentos de la lista.</b> Las opciones están junto al plato (en el celular, justo debajo), agrupadas por sector. Toca los que comes normalmente.</li>' +
        '<li><b>Mira cómo se llena.</b> Cada alimento aparece en su sector. Si un sector está lleno, quita uno para poner otro. Para quitar un alimento, tócalo otra vez.</li>' +
        '<li><b>¿Prefieres empezar con un ejemplo?</b> Más abajo hay comidas latinas y estadounidenses: toca una y luego cámbiale lo que quieras.</li>' +
        '<li><b>Cuando te guste cómo quedó,</b> toca «Ver las porciones». Tu plato se guarda solo y saldrá en tu PDF.</li></ol>' +
        '<p class="ts-hint">No hay un plato correcto ni incorrecto: es un ejercicio para ver tu comida de siempre con ojos nuevos.</p></div>' +
        '<div class="ts-plategrid"><div class="ts-platecol"><div data-zone="plate" class="ts-plate-wrap">' + plateSVG(S.plate) + '</div>' +
        '<div class="ts-legend"><span style="--c:#5F7318"><i></i>½ vegetales sin almidón</span><span style="--c:#A9552F"><i></i>¼ proteína</span><span style="--c:#B98A1E"><i></i>¼ almidón</span></div>' +
        '<div data-zone="feed" class="ts-feed" aria-live="polite">' + plateFeed() + '</div>' +
        '<button type="button" class="ts-btn ts-btn-ghost ts-small" data-act="clearplate">Vaciar el plato</button></div>' +
        '<div class="ts-palcol" data-zone="palette">' + palette() + '</div></div>' +
        '<div class="ts-card"><h3>Ejemplos para probar</h3><p class="ts-hint">Toca una comida para verla en el plato y cámbiale lo que quieras. Hay comidas latinas y estadounidenses: cada persona come distinto.</p><div data-zone="presets">' + presets() + '</div></div>' +
        '<div class="ts-card ts-why"><h3>¿Por qué esta distribución puede ayudar?</h3><div class="ts-3">' +
        '<div><b>Vegetales: la mitad</b><p>Aportan fibra, color y muchos nutrientes. Llenan el plato y dan variedad a la comida.</p></div>' +
        '<div><b>Proteína: un cuarto</b><p>Ayuda a sentirte satisfecha y a mantener tus músculos. Puede ser pollo, pescado, huevos, queso o legumbres.</p></div>' +
        '<div><b>Almidón: un cuarto</b><p>Es tu fuente de energía. El arroz, los frijoles, las lentejas, la papa o el plátano no están prohibidos: tienen su lugar.</p></div></div>' +
        '<p class="ts-hint">Es una guía orientativa, no una regla. Algunas comidas, como sopas, tacos o guisos, no se sirven en un plato: la idea es la misma, variedad y equilibrio.</p></div>';
    },
    zones: { plate: function () { return plateSVG(S.plate); }, feed: plateFeed, palette: palette, presets: presets },
    act: {
      food: function (el) {
        var id = el.getAttribute('data-id'), g = D.FOODS[id].g, arr = S.plate[g], i = arr.indexOf(id);
        if (i > -1) arr.splice(i, 1);
        else if (arr.length >= LIMIT[g]) { TS.toast('Ese sector está lleno. Quita un alimento para cambiarlo.'); return; }
        else arr.push(id);
        S.platePreset = ''; TS.save(); TS.refresh('plate', 'feed', 'palette', 'presets');
      },
      preset: function (el) {
        var p = TS.byId(D.PLATES, el.getAttribute('data-id'));
        S.plate = { veg: p.veg.slice(0, LIMIT.veg), protein: p.protein.slice(0, LIMIT.protein), starch: p.starch.slice(0, LIMIT.starch), extra: p.extra.slice(0, LIMIT.extra) };
        S.platePreset = p.id; TS.save(); TS.refresh('plate', 'feed', 'palette', 'presets');
      },
      pfilter: function (el) { pf = el.getAttribute('data-id'); TS.refresh('presets'); },
      clearplate: function () { S.plate = { veg: [], protein: [], starch: [], extra: [] }; S.platePreset = ''; TS.save(); TS.refresh('plate', 'feed', 'palette', 'presets'); }
    }
  });

  /* ================================================================== 3 · PORCIONES */
  function cupViz() {
    var o = D.SERVE_OPTS[S.serve] || D.SERVE_OPTS[2], v = o.v, txt;
    if (v < 0.5) txt = 'Menos que la porción de referencia. Puede ser suficiente si el resto del plato lleva mucho vegetal y proteína.';
    else if (v === 0.5) txt = 'Es media taza: la porción de referencia. Cabe en una mano en forma de copa.';
    else if (v === 1) txt = 'Una taza es el doble de la referencia (como un puño cerrado). Para muchas personas es una cantidad habitual y puede estar bien, según su hambre, su día y lo que lleve el resto del plato.';
    else if (v < 1) txt = 'Está entre media taza y una taza. Es normal servirse un poco más o un poco menos que la referencia.';
    else txt = 'Es más que la porción de referencia. No es bueno ni malo: fíjate en cómo queda tu plato y cómo te sientes después de comer.';
    return '<div class="ts-cupbox"><div>' + TS.cupSVG(v) + '</div><div><p class="ts-big">' + esc(o.t) + ' de arroz cocido</p><p>' + esc(txt) + '</p></div></div>';
  }
  function quiz() {
    return D.PORTION_QUIZ.map(function (q, i) {
      var ans = S.pq[i], done = ans != null;
      var opts = q.o.map(function (t, j) {
        var cls = done ? (j === q.a ? ' ok' : (j === ans ? ' no' : '')) : '';
        return '<button type="button" class="ts-opt' + cls + '" data-act="pq" data-q="' + i + '" data-o="' + j + '" data-key="pq-' + i + '-' + j + '"' + (done ? ' disabled' : '') + '>' + esc(t) + '</button>';
      }).join('');
      return '<div class="ts-q"><div class="ts-qh">' + (q.hand ? '<span class="ts-hand">' + TS.handSVG(q.hand, 52) + '</span>' : '') + '<p><b>' + (i + 1) + '.</b> ' + esc(q.q) + '</p></div><div class="ts-opts">' + opts + '</div>' +
        (done ? '<p class="ts-expl ' + (ans === q.a ? 'ok' : 'tip') + '" role="status"><b>' + (ans === q.a ? '¡Eso es!' : 'Buen intento.') + '</b> ' + esc(q.e) + '</p>' : '') + '</div>';
    }).join('');
  }
  function measures() {
    return D.MEASURE_ITEMS.map(function (m) {
      var cur = S.measures[m.id] || {};
      function sel(f, label) {
        return '<label class="ts-selwrap"><span>' + label + '</span><select class="ts-select" data-bind="measure" data-m="' + m.id + '" data-f="' + f + '"><option value="">Prefiero no responder</option>' +
          m.opts.map(function (o) { return '<option' + (cur[f] === o ? ' selected' : '') + '>' + esc(o) + '</option>'; }).join('') + '</select></label>';
      }
      return '<div class="ts-meas"><h4>' + esc(m.n) + '</h4><p class="ts-hint">Porción de referencia: <b>' + esc(m.ref) + '</b></p><div class="ts-two">' + sel('usual', 'Lo que suelo servirme') + sel('start', 'Medida con la que quiero empezar a observar') + '</div></div>';
    }).join('');
  }
  TS.register({
    id: 'porciones', short: 'Porciones', eyebrow: 'Estación 3', title: '¿Cuánto es una porción?', next: 'Leer etiquetas',
    lead: 'Aprende a calcular cantidades con tu propia mano y con medidas caseras. Ten presente que la <b>porción de referencia</b>, <b>lo que decides servirte</b> y <b>lo que necesita tu cuerpo</b> son tres cosas distintas.',
    html: function () {
      var cards = D.PORTIONS.map(function (p) {
        return '<article class="ts-pcard"><div class="ts-hand big">' + TS.handSVG(p.hand, 84) + '</div><h4>' + esc(p.n) + '</h4><p class="ts-measure">' + esc(p.measure) + '</p><p class="ts-alt">' + esc(p.alt) + '</p><p>' + esc(p.txt) + '</p>' +
          '<div class="ts-mini">' + p.foods.map(function (f) { return '<span title="' + esc(D.FOODS[f].n) + '">' + D.foodSVG(f, 30) + '</span>'; }).join('') + '</div></article>';
      }).join('');
      return '<div class="ts-pgrid">' + cards + '</div>' +
        '<p class="ts-hint ts-center">Las medidas con la mano son aproximadas: el tamaño de la mano cambia con el tamaño del cuerpo. Fuente de la equivalencia mano ↔ taza: guías de porciones de uso común en educación nutricional.</p>' +
        '<div class="ts-card"><h3>¿Cuánto arroz es esto?</h3><p class="ts-hint">Mueve la barra y mira cómo se ve en una taza medidora.</p>' +
        '<input class="ts-range" type="range" min="0" max="5" step="1" value="' + S.serve + '" data-bind="serve" aria-label="Cantidad de arroz cocido"><div class="ts-ticks"><span>¼</span><span>½</span><span>¾</span><span>1</span><span>1½</span><span>2</span></div>' +
        '<div data-zone="cup" aria-live="polite">' + cupViz() + '</div>' +
        '<div class="ts-3 ts-trio"><div><b>Porción de referencia</b><p>Es una medida estándar para comparar y para leer etiquetas.</p></div><div><b>Lo que me sirvo</b><p>Es la cantidad que decides en la mesa, según tu hambre y tu comida.</p></div><div><b>Lo que necesito</b><p>Depende de ti: tu cuerpo, tu actividad y tu etapa de vida. Un profesional de la salud puede orientarte.</p></div></div></div>' +
        '<div class="ts-card"><h3>Pon a prueba tus ojos</h3><div data-zone="quiz">' + quiz() + '</div></div>' +
        '<div class="ts-card"><h3>Mis medidas</h3><p class="ts-hint">Cuéntanos lo que sueles servirte y elige con qué medida quieres empezar a observar. Es un punto de partida para mirar, no una meta ni un número «correcto».</p><div data-zone="meas">' + measures() + '</div></div>';
    },
    zones: { quiz: quiz, cup: cupViz },
    act: {
      pq: function (el) { S.pq[+el.getAttribute('data-q')] = +el.getAttribute('data-o'); TS.save(); TS.refresh('quiz'); }
    },
    bind: {
      serve: function (v) { S.serve = +v; TS.save(); var z = TS.$('[data-zone="cup"]'); if (z) z.innerHTML = cupViz(); },
      measure: function (v, el) { var m = el.getAttribute('data-m'), f = el.getAttribute('data-f'); S.measures[m] = S.measures[m] || {}; S.measures[m][f] = v; TS.save(); }
    }
  });

  /* ================================================================== 4 · ETIQUETAS */
  var part = 'serving', scaled = {};
  function fmt(v) { return (Math.round(v * 10) / 10).toString().replace('.', ','); }
  function labelHTML(L, o) {
    o = o || {}; var k = o.k || 1, demo = o.demo;
    var dv = Math.round(L.added * k / 50 * 100);
    function row(p, html) { return demo ? '<button type="button" class="nl-row' + (part === p ? ' sel' : '') + '" data-act="part" data-id="' + p + '">' + html + '</button>' : '<div class="nl-row">' + html + '</div>'; }
    return '<div class="nl' + (demo ? ' nl-demo' : '') + '"><div class="nl-h">Información nutricional <em>ejemplo</em></div><div class="nl-name">' + esc(L.name) + '</div>' +
      (L.claim ? '<div class="nl-claim">«' + esc(L.claim) + '»</div>' : '') +
      row('serving', '<span>Tamaño de la porción</span><b>' + (k !== 1 ? 'Ajustada a ' + o.to + ' g' : esc(L.serving)) + '</b>') +
      row('carbs', '<span>Carbohidratos totales</span><b>' + fmt(L.carbs * k) + ' g</b>') +
      row('fiber', '<span class="in">Fibra</span><b>' + fmt(L.fiber * k) + ' g</b>') +
      row('sugars', '<span class="in">Azúcares totales</span><b>' + fmt(L.sugars * k) + ' g</b>') +
      row('added', '<span class="in2">Azúcares añadidos</span><b>' + fmt(L.added * k) + ' g</b>') +
      row('dv', '<span>% Valor Diario de azúcares añadidos</span><b>' + dv + ' %</b>') +
      (demo ? '<button type="button" class="nl-row nl-ing' + (part === 'ingredients' ? ' sel' : '') + '" data-act="part" data-id="ingredients"><span>Ingredientes:</span> ' + esc(L.ing) + '</button>' : '<div class="nl-ing"><span>Ingredientes:</span> ' + esc(L.ing) + '</div>') +
      '<div class="nl-foot">Etiqueta de ejemplo, no corresponde a un producto comercial real.</div></div>';
  }
  function anat() {
    var p = TS.byId(D.LABEL_PARTS, part);
    return '<div class="ts-anat"><div>' + labelHTML(D.DUELS[0].B, { demo: true }) + '</div><div class="ts-partbox" aria-live="polite"><p class="ts-eyebrow">Toca una línea de la etiqueta</p><h4>' + esc(p.n) + '</h4><p>' + esc(p.t) + '</p></div></div>';
  }
  function duels() {
    return D.DUELS.map(function (d, i) {
      var ans = S.labels[d.id], done = ans != null, k = d.scale && scaled[d.id] ? d.scaleTo / parseFloat(d[d.scaleSide].serving) : 1;
      var sc = d.scale ? '<button type="button" class="ts-chip' + (scaled[d.id] ? ' on' : '') + '" data-act="scale" data-id="' + d.id + '" aria-pressed="' + (!!scaled[d.id]) + '">Ver las dos con la misma cantidad (' + d.scaleTo + ' g)</button>' : '';
      var opts = d.o.map(function (t, j) {
        var cls = done ? (j === d.a ? ' ok' : (j === ans ? ' no' : '')) : '';
        return '<button type="button" class="ts-opt' + cls + '" data-act="duel" data-d="' + d.id + '" data-o="' + j + '" data-key="d-' + d.id + '-' + j + '"' + (done ? ' disabled' : '') + '>' + esc(t) + '</button>';
      }).join('');
      var Aopt = d.scale && scaled[d.id] ? { k: k, to: d.scaleTo } : {};
      return '<article class="ts-duel"><h4>' + (i + 1) + '. ' + esc(d.title) + '</h4>' + (sc ? '<div class="ts-chips">' + sc + '</div>' : '') +
        '<div class="ts-labels"><div><p class="ts-tag">Producto A</p>' + labelHTML(d.A, Aopt) + '</div><div><p class="ts-tag">Producto B</p>' + labelHTML(d.B) + '</div></div>' +
        '<p class="ts-qtext"><b>' + esc(d.q) + '</b></p><div class="ts-opts">' + opts + '</div>' +
        (done ? '<p class="ts-expl ' + (ans === d.a ? 'ok' : 'tip') + '" role="status"><b>' + (ans === d.a ? '¡Bien visto!' : 'Casi.') + '</b> ' + esc(d.e) + '</p>' : '') + '</article>';
    }).join('');
  }
  function revisions() {
    return '<div class="ts-chips">' + D.REVISIONS.map(function (r) { return chip('revisions', r.id, r.t, S.revisions.indexOf(r.id) > -1); }).join('') + '</div>';
  }
  TS.register({
    id: 'etiquetas', short: 'Etiquetas', eyebrow: 'Estación 4', title: '¿Qué nos dice la etiqueta?', next: 'Elegir mi movimiento',
    lead: 'El nombre, el envase y la publicidad no cuentan toda la historia: <b>hay que aprender a leer los datos.</b> Practica con etiquetas de ejemplo y recibe la explicación al instante.',
    html: function () {
      return '<div class="ts-card"><h3>Anatomía de una etiqueta</h3><div data-zone="anat">' + anat() + '</div></div>' +
        '<div class="ts-card ts-fruitnote"><h3>Tres ideas para quedarte</h3><div class="ts-3">' +
        '<div><b>La fruta entera aporta fibra</b><p>Además de otros nutrientes. Su azúcar viene dentro de la fruta.</p></div>' +
        '<div><b>Natural no es lo mismo que añadido</b><p>Los azúcares naturales (de la fruta o la leche) y los añadidos se leen en líneas distintas.</p></div>' +
        '<div><b>Ningún alimento es «malo» por sí solo</b><p>La etiqueta te da datos para elegir con calma, sin miedo.</p></div></div></div>' +
        '<div class="ts-card"><h3>Duelos de etiquetas</h3><p class="ts-hint">Cada ejemplo tiene una pregunta. Elige tu respuesta y lee la explicación.</p><div data-zone="duels">' + duels() + '</div></div>' +
        '<details class="ts-details"><summary>¿Y la glucosa? Una explicación sencilla</summary><p>La glucosa es un azúcar sencillo que circula en la sangre y que el cuerpo usa como energía. Cuando digerimos los carbohidratos de los alimentos (almidones y azúcares), se transforman en glucosa.</p>' +
        '<p>Cómo cambia la glucosa después de comer varía de una persona a otra y depende de la comida completa. La fibra, la proteína y las grasas que acompañan a un carbohidrato suelen hacer que la digestión sea más gradual.</p>' +
        '<p>Esto es información educativa y no sustituye la atención médica. Si tienes diabetes u otra condición, tu equipo de salud es quien define tu plan.</p></details>' +
        '<div class="ts-card"><h3>Mis revisiones al comprar</h3><p class="ts-hint">Elige lo que quieres revisar cuando tengas un producto en la mano. Irá a tu PDF.</p><div data-zone="rev">' + revisions() + '</div></div>';
    },
    zones: { anat: anat, duels: duels },
    act: {
      part: function (el) { part = el.getAttribute('data-id'); TS.refresh('anat'); },
      duel: function (el) { S.labels[el.getAttribute('data-d')] = +el.getAttribute('data-o'); TS.save(); TS.refresh('duels'); },
      scale: function (el) { var id = el.getAttribute('data-id'); scaled[id] = !scaled[id]; TS.refresh('duels'); }
    }
  });
})(window);
