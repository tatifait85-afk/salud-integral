/* Mi transformación saludable · núcleo: estado compartido, utilidades, navegación e iconos */
(function (W) {
  'use strict';
  var D = W.TS_DATA;
  var KEY = 'si-transformacion-v1';

  /* ------------------------------------------------------------------ estado */
  function fresh() {
    return {
      v: 1, step: 0, maxStep: 0, name: '', goals: [], usual: [], diets: [], dislikes: '', time: '', budget: '',
      plate: { veg: [], protein: [], starch: [], extra: [] }, platePreset: '',
      pq: {}, serve: 2, measures: {}, labels: {}, revisions: [],
      moveLevel: 'suave', moveLikes: [], blocks: [], moveDays: ['lun', 'mar', 'mie', 'jue', 'vie'],
      likes: [], week: null, habitsByDay: {}, shopOff: {}, shopExtra: [], commit: ''
    };
  }
  var S = fresh();
  try {
    var raw = W.localStorage && W.localStorage.getItem(KEY);
    if (raw) { var p = JSON.parse(raw); if (p && p.v === 1) { S = Object.assign(fresh(), p); S.plate = Object.assign(fresh().plate, p.plate || {}); } }
  } catch (e) { /* sin almacenamiento: la actividad funciona igual, solo no recuerda el progreso */ }

  var saveT = null;
  function save() {
    clearTimeout(saveT);
    saveT = setTimeout(function () { try { W.localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { } }, 250);
  }
  function wipe() { try { W.localStorage.removeItem(KEY); } catch (e) { } }

  /* ------------------------------------------------------------------ utilidades */
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function norm(s) { return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, ''); }
  function toggleIn(arr, v) { var i = arr.indexOf(v); if (i < 0) arr.push(v); else arr.splice(i, 1); return i < 0; }
  function byId(list, id) { for (var i = 0; i < list.length; i++) if (list[i].id === id) return list[i]; return null; }
  function uid() { return 'b' + Math.random().toString(36).slice(2, 8); }
  function toast(msg) {
    var t = $('#ts-toast'); if (!t) return;
    t.textContent = msg; t.classList.add('on'); clearTimeout(toast._t); toast._t = setTimeout(function () { t.classList.remove('on'); }, 3200);
  }

  /* ------------------------------------------------------------------ iconos propios */
  var SK = '#EBCFB0', ST = '#B98F66';
  var HANDS = {
    palm: '<g fill="' + SK + '" stroke="' + ST + '" stroke-width="1.6" stroke-linejoin="round"><rect x="18" y="30" width="30" height="26" rx="10"/><rect x="19" y="8" width="6.5" height="30" rx="3.25"/><rect x="27" y="4" width="6.5" height="34" rx="3.25"/><rect x="35" y="7" width="6.5" height="31" rx="3.25"/><rect x="42.5" y="14" width="6" height="26" rx="3"/><path d="M19 46L8 36a3.6 3.6 0 0 1 5.2-5L23 40z"/></g>',
    fist: '<g fill="' + SK + '" stroke="' + ST + '" stroke-width="1.6" stroke-linejoin="round"><rect x="12" y="20" width="40" height="34" rx="12"/><path d="M12 31h40M22 20v11M32 20v11M42 20v11" fill="none"/><path d="M14 44c-6-1-8-8-2-10l8 4z"/></g>',
    cup: '<g fill="' + SK + '" stroke="' + ST + '" stroke-width="1.6" stroke-linejoin="round"><path d="M8 24h48c0 18-9 30-24 30S8 42 8 24z"/><path d="M8 24c4-6 10-6 14 0M24 24c4-6 10-6 14 0M40 24c4-6 10-6 14 0" fill="none"/></g>',
    thumb: '<g fill="' + SK + '" stroke="' + ST + '" stroke-width="1.6" stroke-linejoin="round"><rect x="22" y="8" width="20" height="50" rx="10"/><path d="M26 14c2-3 10-3 12 0v8H26z" fill="#F7E7D2"/></g>'
  };
  function handSVG(kind, px) {
    if (kind === 'egg') return D.foodSVG('huevos', px || 72);
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="' + (px || 72) + '" height="' + (px || 72) + '" aria-hidden="true">' + (HANDS[kind] || '') + '</svg>';
  }
  var MV = {
    walk: '<circle cx="34" cy="12" r="5"/><path d="M34 18l-4 14-9 7M30 32l7 8v15M34 18l9 8 8 2M31 24l-9 5"/>',
    dance: '<circle cx="32" cy="11" r="5"/><path d="M32 17v20M32 24l-14-8M32 24l14 4 6-8M32 37l-9 18M32 37l12 6 4 12"/>',
    chair: '<circle cx="30" cy="12" r="5"/><path d="M30 18v16M30 24l-10 6M30 24l12-4 6-8M30 34h16v16M30 34l-4 16M22 50h28"/>',
    strength: '<circle cx="32" cy="12" r="5"/><path d="M32 18v22M32 40l-8 15M32 40l8 15M32 26l-14-6M32 26l14-6M10 20h8M46 20h8M12 16v8M52 16v8"/>',
    stretch: '<circle cx="32" cy="12" r="5"/><path d="M32 18v22M32 40l-10 16M32 40l10 16M32 24L16 8M32 24l16-16"/>'
  };
  function moveSVG(kind, px) {
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="' + (px || 56) + '" height="' + (px || 56) + '" fill="none" stroke="#4B5C12" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (MV[kind] || '') + '</svg>';
  }
  function cupSVG(frac) {
    var h = 110, top = 18, fill = Math.max(0, Math.min(1, frac / 2)) * h, y = top + h - fill;
    var ticks = '';[0.25, 0.5, 0.75, 1, 1.5, 2].forEach(function (v) {
      var ty = top + h - (v / 2) * h;
      ticks += '<path d="M62 ' + ty + 'h12" stroke="#173A1E" stroke-width="1.4"/><text x="78" y="' + (ty + 3.5) + '" font-size="10" fill="#5A4A3E" font-family="Jost,sans-serif">' + ({ 0.25: '¼', 0.5: '½', 0.75: '¾', 1: '1', 1.5: '1½', 2: '2' }[v]) + '</text>';
    });
    return '<svg viewBox="0 0 120 150" width="150" height="188" role="img" aria-label="Taza medidora con ' + frac + ' taza de arroz cocido">' +
      '<defs><clipPath id="cupclip"><path d="M20 ' + top + 'h42l-4 ' + h + 'H24z"/></clipPath></defs>' +
      '<path d="M20 ' + top + 'h42l-4 ' + h + 'H24z" fill="#FBF8F1" stroke="#173A1E" stroke-width="2"/>' +
      '<g clip-path="url(#cupclip)"><rect x="10" y="' + y + '" width="70" height="' + (fill + 2) + '" fill="#F7F2E4" stroke="#D8CDB4"/>' +
      (fill > 6 ? '<g fill="#D8CDB4"><ellipse cx="30" cy="' + (y + 8) + '" rx="3" ry="1.4"/><ellipse cx="42" cy="' + (y + 14) + '" rx="3" ry="1.4"/><ellipse cx="36" cy="' + (y + 24) + '" rx="3" ry="1.4"/><ellipse cx="48" cy="' + (y + 30) + '" rx="3" ry="1.4"/><ellipse cx="28" cy="' + (y + 36) + '" rx="3" ry="1.4"/></g>' : '') + '</g>' +
      '<path d="M62 30c14 0 14 28 0 28" fill="none" stroke="#173A1E" stroke-width="2"/>' + ticks + '</svg>';
  }

  /* ------------------------------------------------------------------ registro de estaciones y zonas */
  var STATIONS = [];
  function register(st) { STATIONS.push(st); }
  var root = null, live = null;

  function zone(name) { return root && root.querySelector('[data-zone="' + name + '"]'); }
  function refresh() {
    var st = STATIONS[S.step]; if (!st) return;
    for (var i = 0; i < arguments.length; i++) {
      var z = zone(arguments[i]); if (z && st.zones && st.zones[arguments[i]]) {
        var focusKey = document.activeElement && document.activeElement.getAttribute && document.activeElement.getAttribute('data-key');
        z.innerHTML = st.zones[arguments[i]]();
        if (focusKey) { var el = z.querySelector('[data-key="' + focusKey + '"]'); if (el) el.focus(); }
      }
    }
  }

  /* ------------------------------------------------------------------ navegación */
  function stepper() {
    var out = '<ol class="ts-steps" aria-label="Estaciones">';
    STATIONS.forEach(function (st, i) {
      var cls = i === S.step ? ' is-current' : (i < S.step ? ' is-done' : '');
      out += '<li class="' + cls.trim() + '"><button type="button" data-act="goto" data-n="' + i + '"' + (i === S.step ? ' aria-current="step"' : '') + '><span class="n">' + (i + 1) + '</span><span class="t">' + esc(st.short) + '</span></button></li>';
    });
    return out + '</ol><div class="ts-bar" role="progressbar" aria-valuemin="1" aria-valuemax="' + STATIONS.length + '" aria-valuenow="' + (S.step + 1) + '" aria-label="Progreso"><i style="width:' + Math.round((S.step + 1) / STATIONS.length * 100) + '%"></i></div><p class="ts-count">Estación ' + (S.step + 1) + ' de ' + STATIONS.length + '</p>';
  }
  function render(focus) {
    var st = STATIONS[S.step];
    $('#ts-nav').innerHTML = stepper();
    var last = S.step === STATIONS.length - 1;
    root.innerHTML = '<section class="ts-station" aria-labelledby="ts-h">' +
      '<header class="ts-sthead"><p class="ts-eyebrow">' + esc(st.eyebrow) + '</p><h2 id="ts-h" tabindex="-1">' + esc(st.title) + '</h2><p class="ts-lead">' + st.lead + '</p></header>' +
      st.html() +
      '<footer class="ts-foot">' +
      (S.step > 0 ? '<button class="ts-btn ts-btn-ghost" type="button" data-act="prev">← Atrás</button>' : '<span></span>') +
      (last ? '' : '<button class="ts-btn ts-btn-main" type="button" data-act="next">' + esc(st.next || 'Continuar') + ' →</button>') +
      '</footer></section>';
    if (st.after) st.after();
    if (focus) { var h = $('#ts-h'); if (h) { h.focus({ preventScroll: true }); var top = $('#ts-top'); (top || h).scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'start' }); } }
  }
  function go(n, focus) {
    if (n > 0 && !S.name.trim()) { n = 0; toast('Cuéntanos tu nombre para empezar: aparecerá en la portada de tu plan.'); }
    S.step = Math.max(0, Math.min(STATIONS.length - 1, n)); S.maxStep = Math.max(S.maxStep, S.step); save(); render(focus !== false);
    if (S.step === 0 && !S.name.trim()) { var i = $('#ts-name'); if (i) i.focus(); }
  }

  /* ------------------------------------------------------------------ eventos */
  var ACT = {
    goto: function (el) { go(+el.getAttribute('data-n')); },
    next: function () { go(S.step + 1); },
    prev: function () { go(S.step - 1); },
    toggle: function (el) {   // chips de lista simple: data-list="goals|usual|diets|revisions|moveLikes|moveDays|likes"
      var list = el.getAttribute('data-list'), id = el.getAttribute('data-id');
      var on = toggleIn(S[list], id); el.setAttribute('aria-pressed', on ? 'true' : 'false'); el.classList.toggle('on', on); save();
      var st = STATIONS[S.step]; if (st.onToggle) st.onToggle(list, id, on);
    },
    one: function (el) {      // opción única: data-key2="time|budget|moveLevel"
      var k = el.getAttribute('data-k'), v = el.getAttribute('data-id');
      S[k] = (S[k] === v && k !== 'moveLevel') ? '' : v; save();
      $$('[data-act="one"][data-k="' + k + '"]').forEach(function (b) { var on = S[k] === b.getAttribute('data-id'); b.setAttribute('aria-pressed', on ? 'true' : 'false'); b.classList.toggle('on', on); });
      var st = STATIONS[S.step]; if (st.onOne) st.onOne(k, S[k]);
    }
  };
  function onClick(e) {
    var el = e.target.closest('[data-act]'); if (!el || !root.contains(el) && !el.closest('#ts-nav')) return;
    var a = el.getAttribute('data-act'), st = STATIONS[S.step];
    if (ACT[a]) { ACT[a](el, e); return; }
    if (st && st.act && st.act[a]) st.act[a](el, e);
  }
  function onInput(e) {
    var el = e.target; var b = el.getAttribute && el.getAttribute('data-bind'); if (!b) return;
    var st = STATIONS[S.step]; var v = el.type === 'checkbox' ? el.checked : el.value;
    if (st && st.bind && st.bind[b]) st.bind[b](v, el); else { S[b] = v; save(); }
  }

  function boot() {
    root = $('#ts-root'); if (!root) return;
    document.addEventListener('click', onClick);
    document.addEventListener('input', onInput);
    document.addEventListener('change', onInput);
    var r = $('#ts-reset');
    if (r) r.addEventListener('click', function () {
      if (W.confirm('Se borrarán tus elecciones guardadas en este dispositivo y volverás al inicio. ¿Quieres continuar?')) { wipe(); var f = fresh(); Object.keys(S).forEach(function (k) { delete S[k]; }); Object.assign(S, f); render(true); toast('Listo: empezaste de nuevo.'); }
    });
    if (!S.name.trim()) S.step = 0;
    render(false);
  }

  var TS = W.TS = {
    S: S, D: D, esc: esc, $: $, $$: $$, norm: norm, toggleIn: toggleIn, byId: byId, uid: uid, toast: toast, save: save,
    handSVG: handSVG, moveSVG: moveSVG, cupSVG: cupSVG, register: register, refresh: refresh, go: go, render: render, boot: boot,
    ACT: ACT, STATIONS: STATIONS, getS: function () { return S; }
  };
  /* S puede reemplazarse al reiniciar: las estaciones usan siempre TS.getS() mediante la función s() */
  TS.s = function () { return S; };
})(window);
