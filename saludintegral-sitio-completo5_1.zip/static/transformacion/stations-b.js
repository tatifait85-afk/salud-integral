/* Mi transformación saludable · estaciones 5 a 7: movimiento, semana y plan personalizado */
(function (W) {
  'use strict';
  var TS = W.TS, D = TS.D, S = TS.S, esc = TS.esc;

  function chip(list, id, text, on) {
    return '<button type="button" class="ts-chip' + (on ? ' on' : '') + '" data-act="toggle" data-list="' + list + '" data-id="' + esc(id) + '" aria-pressed="' + (on ? 'true' : 'false') + '">' + esc(text) + '</button>';
  }

  /* ================================================================== 5 · MOVIMIENTO */
  var add = { move: 'caminar', slot: 'am', min: 5 };
  var MINS = [5, 10, 15, 20];
  function mv(id) { return TS.byId(D.MOVES, id); }
  function levelName() { var l = TS.byId(D.LEVELS, S.moveLevel); return l ? l.t : ''; }
  function totals() {
    var day = 0; S.blocks.forEach(function (b) { day += b.min; });
    return { day: day, week: day * S.moveDays.length };
  }
  TS.moveTotals = totals;

  function mcards() {
    return D.MOVES.map(function (m) {
      var on = S.moveLikes.indexOf(m.id) > -1;
      return '<article class="ts-mcard' + (on ? ' on' : '') + '"><div class="ts-micon">' + TS.moveSVG(m.ic, 52) + '</div><div><h4>' + esc(m.n) + '</h4><p>' + esc(m.L[S.moveLevel]) + '</p>' +
        '<button type="button" class="ts-chip' + (on ? ' on' : '') + '" data-act="like" data-id="' + m.id + '" data-key="mc-' + m.id + '" aria-pressed="' + on + '">' + (on ? '♥ Me gusta' : '♡ Me gusta') + '</button></div></article>';
    }).join('');
  }
  function mday() {
    var t = totals(), cols = D.SLOTS.map(function (sl) {
      var list = S.blocks.filter(function (b) { return b.slot === sl.id; });
      var items = list.map(function (b) {
        var m = mv(b.move);
        return '<div class="ts-block"><span class="ts-micon sm">' + TS.moveSVG(m.ic, 34) + '</span><div><b>' + esc(m.n) + '</b>' +
          '<label class="ts-min"><span class="sr">Minutos de ' + esc(m.n) + '</span><select class="ts-select sm" data-bind="blockmin" data-id="' + b.id + '" data-key="bm-' + b.id + '">' +
          MINS.map(function (x) { return '<option value="' + x + '"' + (x === b.min ? ' selected' : '') + '>' + x + ' min</option>'; }).join('') + '</select></label></div>' +
          '<button type="button" class="ts-x" data-act="delblock" data-id="' + b.id + '" aria-label="Quitar ' + esc(m.n) + '">×</button></div>';
      }).join('') || '<p class="ts-empty">Sin bloques</p>';
      return '<div class="ts-slot"><h5>' + esc(sl.t) + '</h5>' + items + '</div>';
    }).join('');
    var days = D.DAYS.map(function (d) { return chip('moveDays', d.id, d.s, S.moveDays.indexOf(d.id) > -1).replace('class="ts-chip', 'title="' + d.t + '" class="ts-chip ts-day'); }).join('');
    return '<div class="ts-sum"><div><span class="num">' + t.day + '</span><span class="u">min al día</span></div><p>' + S.blocks.length + (S.blocks.length === 1 ? ' bloque' : ' bloques') + (S.blocks.length ? ' · se suman solos al agregar o quitar' : '') + '</p></div>' +
      '<div class="ts-slots">' + cols + '</div>' +
      '<h4>¿Qué días lo harás?</h4><div class="ts-chips" role="group" aria-label="Días de movimiento">' + days + '</div>' +
      '<p class="ts-weektot"><b>' + t.week + ' minutos</b> en la semana con tu horario actual.</p>';
  }
  TS.register({
    id: 'movimiento', short: 'Movimiento', eyebrow: 'Estación 5', title: 'Cinco minutos cuentan', next: 'Armar mi semana',
    lead: 'Elige movimientos que disfrutes y repártelos en bloques cortos. Por ejemplo, <b>cuatro bloques de cinco minutos suman veinte minutos</b>. Tú decides cuánto y cuándo.',
    html: function () {
      var lv = D.LEVELS.map(function (l) { return '<button type="button" class="ts-chip' + (S.moveLevel === l.id ? ' on' : '') + '" data-act="one" data-k="moveLevel" data-id="' + l.id + '" aria-pressed="' + (S.moveLevel === l.id) + '">' + esc(l.t) + '</button>'; }).join('');
      var selMove = D.MOVES.map(function (m) { return '<option value="' + m.id + '">' + esc(m.n) + '</option>'; }).join('');
      var selSlot = D.SLOTS.map(function (m) { return '<option value="' + m.id + '">' + esc(m.t) + '</option>'; }).join('');
      var selMin = MINS.map(function (m) { return '<option value="' + m + '">' + m + ' min</option>'; }).join('');
      return '<div class="ts-card"><h3>¿Cómo te sientes hoy para moverte?</h3><p class="ts-hint">Elige tu punto de partida: las ideas de abajo se adaptan. Puedes cambiarlo cuando quieras.</p><div class="ts-chips">' + lv + '</div></div>' +
        '<div class="ts-card"><h3>Movimientos que puedes disfrutar</h3><p class="ts-hint">Marca los que te gusten. Ningún movimiento es obligatorio.</p><div class="ts-mgrid" data-zone="mcards">' + mcards() + '</div></div>' +
        '<div class="ts-card"><h3>Arma tu horario</h3><div class="ts-builder"><label><span>Movimiento</span><select class="ts-select" data-bind="addmove">' + selMove + '</select></label>' +
        '<label><span>Momento</span><select class="ts-select" data-bind="addslot">' + selSlot + '</select></label><label><span>Duración</span><select class="ts-select" data-bind="addmin">' + selMin + '</select></label>' +
        '<button type="button" class="ts-btn ts-btn-main" data-act="addblock">Agregar bloque</button></div>' +
        '<div class="ts-chips"><button type="button" class="ts-btn ts-btn-ghost ts-small" data-act="suggest">Ayúdame a armar un ejemplo</button><button type="button" class="ts-btn ts-btn-ghost ts-small" data-act="clearblocks">Empezar de cero</button></div>' +
        '<div data-zone="mday" aria-live="polite">' + mday() + '</div>' +
        '<p class="ts-hint">Si tienes una condición médica, dolor o dudas, consulta con tu profesional de salud antes de cambiar tu actividad. Esta propuesta es general y adaptable.</p></div>';
    },
    after: function () {
      ['addmove:move', 'addslot:slot', 'addmin:min'].forEach(function (p) { var k = p.split(':'), el = TS.$('[data-bind="' + k[0] + '"]'); if (el) el.value = add[k[1]]; });
    },
    zones: { mcards: mcards, mday: mday },
    onOne: function () { TS.refresh('mcards', 'mday'); },
    onToggle: function (list) { if (list === 'moveDays') TS.refresh('mday'); },
    act: {
      like: function (el) { TS.toggleIn(S.moveLikes, el.getAttribute('data-id')); TS.save(); TS.refresh('mcards'); },
      addblock: function () { S.blocks.push({ id: TS.uid(), move: add.move, slot: add.slot, min: +add.min }); TS.save(); TS.refresh('mday'); },
      delblock: function (el) { var id = el.getAttribute('data-id'); S.blocks = S.blocks.filter(function (b) { return b.id !== id; }); TS.save(); TS.refresh('mday'); },
      clearblocks: function () { S.blocks = []; TS.save(); TS.refresh('mday'); },
      suggest: function () {
        var likes = S.moveLikes.length ? S.moveLikes : (S.moveLevel === 'apoyo' ? ['sentada', 'movilidad', 'bailar'] : ['caminar', 'movilidad', 'bailar', 'fuerza']);
        S.blocks = D.SLOTS.map(function (sl, i) { return { id: TS.uid(), move: likes[i % likes.length], slot: sl.id, min: 5 }; });
        TS.save(); TS.refresh('mday'); TS.toast('Te dejé un ejemplo: cámbialo como quieras.');
      }
    },
    bind: {
      addmove: function (v) { add.move = v; }, addslot: function (v) { add.slot = v; }, addmin: function (v) { add.min = +v; },
      blockmin: function (v, el) { var b = TS.byId(S.blocks, el.getAttribute('data-id')); if (b) { b.min = +v; TS.save(); TS.refresh('mday'); } }
    }
  });

  /* ================================================================== 6 · SEMANA */
  var SLOTK = [{ k: 'd', t: 'Desayuno', pool: 'd' }, { k: 'a', t: 'Almuerzo', pool: 'ac' }, { k: 'm', t: 'Merienda', pool: 'm' }, { k: 'c', t: 'Cena', pool: 'ac' }];
  var FTAGS = { pollo: ['carne'], res: ['carne'], cerdo: ['carne'], pescado: ['pescado'], atun: ['pescado'], huevos: ['huevo'], queso: ['lacteo'], yogurt: ['lacteo'], leche: ['lacteo'], pan: ['gluten'], espaguetis: ['gluten'], avena: ['gluten'] };
  var BAN = { vegetariana: ['carne', 'pescado'], sinlacteos: ['lacteo'], sinhuevo: ['huevo'], sinpescado: ['pescado'], singluten: ['gluten'] };
  var USUAL_MAP = { gallo: ['gallo-huevo', 'gallo-aguacate'], casado: ['casado'], 'arroz-pollo': ['arroz-pollo'], pasta: ['pasta-atun'], sopa: ['sopa-lentejas', 'lentejas-camote', 'chili'], sandwich: ['sandwich-pollo', 'tostada-aguacate'], tacos: ['tacos-pollo', 'tortilla-frijol'], hamburguesa: ['hamburguesa'], ensaladas: ['ensalada-completa'], huevos: ['gallo-huevo', 'revueltos', 'omelette', 'arroz-huevo', 'm-huevo-pepino'] };
  var STOP = ['los', 'las', 'que', 'con', 'sin', 'por', 'una', 'uno', 'mis', 'del', 'pero', 'como', 'no', 'me', 'gusta', 'gustan', 'como', 'comer'];

  function banned() { var b = []; S.diets.forEach(function (d) { (BAN[d] || []).forEach(function (t) { if (b.indexOf(t) < 0) b.push(t); }); }); return b; }
  function dislikeTokens() {
    return TS.norm(S.dislikes).split(/[\s,;.\/]+|\by\b|\bni\b|\bo\b/).map(function (t) { return t.replace(/s$/, ''); }).filter(function (t) { return t.length >= 3 && STOP.indexOf(t) < 0; });
  }
  function foodOk(id) {
    var bn = banned(), tg = FTAGS[id] || [], i;
    for (i = 0; i < tg.length; i++) if (bn.indexOf(tg[i]) > -1) return false;
    var name = TS.norm(D.FOODS[id].n), dt = dislikeTokens();
    for (i = 0; i < dt.length; i++) if (name.indexOf(dt[i]) > -1) return false;
    return true;
  }
  function mealOk(m) {
    var bn = banned(), i;
    for (i = 0; i < m.tags.length; i++) if (bn.indexOf(m.tags[i]) > -1) return false;
    var txt = TS.norm(m.n + ' ' + m.ing.map(function (x) { return D.FOODS[x].n; }).join(' ')), dt = dislikeTokens();
    for (i = 0; i < dt.length; i++) if (txt.indexOf(dt[i]) > -1) return false;
    return true;
  }
  function pool(poolKey, relaxed) {
    var l = D.MEALS.filter(function (m) { return m.s === poolKey && (relaxed || mealOk(m)); });
    return l.length || relaxed ? l : pool(poolKey, true);
  }
  function score(m) {
    var sc = 0, ids = [].concat(S.plate.veg, S.plate.protein, S.plate.starch, S.plate.extra);
    S.usual.forEach(function (u) { if ((USUAL_MAP[u] || []).indexOf(m.id) > -1) sc += 4; });
    if (S.likes.indexOf(m.id) > -1) sc += 6;
    m.ing.forEach(function (i) { if (ids.indexOf(i) > -1) sc += 1; });
    if (S.budget === 'ajustado' && m.eco) sc += 3; else if (S.budget === 'medio' && m.eco) sc += 1;
    if (S.time === 'poco' && m.q) sc += 3; else if (S.time === 'medio' && m.q) sc += 1;
    return sc;
  }
  var HDEF = ['plato', 'mover', 'agua', 'etiqueta', 'plan', 'pausa', 'porcion'];
  function buildWeek() {
    var used = {}, cells = {}, prev = {};
    D.DAYS.forEach(function (day, di) {
      var today = {};
      SLOTK.forEach(function (sl, si) {
        var best = null, bs = -1e9;
        pool(sl.pool).forEach(function (m, mi) {
          var s = score(m) - 6 * (used[m.id] || 0) - ((used[m.id] || 0) >= 2 ? 40 : 0) - (prev[sl.k] === m.id ? 6 : 0) - (today[m.id] ? 9 : 0) + ((mi * 7 + di * 3 + si) % 5) * 0.01;
          if (s > bs) { bs = s; best = m; }
        });
        if (best) { cells[day.id + '-' + sl.k] = { m: best.id, sw: {} }; used[best.id] = (used[best.id] || 0) + 1; today[best.id] = 1; prev[sl.k] = best.id; }
      });
    });
    S.week = { cells: cells };
    var hs = S.goals.map(function (g) { var o = TS.byId(D.GOALS, g); return o && o.h; }).filter(Boolean);
    HDEF.forEach(function (h) { if (hs.length < 7 && hs.indexOf(h) < 0) hs.push(h); });
    S.habitsByDay = {}; D.DAYS.forEach(function (d, i) { S.habitsByDay[d.id] = hs[i % hs.length]; });
    TS.save();
  }
  TS.ensureWeek = function () { if (!S.week) buildWeek(); };

  function effIng(cell) {
    var m = TS.byId(D.MEALS, cell.m);
    return m.ing.map(function (i) { return cell.sw[i] || i; });
  }
  function cellName(cell) {
    var m = TS.byId(D.MEALS, cell.m), pairs = Object.keys(cell.sw || {}).filter(function (k) { return cell.sw[k] !== k; });
    if (!pairs.length) return m.n;
    return m.n + ' (con ' + pairs.map(function (k) { return D.FOODS[cell.sw[k]].n.toLowerCase() + ' en lugar de ' + D.FOODS[k].n.toLowerCase(); }).join(' y ') + ')';
  }
  TS.cellName = cellName;
  TS.weekCells = function () {
    TS.ensureWeek();
    var out = {}; D.DAYS.forEach(function (d) { SLOTK.forEach(function (sl) { var c = S.week.cells[d.id + '-' + sl.k]; out[d.id + '-' + sl.k] = c ? cellName(c) : ''; }); });
    return out;
  };
  TS.SLOTK = SLOTK;

  function shopping() {
    TS.ensureWeek();
    var cnt = {};
    Object.keys(S.week.cells).forEach(function (k) { effIng(S.week.cells[k]).forEach(function (i) { cnt[i] = (cnt[i] || 0) + 1; }); });
    var order = ['veg', 'extra', 'starch', 'protein', 'pantry'], cat = { veg: 'Verduras y hortalizas', extra: 'Frutas, grasas y complementos', starch: 'Granos, tubérculos y cereales', protein: 'Proteínas y lácteos', pantry: 'Despensa' };
    return order.map(function (g) {
      var items = Object.keys(cnt).filter(function (i) { return D.FOODS[i].g === g; }).sort(function (a, b) { return D.FOODS[a].n.localeCompare(D.FOODS[b].n, 'es'); })
        .map(function (i) { return { id: i, n: D.FOODS[i].n, c: cnt[i], off: !!S.shopOff[i] }; });
      return { g: g, t: cat[g], items: items };
    }).filter(function (x) { return x.items.length; });
  }
  TS.shoppingList = shopping;

  function likesPicker() {
    var groups = [['d', 'Desayunos'], ['ac', 'Almuerzos y cenas'], ['m', 'Meriendas']];
    return groups.map(function (g) {
      return '<h4>' + g[1] + '</h4><div class="ts-chips">' + D.MEALS.filter(function (m) { return m.s === g[0] && mealOk(m); }).map(function (m) {
        return chip('likes', m.id, m.n, S.likes.indexOf(m.id) > -1);
      }).join('') + '</div>';
    }).join('');
  }
  function weekGrid() {
    if (!S.week) return '<div class="ts-emptyweek"><p>Elige las comidas que te gustan (opcional) y toca <b>Armar mi semana</b>. Luego podrás cambiar todo.</p></div>';
    var head = '<div class="ts-wh"></div>' + SLOTK.map(function (s) { return '<div class="ts-wh">' + s.t + '</div>'; }).join('') + '<div class="ts-wh">Hábito del día</div>';
    var rows = D.DAYS.map(function (d) {
      var cells = SLOTK.map(function (sl) {
        var key = d.id + '-' + sl.k, cell = S.week.cells[key];
        if (!cell) return '<div class="ts-cell" data-l="' + sl.t + '"></div>';
        var opts = pool(sl.pool).slice(); if (!TS.byId(opts, cell.m)) opts.unshift(TS.byId(D.MEALS, cell.m));
        var chips = TS.byId(D.MEALS, cell.m).ing.filter(function (i) { return D.SWAPS[i]; }).map(function (i) {
          var cur = cell.sw[i] || i;
          return '<button type="button" class="ts-ing' + (cur !== i ? ' sw' : '') + '" data-act="swap" data-cell="' + key + '" data-ing="' + i + '" data-key="sw-' + key + '-' + i + '" title="Toca para sustituir por otra opción">' + esc(D.FOODS[cur].n) + ' ⇄</button>';
        }).join('');
        return '<div class="ts-cell" data-l="' + sl.t + '"><label class="sr" for="c-' + key + '">' + d.t + ' ' + sl.t + '</label><select id="c-' + key + '" class="ts-select sm" data-bind="cellmeal" data-cell="' + key + '" data-key="cm-' + key + '">' +
          opts.map(function (m) { return '<option value="' + m.id + '"' + (m.id === cell.m ? ' selected' : '') + '>' + esc(m.n) + '</option>'; }).join('') + '</select>' +
          '<div class="ts-ings">' + chips + '</div>' + (Object.keys(cell.sw).filter(function (k) { return cell.sw[k] !== k; }).length ? '<p class="ts-swnote">' + esc(cellName(cell).replace(TS.byId(D.MEALS, cell.m).n, '').trim()) + '</p>' : '') + '</div>';
      }).join('');
      var hab = '<div class="ts-cell" data-l="Hábito del día"><label class="sr" for="h-' + d.id + '">Hábito del ' + d.t + '</label><select id="h-' + d.id + '" class="ts-select sm" data-bind="dayhabit" data-day="' + d.id + '" data-key="dh-' + d.id + '">' +
        D.HABITS.map(function (h) { return '<option value="' + h.id + '"' + (S.habitsByDay[d.id] === h.id ? ' selected' : '') + '>' + esc(h.t) + '</option>'; }).join('') + '</select></div>';
      return '<div class="ts-wd">' + d.t + '</div>' + cells + hab;
    }).join('');
    return '<div class="ts-weekgrid" role="group" aria-label="Plan semanal">' + head + rows + '</div>';
  }
  function shopZone() {
    if (!S.week) return '';
    var groups = shopping();
    var extra = S.shopExtra.map(function (t, i) { return '<li><span>' + esc(t) + '</span><button type="button" class="ts-x" data-act="delextra" data-i="' + i + '" aria-label="Quitar ' + esc(t) + '">×</button></li>'; }).join('');
    return groups.map(function (g) {
      return '<div class="ts-shopg"><h4>' + esc(g.t) + '</h4><ul>' + g.items.map(function (it) {
        return '<li><label><input type="checkbox" data-bind="shopoff" data-id="' + it.id + '"' + (it.off ? ' checked' : '') + '><span' + (it.off ? ' class="off"' : '') + '>' + esc(it.n) + '</span></label><em>' + it.c + (it.c === 1 ? ' comida' : ' comidas') + '</em></li>';
      }).join('') + '</ul></div>';
    }).join('') + '<div class="ts-shopg"><h4>Otros que quiero agregar</h4><ul>' + extra + '</ul><div class="ts-addextra"><input class="ts-input" id="ts-extra" type="text" maxlength="50" placeholder="Ej.: café, sal, jabón" data-key="extra-in"><button type="button" class="ts-btn ts-btn-ghost ts-small" data-act="addextra">Agregar</button></div></div>' +
      '<p class="ts-hint">Marca «ya lo tengo» en lo que tienes en casa y lo quitamos de tu lista del PDF.</p>';
  }
  TS.register({
    id: 'semana', short: 'Mi semana', eyebrow: 'Estación 6', title: 'Mis comidas y mi semana', next: 'Ver mi plan',
    lead: 'Con lo que elegiste armamos una propuesta flexible. Cambia comidas, sustituye alimentos y reparte hábitos: <b>es tu semana, tú la editas</b>. No hay una dieta fija ni un número de calorías.',
    html: function () {
      return '<div class="ts-card"><h3>Comidas que me gustan</h3><p class="ts-hint">Opcional. Las que marques tendrán prioridad. Ya quitamos lo que dijiste que no comes.</p><div data-zone="likes">' + likesPicker() + '</div></div>' +
        '<div class="ts-center"><button type="button" class="ts-btn ts-btn-main" data-act="build">' + (S.week ? 'Volver a proponer mi semana' : 'Armar mi semana') + '</button></div>' +
        '<div class="ts-card"><h3>Mi semana</h3><p class="ts-hint">Cambia una comida con la lista. Toca un ingrediente con ⇄ para sustituirlo por otro del mismo tipo.</p><div data-zone="week">' + weekGrid() + '</div></div>' +
        '<div class="ts-card"><h3>Mi lista de compras</h3><div data-zone="shop">' + shopZone() + '</div></div>' +
        '<div class="ts-card ts-2col"><div><h3>Ideas para ahorrar</h3><ul class="ts-bul"><li>Las legumbres secas (frijoles, lentejas, garbanzos) rinden mucho y cuestan poco.</li><li>Compra verduras y frutas de temporada: suelen ser más baratas y sabrosas.</li><li>El huevo y el atún en lata son proteínas económicas y rápidas.</li><li>Cocina doble y congela porciones para otro día.</li></ul></div>' +
        '<div><h3>Preparación sencilla</h3><ul class="ts-bul"><li>Cocina arroz y frijoles de una vez para varios días.</li><li>Lava y corta las verduras al llegar del súper.</li><li>Deja marinado el pollo o el pescado la noche anterior.</li><li>Prepara una ensalada base y agrégale lo fresco al servir.</li></ul></div></div>';
    },
    zones: { week: weekGrid, shop: shopZone, likes: likesPicker },
    act: {
      build: function () {
        if (S.week && !W.confirm('Se volverá a proponer toda la semana y se perderán tus cambios. ¿Quieres continuar?')) return;
        buildWeek(); TS.render(false); TS.toast('Tu semana está lista. Edítala a tu gusto.');
      },
      swap: function (el) {
        var key = el.getAttribute('data-cell'), ing = el.getAttribute('data-ing'), cell = S.week.cells[key];
        var opts = [ing].concat(D.SWAPS[ing] || []).filter(function (x) { return x === ing || foodOk(x); });
        var cur = cell.sw[ing] || ing, nx = opts[(opts.indexOf(cur) + 1) % opts.length];
        if (nx === ing) delete cell.sw[ing]; else cell.sw[ing] = nx;
        TS.save(); TS.refresh('week', 'shop');
      },
      addextra: function () { var i = TS.$('#ts-extra'); if (i && i.value.trim()) { S.shopExtra.push(i.value.trim()); TS.save(); TS.refresh('shop'); } },
      delextra: function (el) { S.shopExtra.splice(+el.getAttribute('data-i'), 1); TS.save(); TS.refresh('shop'); }
    },
    bind: {
      cellmeal: function (v, el) { var c = S.week.cells[el.getAttribute('data-cell')]; c.m = v; c.sw = {}; TS.save(); TS.refresh('week', 'shop'); },
      dayhabit: function (v, el) { S.habitsByDay[el.getAttribute('data-day')] = v; TS.save(); },
      shopoff: function (v, el) { var id = el.getAttribute('data-id'); if (v) S.shopOff[id] = true; else delete S.shopOff[id]; TS.save(); TS.refresh('shop'); }
    }
  });

  /* ================================================================== 7 · PLAN */
  function summary() {
    var t = totals(), meals = S.week ? Object.keys(S.week.cells).length : 0, shop = S.week ? shopping().reduce(function (a, g) { return a + g.items.filter(function (i) { return !i.off; }).length; }, 0) : 0;
    var goals = S.goals.length ? S.goals.map(function (g) { return '<li>' + esc(TS.byId(D.GOALS, g).t) + '</li>'; }).join('') : '<li>Explorar toda la actividad a mi ritmo</li>';
    var pref = [];
    if (S.usual.length) pref.push('Comidas de siempre: ' + S.usual.map(function (u) { return TS.byId(D.USUAL, u).t.toLowerCase(); }).join(', '));
    if (S.diets.length) pref.push(S.diets.map(function (u) { return TS.byId(D.DIETS, u).t; }).join(', '));
    if (S.dislikes.trim()) pref.push('No como: ' + S.dislikes.trim());
    if (S.time) pref.push('Tiempo para cocinar: ' + TS.byId(D.TIMES, S.time).t.toLowerCase());
    if (S.budget) pref.push('Presupuesto: ' + TS.byId(D.BUDGETS, S.budget).t.toLowerCase());
    return '<div class="ts-sumgrid">' +
      '<div class="ts-card"><h4>Lo que quiero lograr</h4><ul class="ts-bul">' + goals + '</ul>' + (pref.length ? '<h4>Mis preferencias</h4><ul class="ts-bul">' + pref.map(function (p) { return '<li>' + esc(p) + '</li>'; }).join('') + '</ul>' : '') + '</div>' +
      '<div class="ts-card ts-center"><h4>Mi plato</h4><div class="ts-plate-wrap sm">' + TS.plateSVG(S.plate) + '</div></div>' +
      '<div class="ts-card"><h4>Mi plan en números</h4><ul class="ts-stats"><li><b>' + meals + '</b><span>comidas en mi semana</span></li><li><b>' + shop + '</b><span>productos en mi lista</span></li><li><b>' + t.day + '</b><span>min de movimiento al día</span></li><li><b>' + t.week + '</b><span>min a la semana</span></li></ul></div></div>';
  }
  var pdfBusy = false;
  TS.register({
    id: 'plan', short: 'Mi plan', eyebrow: 'Estación 7', title: 'Mi plan personalizado', next: '',
    lead: 'Así quedó lo que elegiste. Tu PDF reúne tu plato, tus porciones, tu guía de etiquetas, tu semana, tu lista de compras y tu rutina, con espacio para registrar tus avances.',
    html: function () {
      return '<div data-zone="sum">' + summary() + '</div>' +
        '<div class="ts-card"><h3>Último toque</h3><label class="ts-lab" for="ts-name2">Nombre en la portada</label><input id="ts-name2" class="ts-input" type="text" maxlength="60" data-bind="name" value="' + esc(S.name) + '">' +
        '<label class="ts-lab" for="ts-commit">Mi compromiso (opcional)</label><textarea id="ts-commit" class="ts-input" rows="3" maxlength="240" data-bind="commit" placeholder="Ej.: Esta semana voy a armar mi plato con la guía en el almuerzo.">' + esc(S.commit) + '</textarea></div>' +
        '<div class="ts-card ts-dl"><div><h3>Descarga tu PDF</h3><p>El PDF se genera aquí mismo, en tu dispositivo. <b>Es rellenable en pantalla:</b> ábrelo con tu lector de PDF para editar tu plan semanal, tu lista y tu registro de avances, o imprímelo.</p></div>' +
        '<div><button type="button" class="ts-btn ts-btn-main ts-big" data-act="pdf" id="ts-pdfbtn">Descargar mi PDF</button><p class="ts-status" id="ts-pdfmsg" role="status" aria-live="polite"></p></div></div>' +
        '<p class="ts-hint ts-center">Puedes volver a cualquier estación con los números de arriba, cambiar lo que quieras y descargar otra vez.</p>' +
        '<p class="ts-legal">Este material es educativo y está pensado para la alimentación general, las porciones, las etiquetas y los hábitos. No diagnostica ni trata enfermedades, no sustituye la atención de tu profesional de la salud y las cantidades son una guía que debes adaptar a tu caso.</p>';
    },
    zones: { sum: summary },
    after: function () { TS.ensureWeek(); TS.refresh('sum'); },
    act: {
      pdf: function () {
        if (pdfBusy) return;
        var btn = TS.$('#ts-pdfbtn'), msg = TS.$('#ts-pdfmsg');
        if (!S.name.trim()) { msg.textContent = 'Escribe tu nombre para la portada.'; var n = TS.$('#ts-name2'); if (n) n.focus(); return; }
        pdfBusy = true; btn.disabled = true; btn.textContent = 'Preparando tu PDF…'; msg.textContent = '';
        TS.makePDF(S).then(function (fn) {
          msg.textContent = '¡Listo! Se descargó «' + fn + '». Si no ves la descarga, revisa la carpeta de descargas de tu navegador.';
        }).catch(function (e) {
          if (W.console) console.error(e);
          msg.textContent = 'No pudimos crear el PDF. Revisa tu conexión y vuelve a intentarlo; tus elecciones siguen guardadas.';
        }).then(function () { pdfBusy = false; btn.disabled = false; btn.textContent = 'Descargar mi PDF'; });
      }
    },
    bind: { name: function (v) { S.name = v; TS.save(); }, commit: function (v) { S.commit = v; TS.save(); } }
  });

  /* arranque (esta es la última pieza de la actividad en cargarse) */
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', TS.boot); else TS.boot();

  /* carga perezosa de pdf-lib y del generador de PDF */
  var pdfP = null;
  function loadScript(src) { return new Promise(function (ok, bad) { var s = document.createElement('script'); s.src = src; s.onload = ok; s.onerror = function () { bad(new Error('No se pudo cargar ' + src)); }; document.head.appendChild(s); }); }
  TS.makePDF = function (state) {
    if (!pdfP) pdfP = loadScript('/assets/transformacion/vendor/pdf-lib.min.js').then(function () { return loadScript('/assets/transformacion/pdf.js'); }).catch(function (e) { pdfP = null; throw e; });
    return pdfP.then(function () { return TS.buildPDF(state); });
  };
})(window);
